# SonicSpace – Music Recording Studio & Equipment Booking Management System

SonicSpace is a modern, responsive full-stack web application designed for multi-room music recording studios, Dolby Atmos mixing labs, and vintage outboard equipment rental facilities.

---

## 🎧 Core System Features

1. **Public Studio Showcase**:
   - Dynamic listing of five acoustically treated studio rooms (Neve 88RS, API 1608-II, SSL Duality Delta, Beat Foundry, Skyline Vocal Suite).
   - Real-time availability checking and conflict avoidance.
   - Comprehensive equipment catalog with vintage microphones, tube preamps, synthesizers, and instruments.
   - Detailed acoustical specifications, monitoring setups, and verified artist reviews.

2. **Customer Portal & Booking Flow**:
   - Secure customer authentication with JWT tokens and bcrypt password hashing.
   - Multi-step booking engine: room selection, date/time picker, duration, session type, dedicated engineer toggle, and outboard gear reservation.
   - Live double-booking validation (pessimistic schedule interval lock).
   - Simulated payment checkout (Card, Apple Pay, PayPal).
   - Customer dashboard: session history, upcoming bookings, cancellation with simulated refund, and post-session review submissions.

3. **Admin Operations Hub**:
   - Executive dashboard with **Chart.js** analytics: monthly revenue breakdown (studio vs gear rentals), studio utilization distribution, session type breakdown, and top rented gear.
   - Studio room management (Add, Edit, Rates, Status, Delete).
   - Equipment inventory management (Stock counts, daily/hourly rates, specs).
   - Booking reservations ledger with status management (`confirmed`, `in_session`, `completed`, `cancelled`).
   - Payment audit ledger with transaction references.
   - User account role moderation (promote to Admin or demote to Customer).
   - One-click CSV export of booking and financial records.

4. **Academic DBMS Explorer & Interactive SQL Console**:
   - In-app interactive SQL query runner to test views, multi-table joins, aggregations, and transactions in real-time.
   - Complete ER Diagram specification with primary keys, foreign keys, and cardinalities.
   - Normalization analysis from 1NF to 3NF.
   - ACID transaction walkthrough demonstrating pessimistic row locking (`SELECT ... FOR UPDATE`) to prevent concurrent double bookings.

---

## 🗄️ Database Architecture (MySQL 8.0+)

The relational database is normalized to 3NF across 8 tables:
- `users`: Artists, producers, and administrative staff credentials.
- `studios`: Acoustic rooms, consoles, monitoring systems, dimensions, and baseline hourly rates.
- `studio_availability`: Weekly operating schedules across all 7 days.
- `equipment`: Microphone locker, outboard compressors, preamps, synthesizers, and instruments.
- `bookings`: Central transaction reservations with date, time slots, duration, and financial tallies.
- `booking_equipment`: Associative table linking reserved gear to bookings ($M:N$).
- `payments`: Simulated financial settlements, transaction IDs, and payment methods.
- `reviews`: Verified artist reviews, sound quality ratings, and cleanliness scores.

### Database Views:
- `view_studio_summary`: Aggregated bookings, revenue, and computed ratings per studio room.
- `view_booking_details`: Denormalized customer, studio, and payment information for invoice rendering.
- `view_revenue_monthly`: Monthly gross sales, studio time sales, and gear rental revenue.

---

## 🚀 Getting Started

### 1. Prerequisites
- Node.js 18+ or 20+
- (Optional) MySQL 8.0+ instance (The application includes an in-process simulated relational database pre-seeded with rich sample data that runs out of the box without requiring local MySQL installation).

### 2. Environment Setup
Copy the example environment configuration:
```bash
cp .env.example .env
```

Configure your `.env` variables:
```env
# Port & JWT Secret
PORT=3000
JWT_SECRET=your_jwt_secret_key_here

# (Optional) MySQL 8 Credentials:
# Leave blank to run in simulated relational memory mode, or provide your live MySQL 8 connection details:
DB_HOST=localhost
DB_PORT=3306
DB_USER=sonic_user
DB_PASSWORD=your_password
DB_NAME=sonicspace_db
```

### 3. Installation
```bash
npm install
```

### 4. Database Setup & Migration (MySQL 8.0+)

#### Option A: Quick Command-Line Setup
Create the database, user, and load the schema and seeds directly using the MySQL CLI:
```bash
# 1. Connect as root and create database and user
mysql -u root -p -e "
  CREATE DATABASE IF NOT EXISTS sonicspace_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
  CREATE USER IF NOT EXISTS 'sonic_user'@'localhost' IDENTIFIED BY 'sonic_secret_password_2026';
  GRANT ALL PRIVILEGES ON sonicspace_db.* TO 'sonic_user'@'localhost';
  FLUSH PRIVILEGES;
"

# 2. Execute DDL Schema (creates all 8 normalized tables, foreign keys, indexes, and views)
mysql -u sonic_user -psonic_secret_password_2026 sonicspace_db < database/schema.sql

# 3. Seed Realistic Sample Data (studios, equipment, demo users, sample bookings, payments, reviews)
mysql -u sonic_user -psonic_secret_password_2026 sonicspace_db < database/seed.sql
```

#### Option B: Automatic Auto-Bootstrap
The Node.js backend automatically checks for the presence of tables upon startup and executes `database/schema.sql` and `database/seed.sql` if the database is unpopulated. Ensure your `.env` contains valid connection credentials.

#### Option C: MySQL Workbench / phpMyAdmin / DBeaver
1. Open your database management tool and connect to your MySQL 8 instance.
2. Open `database/schema.sql` and execute the entire script to create `sonicspace_db`, all tables, foreign keys, and views.
3. Open `database/seed.sql` and execute the script to populate the initial catalogue and test accounts.
4. Verify by running `SELECT * FROM view_studio_summary;`.

### 5. Running the Application
Development server (Full-stack Express + Vite):
```bash
npm run dev
```
Open your browser to `http://localhost:3000`.

---

## 🔑 Demo Accounts (Pre-seeded)

Use these accounts or click the **1-Click Test Drive** buttons in the navbar or login modal:
- **Studio Director (Admin)**:
  - Email: `admin@sonicspace.io`
  - Password: `password123`
- **Artist / Producer (Customer)**:
  - Email: `damian@producer.com`
  - Password: `password123`

---

## 🐳 Docker Deployment

Build and run using Docker:
```bash
# Build the Docker image
docker build -t sonicspace-app .

# Run the container
docker run -p 3000:3000 -e JWT_SECRET=sonic_secret_key sonicspace-app
```

---

## ☁️ Google Cloud Run Deployment

Deploy SonicSpace to Google Cloud Run:
```bash
# Authenticate and set GCP project
gcloud auth login
gcloud config set project YOUR_GCP_PROJECT_ID

# Deploy directly from source to Cloud Run
gcloud run deploy sonicspace \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated \
  --port 3000 \
  --set-env-vars="JWT_SECRET=your_production_secret_key"
```
