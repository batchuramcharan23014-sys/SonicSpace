import React, { useState } from 'react';
import { Music2, Sliders, Calendar, ShieldCheck, User as UserIcon, LogOut, ChevronDown, Database, Menu, X, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { DbStatusBadge } from './DbStatusBadge';
import { AudioWaveform } from './AudioWaveform';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenBooking: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onOpenProfile: () => void;
  onOpenDbms: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  onOpenBooking,
  onOpenAuth,
  onOpenProfile,
  onOpenDbms
}) => {
  const { user, isAuthenticated, isAdmin, logout, quickLogin } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { id: 'studios', label: 'Studios' },
    { id: 'equipment', label: 'Gear Catalogue' },
    { id: 'pricing', label: 'Pricing & Hours' },
    { id: 'about', label: 'About Us' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B0B13]/90 backdrop-blur-xl border-b border-purple-500/20 shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Waveform */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 text-left cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-lg shadow-purple-600/30 group-hover:scale-105 transition-transform">
                <div className="w-full h-full bg-[#0B0B13] rounded-[10px] flex items-center justify-center">
                  <Music2 className="w-5 h-5 text-purple-400 group-hover:text-cyan-400 transition-colors" />
                </div>
              </div>
              <div>
                <span className="text-lg font-extrabold tracking-tight bg-gradient-to-r from-white via-slate-100 to-purple-300 bg-clip-text text-transparent">
                  Sonic<span className="text-purple-400">Space</span>
                </span>
                <span className="hidden sm:block text-[10px] font-mono tracking-widest text-slate-400 uppercase">
                  Studio & Gear Booking
                </span>
              </div>
            </button>

            {/* Audio Wave Visualizer */}
            <div className="hidden lg:flex items-center pl-3 border-l border-white/10">
              <AudioWaveform active={true} />
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 lg:gap-2">
            {navLinks.map(link => {
              const active = currentView === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => onNavigate(link.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs lg:text-sm font-medium transition-all cursor-pointer ${
                    active
                      ? 'text-white bg-purple-600/20 border border-purple-500/40 shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {link.label}
                </button>
              );
            })}

            {/* DBMS Explorer Button */}
            <button
              onClick={onOpenDbms}
              className="px-3 py-1.5 rounded-lg text-xs lg:text-sm font-medium text-purple-300 hover:text-white hover:bg-purple-950/40 border border-purple-500/30 transition-all flex items-center gap-1.5 cursor-pointer ml-1"
            >
              <Database className="w-3.5 h-3.5 text-cyan-400" />
              <span>DBMS Explorer</span>
            </button>
          </nav>

          {/* Right Controls: DB Status Pill & User Auth */}
          <div className="hidden md:flex items-center gap-3">
            <DbStatusBadge onClick={onOpenDbms} />

            {/* Fast Demo Account Switcher if not authenticated */}
            {!isAuthenticated && (
              <div className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-xl border border-white/10">
                <button
                  onClick={() => quickLogin('customer')}
                  title="1-Click Login as Artist Damian Cruz"
                  className="px-2 py-1 rounded text-[11px] font-medium text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
                >
                  Artist Demo
                </button>
                <button
                  onClick={() => quickLogin('admin')}
                  title="1-Click Login as Studio Director Marcus Vance"
                  className="px-2 py-1 rounded text-[11px] font-medium text-purple-300 hover:text-white hover:bg-purple-900/60 transition-colors cursor-pointer"
                >
                  Admin Demo
                </button>
              </div>
            )}

            {/* Primary Action Button */}
            <button
              onClick={onOpenBooking}
              className="px-4 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/25 transition-all flex items-center gap-1.5 cursor-pointer hover:scale-[1.02]"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Session</span>
            </button>

            {/* User Dropdown */}
            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pl-2.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-purple-500/30 transition-all cursor-pointer"
                >
                  <img
                    src={user?.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'}
                    alt={user?.name}
                    className="w-7 h-7 rounded-lg object-cover"
                  />
                  <span className="text-xs font-medium text-white max-w-[100px] truncate">{user?.name}</span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl bg-[#12111E] border border-purple-500/30 shadow-2xl p-2 z-50 text-xs text-slate-200 glow-purple">
                    <div className="p-2 border-b border-white/5 mb-1">
                      <p className="font-semibold text-white truncate">{user?.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">{user?.email}</p>
                      <span className="inline-block mt-1 px-1.5 py-0.5 rounded text-[10px] uppercase font-mono font-bold bg-purple-900/50 text-purple-300 border border-purple-500/20">
                        {user?.role === 'admin' ? 'Studio Administrator' : 'Artist / Client'}
                      </span>
                    </div>

                    <button
                      onClick={() => { onNavigate('customer'); setUserDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <Calendar className="w-4 h-4 text-purple-400" />
                      <span>My Studio Bookings</span>
                    </button>

                    {isAdmin && (
                      <button
                        onClick={() => { onNavigate('admin'); setUserDropdownOpen(false); }}
                        className="w-full text-left px-3 py-2 rounded-lg hover:bg-purple-950/40 text-purple-300 font-medium flex items-center gap-2 cursor-pointer transition-colors"
                      >
                        <ShieldCheck className="w-4 h-4 text-purple-400" />
                        <span>Admin Operations Hub</span>
                      </button>
                    )}

                    <button
                      onClick={() => { onOpenProfile(); setUserDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-white/5 flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-cyan-400" />
                      <span>Profile & Studio Preferences</span>
                    </button>

                    <div className="my-1 border-t border-white/5" />

                    <button
                      onClick={() => { logout(); setUserDropdownOpen(false); }}
                      className="w-full text-left px-3 py-2 rounded-lg hover:bg-rose-500/10 text-rose-300 flex items-center gap-2 cursor-pointer transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-all cursor-pointer"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F0E1C] border-b border-purple-500/30 p-4 space-y-3">
          <div className="flex flex-col gap-1">
            {navLinks.map(link => (
              <button
                key={link.id}
                onClick={() => { onNavigate(link.id); setMobileMenuOpen(false); }}
                className="w-full text-left px-3 py-2 rounded-lg text-sm text-slate-200 hover:bg-purple-950/40"
              >
                {link.label}
              </button>
            ))}
            <button
              onClick={() => { onOpenDbms(); setMobileMenuOpen(false); }}
              className="w-full text-left px-3 py-2 rounded-lg text-sm text-purple-300 hover:bg-purple-950/40 font-medium flex items-center gap-2"
            >
              <Database className="w-4 h-4 text-cyan-400" />
              <span>DBMS Academic Explorer</span>
            </button>
          </div>

          <div className="pt-3 border-t border-white/10 flex flex-col gap-2">
            <button
              onClick={() => { onOpenBooking(); setMobileMenuOpen(false); }}
              className="w-full py-2.5 rounded-xl bg-purple-600 text-white font-medium text-sm text-center"
            >
              Book Studio Session
            </button>

            {isAuthenticated ? (
              <div className="flex items-center justify-between pt-2">
                <span className="text-xs text-slate-300">{user?.name} ({user?.role})</span>
                <button
                  onClick={() => { logout(); setMobileMenuOpen(false); }}
                  className="text-xs text-rose-300 font-medium"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => { quickLogin('customer'); setMobileMenuOpen(false); }}
                  className="py-2 rounded-lg bg-slate-900 border border-slate-700 text-xs text-slate-200"
                >
                  Artist Demo
                </button>
                <button
                  onClick={() => { quickLogin('admin'); setMobileMenuOpen(false); }}
                  className="py-2 rounded-lg bg-purple-950 border border-purple-500/40 text-xs text-purple-200"
                >
                  Admin Demo
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
