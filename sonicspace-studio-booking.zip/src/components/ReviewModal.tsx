import React, { useState } from 'react';
import { X, Star, Sparkles, Send, CheckCircle2 } from 'lucide-react';
import { Booking, Review } from '../types';
import { api } from '../services/api';

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: Booking | null;
  onReviewSubmitted?: (review: Review) => void;
}

export const ReviewModal: React.FC<ReviewModalProps> = ({ isOpen, onClose, booking, onReviewSubmitted }) => {
  const [rating, setRating] = useState<number>(5);
  const [soundQualityRating, setSoundQualityRating] = useState<number>(5);
  const [cleanlinessRating, setCleanlinessRating] = useState<number>(5);
  const [comment, setComment] = useState<string>('');
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  if (!isOpen || !booking) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim()) {
      setError('Please provide a comment regarding your studio session experience.');
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const res = await api.createReview({
        bookingId: booking.id,
        rating,
        soundQualityRating,
        cleanlinessRating,
        comment: comment.trim()
      });
      setSuccess(true);
      if (onReviewSubmitted) onReviewSubmitted(res.review);
      setTimeout(() => {
        setSuccess(false);
        setComment('');
        onClose();
      }, 1200);
    } catch (err: any) {
      setError(err.message || 'Failed to submit review.');
    } finally {
      setSubmitting(false);
    }
  };

  const renderStars = (currentVal: number, setVal: (n: number) => void) => {
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <button
            key={star}
            type="button"
            onClick={() => setVal(star)}
            className="p-1 text-slate-600 hover:text-amber-400 focus:outline-none transition-colors cursor-pointer"
          >
            <Star
              className={`w-6 h-6 ${
                star <= currentVal ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
              }`}
            />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      <div className="relative w-full max-w-lg bg-[#12111E] border border-purple-500/30 rounded-2xl shadow-2xl p-6 text-white glow-purple overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-medium mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Verified Session Feedback</span>
          </div>
          <h2 className="text-xl font-bold text-white">Rate Your Studio Session</h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {booking.studio_name} • Session Ref: {booking.booking_reference}
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            {error}
          </div>
        )}

        {success ? (
          <div className="py-8 text-center space-y-2">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 mb-1">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white">Review Submitted!</h3>
            <p className="text-xs text-slate-300">Thank you for helping us maintain world-class studio quality.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Overall Rating */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div>
                <span className="text-xs font-semibold text-white block">Overall Experience</span>
                <span className="text-[10px] text-slate-400">Atmosphere, workflow & staff assistance</span>
              </div>
              {renderStars(rating, setRating)}
            </div>

            {/* Sound Quality Rating */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div>
                <span className="text-xs font-semibold text-white block">Acoustics & Sound Quality</span>
                <span className="text-[10px] text-slate-400">Frequency transparency, room decay, monitors</span>
              </div>
              {renderStars(soundQualityRating, setSoundQualityRating)}
            </div>

            {/* Cleanliness / Gear State */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
              <div>
                <span className="text-xs font-semibold text-white block">Facility Cleanliness & Gear State</span>
                <span className="text-[10px] text-slate-400">Sanitized mics, cable tidiness, lounge state</span>
              </div>
              {renderStars(cleanlinessRating, setCleanlinessRating)}
            </div>

            {/* Comment */}
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Artist Review & Audio Engineering Feedback
              </label>
              <textarea
                required
                rows={4}
                value={comment}
                onChange={e => setComment(e.target.value)}
                placeholder="Share your experience with the console, microphones, acoustic treatment, or recording engineer..."
                className="w-full p-3 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs shadow-lg shadow-purple-600/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {submitting ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Publish Session Review</span>
                </>
              )}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
