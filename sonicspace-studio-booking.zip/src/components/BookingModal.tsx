import React, { useState, useEffect } from 'react';
import { X, Calendar, Clock, Sparkles, Check, AlertTriangle, Shield, CreditCard, ChevronRight, ChevronLeft, Mic, Sliders, CheckCircle2 } from 'lucide-react';
import { Studio, Equipment, Booking } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedStudio?: Studio | null;
  onBookingSuccess?: (booking: Booking) => void;
  onOpenAuth?: () => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  selectedStudio,
  onBookingSuccess,
  onOpenAuth
}) => {
  const { user, isAuthenticated } = useAuth();

  // Steps: 1: Studio & Schedule, 2: Equipment Gear Add-ons, 3: Review & Payment Checkout, 4: Confirmed
  const [step, setStep] = useState<number>(1);

  // Studio & Schedule State
  const [studios, setStudios] = useState<Studio[]>([]);
  const [activeStudioId, setActiveStudioId] = useState<number>(selectedStudio?.id || 1);
  const [date, setDate] = useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  });
  const [startTime, setStartTime] = useState<string>('14:00');
  const [durationHours, setDurationHours] = useState<number>(4);
  const [sessionType, setSessionType] = useState<string>('Tracking / Recording');
  const [engineerRequired, setEngineerRequired] = useState<boolean>(true);
  const [specialRequests, setSpecialRequests] = useState<string>('');

  // Equipment catalogue & selected items
  const [equipmentList, setEquipmentList] = useState<Equipment[]>([]);
  const [selectedGear, setSelectedGear] = useState<Record<number, number>>({}); // equipmentId -> quantity

  // Availability checking state
  const [checkingAvailability, setCheckingAvailability] = useState<boolean>(false);
  const [availabilityResult, setAvailabilityResult] = useState<{ available: boolean; conflicts?: any[] } | null>(null);

  // Payment simulated state
  const [paymentMethod, setPaymentMethod] = useState<'credit_card' | 'apple_pay' | 'paypal'>('credit_card');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('921');
  const [cardHolder, setCardHolder] = useState(user?.name || 'Damian Cruz');

  // Submitting state & result
  const [submitting, setSubmitting] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);

  // Load initial studios & equipment list
  useEffect(() => {
    if (!isOpen) return;
    const loadData = async () => {
      try {
        const [stdList, eqList] = await Promise.all([
          api.getStudios({ status: 'active' }),
          api.getEquipment({ status: 'available' })
        ]);
        setStudios(stdList);
        setEquipmentList(eqList);
        if (selectedStudio) {
          setActiveStudioId(selectedStudio.id);
        } else if (stdList.length > 0) {
          setActiveStudioId(stdList[0].id);
        }
      } catch (err) {
        console.error('Failed to load booking resources', err);
      }
    };
    loadData();
  }, [isOpen, selectedStudio]);

  // Sync active studio if selectedStudio changes
  useEffect(() => {
    if (selectedStudio) {
      setActiveStudioId(selectedStudio.id);
    }
  }, [selectedStudio]);

  // Re-check slot availability whenever studio, date, startTime, or duration changes
  useEffect(() => {
    if (!isOpen || !activeStudioId || !date || !startTime) return;

    let cancelled = false;
    const verifySlot = async () => {
      setCheckingAvailability(true);
      setError(null);
      try {
        const res = await api.checkAvailability(activeStudioId, date, startTime, durationHours);
        if (!cancelled) {
          setAvailabilityResult({ available: res.available, conflicts: res.conflicts });
        }
      } catch (err: any) {
        if (!cancelled) {
          setAvailabilityResult({ available: false });
          setError(err.message);
        }
      } finally {
        if (!cancelled) setCheckingAvailability(false);
      }
    };

    const timer = setTimeout(verifySlot, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [isOpen, activeStudioId, date, startTime, durationHours]);

  if (!isOpen) return null;

  const currentStudio = studios.find(s => s.id === activeStudioId) || selectedStudio || studios[0];

  // Pricing calculations
  const studioRate = currentStudio ? currentStudio.hourly_rate : 120;
  const studioTotal = studioRate * durationHours;

  let equipmentTotal = 0;
  Object.entries(selectedGear).forEach(([idStr, qty]) => {
    const eq = equipmentList.find(e => e.id === parseInt(idStr, 10));
    if (eq && qty > 0) {
      equipmentTotal += eq.hourly_rate * durationHours * qty;
    }
  });

  const subtotal = studioTotal + equipmentTotal;
  const tax = parseFloat((subtotal * 0.08).toFixed(2));
  const grandTotal = parseFloat((subtotal + tax).toFixed(2));

  const toggleGear = (eqId: number) => {
    setSelectedGear(prev => {
      const next = { ...prev };
      if (next[eqId]) {
        delete next[eqId];
      } else {
        next[eqId] = 1;
      }
      return next;
    });
  };

  const handleConfirmAndPay = async () => {
    if (!isAuthenticated) {
      if (onOpenAuth) onOpenAuth();
      return;
    }

    setSubmitting(true);
    setError(null);

    try {
      const gearItems = Object.entries(selectedGear)
        .filter(([_, qty]) => qty > 0)
        .map(([id, qty]) => ({ equipmentId: parseInt(id, 10), quantity: qty }));

      const res = await api.createBooking({
        studioId: activeStudioId,
        date,
        startTime,
        durationHours,
        sessionType,
        engineerRequired,
        specialRequests,
        equipmentItems: gearItems,
        paymentMethod,
        cardLast4: cardNumber.replace(/\D/g, '').slice(-4) || '4242',
        cardBrand: paymentMethod === 'apple_pay' ? 'Apple Card' : 'Visa'
      });

      setConfirmedBooking(res.booking);
      setStep(4);
      if (onBookingSuccess) onBookingSuccess(res.booking);
    } catch (err: any) {
      setError(err.message || 'Booking submission failed. Please try a different slot.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleResetModal = () => {
    setStep(1);
    setSelectedGear({});
    setConfirmedBooking(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-3xl bg-[#12111E] border border-purple-500/30 rounded-2xl shadow-2xl text-white glow-purple overflow-hidden my-auto">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-900/60">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>SonicSpace Session Booking</span>
                {step < 4 && (
                  <span className="text-xs font-normal text-purple-300 bg-purple-950/70 px-2 py-0.5 rounded-full border border-purple-500/30">
                    Step {step} of 3
                  </span>
                )}
              </h2>
              <p className="text-xs text-slate-400">
                Guaranteed lock-in with real-time double-booking prevention
              </p>
            </div>
          </div>
          <button
            onClick={handleResetModal}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Indicator (Steps 1 to 3) */}
        {step < 4 && (
          <div className="flex items-center justify-between px-6 py-2.5 bg-slate-950/60 border-b border-white/5 text-xs">
            <button
              onClick={() => setStep(1)}
              className={`flex items-center gap-1.5 font-medium cursor-pointer ${
                step === 1 ? 'text-purple-400' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 1 ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}>1</span>
              <span>Studio & Schedule</span>
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
            <button
              onClick={() => availabilityResult?.available && setStep(2)}
              disabled={!availabilityResult?.available}
              className={`flex items-center gap-1.5 font-medium cursor-pointer ${
                step === 2 ? 'text-purple-400' : 'text-slate-400 hover:text-white'
              } disabled:opacity-40 disabled:cursor-not-allowed`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 2 ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}>2</span>
              <span>Equipment Add-ons</span>
            </button>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
            <button
              onClick={() => availabilityResult?.available && setStep(3)}
              disabled={!availabilityResult?.available}
              className={`flex items-center gap-1.5 font-medium cursor-pointer ${
                step === 3 ? 'text-purple-400' : 'text-slate-400 hover:text-white'
              } disabled:opacity-40 disabled:cursor-not-allowed`}
            >
              <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${
                step === 3 ? 'bg-purple-600 text-white' : 'bg-slate-800 text-slate-400'
              }`}>3</span>
              <span>Simulated Payment</span>
            </button>
          </div>
        )}

        {/* Modal Body */}
        <div className="p-6 max-h-[70vh] overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* ================= STEP 1: STUDIO & SCHEDULE ================= */}
          {step === 1 && (
            <div className="space-y-6">
              {/* Studio Selection Cards */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2">
                  Select Recording Studio Room
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {studios.map(s => {
                    const isSelected = s.id === activeStudioId;
                    return (
                      <div
                        key={s.id}
                        onClick={() => setActiveStudioId(s.id)}
                        className={`p-3.5 rounded-xl border transition-all duration-200 cursor-pointer flex gap-3 ${
                          isSelected
                            ? 'bg-purple-950/40 border-purple-500 shadow-md shadow-purple-900/20'
                            : 'bg-slate-900/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                        }`}
                      >
                        <img
                          src={s.image_url}
                          alt={s.name}
                          className="w-16 h-16 rounded-lg object-cover shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between">
                            <h4 className="text-sm font-semibold text-white truncate">{s.name}</h4>
                            {isSelected && <Check className="w-4 h-4 text-purple-400 shrink-0" />}
                          </div>
                          <p className="text-[11px] text-purple-300 font-mono mt-0.5">${s.hourly_rate}/hr</p>
                          <p className="text-[10px] text-slate-400 truncate mt-1">{s.console_type}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Date, Time, Duration Controls */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-purple-400" />
                    <span>Session Date</span>
                  </label>
                  <input
                    type="date"
                    min={new Date().toISOString().slice(0, 10)}
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Start Time</span>
                  </label>
                  <select
                    value={startTime}
                    onChange={e => setStartTime(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500"
                  >
                    {['08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00'].map(t => (
                      <option key={t} value={t}>{t} ({parseInt(t) >= 12 ? (parseInt(t) === 12 ? '12 PM' : `${parseInt(t) - 12} PM`) : `${parseInt(t)} AM`})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Duration (Hours)
                  </label>
                  <select
                    value={durationHours}
                    onChange={e => setDurationHours(parseInt(e.target.value, 10))}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500"
                  >
                    {[2, 3, 4, 6, 8, 10, 12].map(hrs => (
                      <option key={hrs} value={hrs}>{hrs} Hours Block</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Live Conflict Availability Banner */}
              <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
                checkingAvailability
                  ? 'bg-slate-900 border-slate-800 text-slate-400'
                  : availabilityResult?.available
                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-300'
                  : 'bg-rose-950/30 border-rose-500/40 text-rose-300'
              }`}>
                <div className="flex items-center gap-2">
                  {checkingAvailability ? (
                    <span className="w-3.5 h-3.5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin" />
                  ) : availabilityResult?.available ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>
                    {checkingAvailability
                      ? 'Validating studio schedule & atomic slot lock...'
                      : availabilityResult?.available
                      ? `Studio slot is 100% available on ${date} from ${startTime} for ${durationHours} hrs!`
                      : `Slot conflict! ${currentStudio?.name} is already booked at this time. Please adjust start time or date.`}
                  </span>
                </div>
                <span className="font-mono text-white text-xs shrink-0">
                  ${studioRate * durationHours} Studio Total
                </span>
              </div>

              {/* Session Type & Engineer Requirement */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Session Workflow Type
                  </label>
                  <select
                    value={sessionType}
                    onChange={e => setSessionType(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-sm text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="Tracking / Recording">Tracking / Band Recording</option>
                    <option value="Vocal Tracking">Lead Vocal Tracking</option>
                    <option value="Mixing & Mastering">Analog Summing / Mastering</option>
                    <option value="Podcast / Voiceover">Podcast & Voiceover</option>
                    <option value="Full Production">Full Production & Beat Lab</option>
                    <option value="Band Rehearsal">Pre-Tour Band Rehearsal</option>
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <label className="flex items-center gap-3 p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={engineerRequired}
                      onChange={e => setEngineerRequired(e.target.checked)}
                      className="w-4 h-4 text-purple-600 rounded focus:ring-purple-500 cursor-pointer"
                    />
                    <div className="text-xs">
                      <span className="font-medium text-white">Dedicated Staff Audio Engineer</span>
                      <p className="text-[10px] text-slate-400">Assists with patchbay, mic placement & DAW tracking</p>
                    </div>
                  </label>
                </div>
              </div>

              {/* Special Requests */}
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Session Notes or Patchbay Instructions (Optional)
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g. Please leave drum overheads patched to Neve 1073 preamps, and set lighting to cyan vibe."
                  value={specialRequests}
                  onChange={e => setSpecialRequests(e.target.value)}
                  className="w-full p-2.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>
          )}

          {/* ================= STEP 2: EQUIPMENT ADD-ONS ================= */}
          {step === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white">Reserve Studio Gear & Outboard Hardware</h3>
                  <p className="text-xs text-slate-400">
                    Add world-class vintage microphones, preamps, and synthesizers to your session lock.
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs text-purple-300 font-mono">
                    Gear Total: +${equipmentTotal}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[46vh] overflow-y-auto pr-1">
                {equipmentList.map(eq => {
                  const isChecked = Boolean(selectedGear[eq.id]);
                  const itemHourlyCost = eq.hourly_rate * durationHours;

                  return (
                    <div
                      key={eq.id}
                      onClick={() => toggleGear(eq.id)}
                      className={`p-3 rounded-xl border transition-all cursor-pointer flex gap-3 items-center ${
                        isChecked
                          ? 'bg-purple-950/40 border-purple-500 shadow-sm'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <img
                        src={eq.image_url}
                        alt={eq.name}
                        className="w-14 h-14 rounded-lg object-cover shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-[10px] uppercase font-semibold text-cyan-400">{eq.category}</span>
                          <span className="text-xs font-mono text-purple-300">+${itemHourlyCost}</span>
                        </div>
                        <h4 className="text-xs font-medium text-white truncate mt-0.5">{eq.name}</h4>
                        <p className="text-[10px] text-slate-400 truncate">{eq.brand} • ${eq.hourly_rate}/hr</p>
                      </div>
                      <div className={`w-5 h-5 rounded-md flex items-center justify-center border shrink-0 ${
                        isChecked ? 'bg-purple-600 border-purple-500 text-white' : 'border-slate-700 bg-slate-950'
                      }`}>
                        {isChecked && <Check className="w-3.5 h-3.5" />}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* ================= STEP 3: SUMMARY & SIMULATED CHECKOUT ================= */}
          {step === 3 && (
            <div className="space-y-6">
              {/* Order Invoice Summary */}
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-white/5">
                  <div>
                    <h4 className="text-sm font-semibold text-white">{currentStudio?.name}</h4>
                    <p className="text-xs text-slate-400">
                      {date} • {startTime} ({durationHours} Hours) • {sessionType}
                    </p>
                  </div>
                  <span className="font-mono text-sm text-purple-300">${studioTotal.toFixed(2)}</span>
                </div>

                {/* Reserved Equipment Breakdown */}
                {Object.keys(selectedGear).length > 0 && (
                  <div className="pb-3 border-b border-white/5 space-y-1.5">
                    <p className="text-[11px] font-semibold text-slate-300 uppercase tracking-wider">
                      Reserved Gear ({Object.keys(selectedGear).length} items):
                    </p>
                    {Object.entries(selectedGear).map(([idStr, qty]) => {
                      const eq = equipmentList.find(e => e.id === parseInt(idStr, 10));
                      if (!eq) return null;
                      const lineTotal = eq.hourly_rate * durationHours * qty;
                      return (
                        <div key={eq.id} className="flex justify-between text-xs text-slate-300">
                          <span className="truncate pr-2">• {eq.name}</span>
                          <span className="font-mono text-slate-400 shrink-0">${lineTotal.toFixed(2)}</span>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Tax & Total */}
                <div className="space-y-1 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span className="font-mono">${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-slate-400">
                    <span>Studio Facility & Acoustic Surcharge (8%)</span>
                    <span className="font-mono">${tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-white pt-2 border-t border-white/10">
                    <span>Total Session Lock</span>
                    <span className="font-mono text-emerald-400">${grandTotal.toFixed(2)}</span>
                  </div>
                </div>
              </div>

              {/* Simulated Payment Selector */}
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-2 flex items-center justify-between">
                  <span>Simulated Checkout Method</span>
                  <span className="text-[10px] text-cyan-400 font-normal flex items-center gap-1">
                    <Shield className="w-3 h-3" />
                    Simulated Sandbox Mode (No real charges)
                  </span>
                </label>

                <div className="grid grid-cols-3 gap-2 mb-4">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('credit_card')}
                    className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-all ${
                      paymentMethod === 'credit_card'
                        ? 'bg-purple-900/40 border-purple-500 text-white'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-4 h-4 text-purple-400" />
                    <span>Credit Card</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple_pay')}
                    className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-all ${
                      paymentMethod === 'apple_pay'
                        ? 'bg-purple-900/40 border-purple-500 text-white'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-cyan-400" />
                    <span>Apple Pay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('paypal')}
                    className={`p-2.5 rounded-xl border text-xs font-medium flex items-center justify-center gap-2 cursor-pointer transition-all ${
                      paymentMethod === 'paypal'
                        ? 'bg-purple-900/40 border-purple-500 text-white'
                        : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span className="font-bold text-blue-400 text-xs">P</span>
                    <span>PayPal</span>
                  </button>
                </div>

                {paymentMethod === 'credit_card' && (
                  <div className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 space-y-3">
                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">Card Number</label>
                      <input
                        type="text"
                        value={cardNumber}
                        onChange={e => setCardNumber(e.target.value)}
                        className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">Expiration</label>
                        <input
                          type="text"
                          value={cardExpiry}
                          onChange={e => setCardExpiry(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-purple-500"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">CVC Code</label>
                        <input
                          type="text"
                          value={cardCvc}
                          onChange={e => setCardCvc(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-lg text-xs font-mono text-white focus:outline-none focus:border-purple-500"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {!isAuthenticated && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center justify-between">
                  <span>Sign in is required to complete session booking.</span>
                  <button
                    type="button"
                    onClick={onOpenAuth}
                    className="px-3 py-1 rounded bg-amber-500 text-slate-950 font-semibold text-xs hover:bg-amber-400 cursor-pointer"
                  >
                    Sign In Now
                  </button>
                </div>
              )}
            </div>
          )}

          {/* ================= STEP 4: SUCCESS CONFIRMATION ================= */}
          {step === 4 && confirmedBooking && (
            <div className="text-center py-6 space-y-4">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 mb-2">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div>
                <h3 className="text-2xl font-bold text-white">Session Confirmed!</h3>
                <p className="text-sm text-slate-300 mt-1">
                  Your studio time is locked into the schedule. A receipt and calendar invite have been generated.
                </p>
              </div>

              <div className="max-w-md mx-auto p-4 rounded-xl bg-slate-900 border border-purple-500/30 text-left space-y-2 text-xs">
                <div className="flex justify-between pb-2 border-b border-slate-800">
                  <span className="text-slate-400">Booking Reference:</span>
                  <span className="font-mono font-bold text-purple-400">{confirmedBooking.booking_reference}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Studio:</span>
                  <span className="font-medium text-white">{confirmedBooking.studio_name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Date & Slot:</span>
                  <span className="font-medium text-white">{confirmedBooking.booking_date} @ {confirmedBooking.start_time.slice(0, 5)} ({confirmedBooking.duration_hours} hrs)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Session Type:</span>
                  <span className="font-medium text-white">{confirmedBooking.session_type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Total Settled:</span>
                  <span className="font-mono font-bold text-emerald-400">${confirmedBooking.total_amount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Simulated Txn ID:</span>
                  <span className="font-mono text-[11px] text-slate-400">{confirmedBooking.payment?.transaction_id || 'TXN_SONIC_CONFIRMED'}</span>
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleResetModal}
                  className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-sm transition-all cursor-pointer shadow-lg shadow-purple-600/30"
                >
                  Return to Dashboard & Manage Sessions
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Action Controls (Steps 1 to 3) */}
        {step < 4 && (
          <div className="flex items-center justify-between px-6 py-4 border-t border-white/10 bg-slate-900/60">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep(step - 1)}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back</span>
              </button>
            ) : (
              <div />
            )}

            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-[10px] text-slate-400 uppercase">Estimated Total</p>
                <p className="text-sm font-bold font-mono text-emerald-400">${grandTotal.toFixed(2)}</p>
              </div>

              {step === 1 && (
                <button
                  type="button"
                  disabled={!availabilityResult?.available || checkingAvailability}
                  onClick={() => setStep(2)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs shadow-lg shadow-purple-600/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <span>Continue to Gear Add-ons</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}

              {step === 2 && (
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-medium text-xs shadow-lg shadow-purple-600/20 transition-all flex items-center gap-2 cursor-pointer"
                >
                  <span>Proceed to Payment</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              )}

              {step === 3 && (
                <button
                  type="button"
                  disabled={submitting || !isAuthenticated}
                  onClick={handleConfirmAndPay}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white font-semibold text-xs shadow-lg shadow-emerald-600/20 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      <span>Locking Session & Executing Transaction...</span>
                    </>
                  ) : (
                    <>
                      <Shield className="w-4 h-4" />
                      <span>Confirm & Lock Booking (${grandTotal.toFixed(2)})</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
