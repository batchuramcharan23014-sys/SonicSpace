import React from 'react';

export const AudioWaveform: React.FC<{ active?: boolean; className?: string }> = ({ active = true, className = '' }) => {
  return (
    <div className={`flex items-center gap-[3px] h-6 ${className}`}>
      <span className={`w-1 rounded-full bg-purple-500 ${active ? 'animate-wave-1' : 'h-2'}`} />
      <span className={`w-1 rounded-full bg-cyan-400 ${active ? 'animate-wave-2' : 'h-3'}`} />
      <span className={`w-1 rounded-full bg-violet-400 ${active ? 'animate-wave-3' : 'h-1.5'}`} />
      <span className={`w-1 rounded-full bg-purple-400 ${active ? 'animate-wave-4' : 'h-4'}`} />
      <span className={`w-1 rounded-full bg-blue-500 ${active ? 'animate-wave-5' : 'h-2'}`} />
    </div>
  );
};
