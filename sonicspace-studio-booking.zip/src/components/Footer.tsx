import React from 'react';
import { Music2, Database, Shield, Sparkles, MapPin, Phone, Mail, Clock } from 'lucide-react';
import { AudioWaveform } from './AudioWaveform';

interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenDbms: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenDbms }) => {
  return (
    <footer className="w-full bg-[#08080E] border-t border-purple-500/20 text-slate-400 text-xs mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
          {/* Col 1: Brand & Tagline */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-purple-600/30 border border-purple-500/40 flex items-center justify-center">
                <Music2 className="w-5 h-5 text-purple-400" />
              </div>
              <span className="text-lg font-bold text-white tracking-tight">
                Sonic<span className="text-purple-400">Space</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Premier multi-room recording studio, Dolby Atmos mixing lab, and vintage outboard gear rental facility. Crafted for visionary artists, producers, and audio engineers.
            </p>
            <div className="flex items-center gap-2 pt-2">
              <AudioWaveform active={false} />
              <span className="text-[11px] font-mono text-purple-300">Dolby Atmos 7.1.4 Certified</span>
            </div>
          </div>

          {/* Col 2: Studio Rooms */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Recording Rooms</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('studios')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio A – The Neon Chamber (Neve 88RS)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('studios')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio B – Velvet Horizon (API 1608-II)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('studios')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio C – Electric Violet (SSL Duality)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('studios')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio D – The Beat Foundry (Moog/MPC)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('studios')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio E – Skyline Vocal & Broadcast
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Quick Navigation & Academic DBMS */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">System & Academics</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={onOpenDbms} className="hover:text-purple-300 transition-colors cursor-pointer flex items-center gap-1.5 font-medium text-purple-400">
                  <Database className="w-3.5 h-3.5" />
                  <span>DBMS Architecture & SQL Console</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('equipment')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Outboard Equipment Catalogue
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('pricing')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Session Hourly Rates & Packages
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Acoustic Design & Staff Engineers
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-purple-300 transition-colors cursor-pointer">
                  Studio Load-in & Booking Inquiries
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Facility Info & Hours */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Facility Location</h4>
            <div className="flex items-start gap-2 text-xs">
              <MapPin className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
              <span>482 Soundwave Blvd, Recording Arts District, Los Angeles, CA 90028</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>+1 (555) 880-BEAT (2328)</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <Mail className="w-4 h-4 text-violet-400 shrink-0" />
              <span>sessions@sonicspace.io</span>
            </div>
            <div className="flex items-center gap-2 text-xs pt-1 text-slate-300">
              <Clock className="w-4 h-4 text-amber-400 shrink-0" />
              <span>Open 7 Days • 08:00 AM – 02:00 AM</span>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <p>© {new Date().getFullYear()} SonicSpace Music Recording Studios. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <button onClick={onOpenDbms} className="hover:text-white transition-colors cursor-pointer">
              ER Diagram & Schema
            </button>
            <span>•</span>
            <span className="text-purple-400 font-mono">MySQL 8 Relational Architecture</span>
            <span>•</span>
            <span className="text-emerald-400">Pessimistic Double-Booking Locks Active</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
