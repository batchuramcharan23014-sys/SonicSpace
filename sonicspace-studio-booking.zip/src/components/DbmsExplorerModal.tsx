import React, { useState, useEffect } from 'react';
import { X, Database, Terminal, FileCode, GitFork, ShieldCheck, Play, Copy, Check, RefreshCw, Cpu, BookOpen, Layers } from 'lucide-react';
import { api } from '../services/api';
import { DbStatus } from '../types';

interface DbmsExplorerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DbmsExplorerModal: React.FC<DbmsExplorerModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'console' | 'er_diagram' | 'normalization' | 'acid' | 'schema_sql'>('console');
  const [dbStatus, setDbStatus] = useState<DbStatus | null>(null);
  const [testingConnection, setTestingConnection] = useState(false);

  // SQL Console state
  const [queryInput, setQueryInput] = useState<string>(
    'SELECT * FROM view_studio_summary;'
  );
  const [queryResult, setQueryResult] = useState<{
    columns: string[];
    rows: any[];
    rowCount: number;
    executionTimeMs: number;
  } | null>(null);
  const [queryLoading, setQueryLoading] = useState(false);
  const [queryError, setQueryError] = useState<string | null>(null);

  // Schema & seed SQL script state
  const [schemaSql, setSchemaSql] = useState<string>('');
  const [seedSql, setSeedSql] = useState<string>('');
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    api.getDbStatus().then(setDbStatus).catch(console.error);
    api.getSchemaSql().then(data => {
      setSchemaSql(data.schemaSql);
      setSeedSql(data.seedSql);
    }).catch(console.error);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRunQuery = async (customQ?: string) => {
    const q = customQ || queryInput;
    setQueryLoading(true);
    setQueryError(null);
    try {
      const res = await api.runQuery(q);
      if (res.success) {
        setQueryResult({
          columns: res.columns,
          rows: res.rows,
          rowCount: res.rowCount,
          executionTimeMs: res.executionTimeMs
        });
      } else {
        setQueryError(res.error || 'Execution failed');
      }
    } catch (err: any) {
      setQueryError(err.message || 'Execution error');
      setQueryResult(null);
    } finally {
      setQueryLoading(false);
    }
  };

  const sampleQueries = [
    {
      title: 'View 1: Studio Analytics Summary',
      category: 'Views & Grouping',
      sql: 'SELECT * FROM view_studio_summary;'
    },
    {
      title: 'View 2: Denormalized Booking Details',
      category: 'Views & Joins',
      sql: 'SELECT * FROM view_booking_details LIMIT 5;'
    },
    {
      title: 'Monthly Revenue Aggregation',
      category: 'Views & Aggregations',
      sql: 'SELECT * FROM view_revenue_monthly;'
    },
    {
      title: 'INNER JOIN: Active Bookings & Clients',
      category: 'Joins',
      sql: 'SELECT b.booking_reference, u.name AS artist_name, s.name AS studio_name, b.booking_date, b.total_amount, b.status FROM bookings b INNER JOIN users u ON b.user_id = u.id INNER JOIN studios s ON b.studio_id = s.id;'
    },
    {
      title: 'LEFT JOIN: Studio Reviews & Acoustics Ratings',
      category: 'Joins & Aggregation',
      sql: 'SELECT s.name AS studio_name, s.hourly_rate, COUNT(r.id) AS review_count, AVG(r.rating) AS avg_stars FROM studios s LEFT JOIN reviews r ON s.id = r.studio_id GROUP BY s.id, s.name, s.hourly_rate;'
    },
    {
      title: 'Equipment Inventory Status',
      category: 'CRUD & Filter',
      sql: 'SELECT name, category, brand, hourly_rate, available_quantity, total_quantity, status FROM equipment WHERE status = "available";'
    }
  ];

  const handleTestConnection = async () => {
    setTestingConnection(true);
    try {
      const res = await api.testDbConnection();
      setDbStatus(res.status);
    } catch (err) {
      console.error(err);
    } finally {
      setTestingConnection(false);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-5xl h-[90vh] bg-[#0E0D1B] border border-purple-500/40 rounded-2xl shadow-2xl text-white glow-purple flex flex-col overflow-hidden">
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-900/80">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">SonicSpace DBMS Academic Architecture & SQL Console</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-900/60 text-purple-300 border border-purple-500/30">
                  MySQL 8.0+
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Normalized 3NF Relational Database Model • ACID Transactions • Concurrency Control
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Engine Status Strip */}
        <div className="px-6 py-2.5 bg-slate-950/80 border-b border-white/5 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${dbStatus?.connected ? 'bg-emerald-400' : 'bg-cyan-400'} animate-pulse`} />
              <span className="font-semibold text-slate-200">
                Mode: {dbStatus?.mode === 'mysql' && dbStatus?.connected ? 'Live MySQL 8 Server' : 'Relational Memory Engine (MySQL Ready)'}
              </span>
            </div>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Host: <span className="text-slate-300 font-mono">{dbStatus?.host || 'in-memory'}</span></span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-400">Database: <span className="text-purple-300 font-mono">{dbStatus?.database || 'sonicspace_db'}</span></span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleTestConnection}
              disabled={testingConnection}
              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-medium flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3 h-3 ${testingConnection ? 'animate-spin' : ''}`} />
              <span>Test Connection</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex px-6 border-b border-white/10 bg-slate-900/40 text-xs overflow-x-auto">
          {[
            { id: 'console', label: 'Interactive SQL Console', icon: Terminal },
            { id: 'er_diagram', label: 'ER Diagram & Cardinality', icon: GitFork },
            { id: 'normalization', label: '1NF to 3NF Normalization', icon: Layers },
            { id: 'acid', label: 'ACID & Double-Booking Locks', icon: ShieldCheck },
            { id: 'schema_sql', label: 'DDL Schema & Seed Scripts', icon: FileCode }
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-3 px-4 font-medium flex items-center gap-2 border-b-2 transition-all cursor-pointer whitespace-nowrap ${
                  active
                    ? 'border-purple-500 text-white bg-purple-500/10'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${active ? 'text-purple-400' : 'text-slate-400'}`} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Tab Body Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#0B0B13]/80">
          {/* TAB 1: INTERACTIVE SQL CONSOLE */}
          {activeTab === 'console' && (
            <div className="space-y-4">
              {/* Preset Query Badges */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
                  Pre-Configured Academic Test Queries (Click to load & run)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                  {sampleQueries.map((item, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setQueryInput(item.sql);
                        handleRunQuery(item.sql);
                      }}
                      className="p-2.5 text-left rounded-xl bg-slate-900/70 border border-slate-800 hover:border-purple-500/50 hover:bg-purple-950/20 transition-all text-xs cursor-pointer group"
                    >
                      <span className="text-[10px] text-cyan-400 font-mono block">{item.category}</span>
                      <span className="font-medium text-slate-200 group-hover:text-white block mt-0.5">{item.title}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* SQL Query Editor */}
              <div className="rounded-xl border border-purple-500/30 overflow-hidden bg-slate-950 shadow-inner">
                <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-xs">
                  <span className="font-mono text-purple-300 flex items-center gap-1.5">
                    <Terminal className="w-3.5 h-3.5" />
                    <span>SQL Query Terminal</span>
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => copyToClipboard(queryInput, 'query')}
                      className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px] cursor-pointer"
                    >
                      {copied === 'query' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copied === 'query' ? 'Copied' : 'Copy'}</span>
                    </button>
                    <button
                      onClick={() => handleRunQuery()}
                      disabled={queryLoading}
                      className="px-3 py-1 rounded bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all cursor-pointer shadow-md shadow-purple-600/30 disabled:opacity-50"
                    >
                      {queryLoading ? (
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Play className="w-3.5 h-3.5 fill-current" />
                      )}
                      <span>Execute Query</span>
                    </button>
                  </div>
                </div>
                <textarea
                  value={queryInput}
                  onChange={e => setQueryInput(e.target.value)}
                  rows={3}
                  className="w-full p-3 bg-slate-950 text-cyan-300 font-mono text-xs focus:outline-none resize-none leading-relaxed"
                />
              </div>

              {/* Query Results / Output Table */}
              {queryError && (
                <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-mono">
                  Error: {queryError}
                </div>
              )}

              {queryResult && (
                <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-2 bg-slate-950 border-b border-slate-800 text-xs">
                    <span className="text-slate-300 font-medium">
                      Query Execution Result: <span className="text-emerald-400 font-mono">{queryResult.rowCount} rows</span> returned
                    </span>
                    <span className="text-[11px] font-mono text-purple-400">
                      ⚡ Runtime: {queryResult.executionTimeMs} ms
                    </span>
                  </div>

                  <div className="overflow-x-auto max-h-60">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-950/80 sticky top-0 border-b border-slate-800">
                        <tr>
                          {queryResult.columns.map(col => (
                            <th key={col} className="p-2.5 font-mono text-purple-300 font-semibold uppercase tracking-wider">
                              {col}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-mono text-[11px]">
                        {queryResult.rows.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-800/40 transition-colors">
                            {queryResult.columns.map(col => (
                              <td key={col} className="p-2.5 text-slate-300 whitespace-nowrap">
                                {typeof row[col] === 'object' && row[col] !== null
                                  ? JSON.stringify(row[col])
                                  : String(row[col] ?? 'NULL')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: ER DIAGRAM & CARDINALITIES */}
          {activeTab === 'er_diagram' && (
            <div className="space-y-6 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                  <GitFork className="w-4 h-4 text-purple-400" />
                  <span>Relational Entities & Key Constraints</span>
                </h3>
                <p className="text-slate-400 mb-4">
                  The SonicSpace schema is organized into 8 interconnected relational tables with rigorous primary keys (PK), foreign keys (FK) with cascade/restrict policies, and unique constraints.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 font-mono text-[11px]">
                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">1. USERS (Entity)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">Unique: <span className="text-cyan-400">email</span></p>
                    <p className="text-slate-400">Attrs: name, password_hash, role (customer/admin), phone, bio, genre_specialty</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">2. STUDIOS (Entity)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">Unique: <span className="text-cyan-400">slug</span></p>
                    <p className="text-slate-400">Attrs: name, hourly_rate, capacity, square_feet, console_type, status, rating_avg</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">3. BOOKINGS (Core Transaction Entity)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">FKs: <span className="text-purple-300">user_id -&gt; users(id)</span>, <span className="text-purple-300">studio_id -&gt; studios(id)</span></p>
                    <p className="text-slate-400">Unique: <span className="text-cyan-400">booking_reference</span></p>
                    <p className="text-slate-400">Index: (studio_id, booking_date, start_time, end_time) for overlap avoidance</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">4. BOOKING_EQUIPMENT (Bridge Entity: M:N)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">FKs: <span className="text-purple-300">booking_id -&gt; bookings(id) ON DELETE CASCADE</span>, <span className="text-purple-300">equipment_id -&gt; equipment(id)</span></p>
                    <p className="text-slate-400">Unique: (booking_id, equipment_id)</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">5. EQUIPMENT (Entity)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">Attrs: name, category, brand, model, hourly_rate, daily_rate, available_quantity</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-purple-500/20">
                    <span className="text-purple-400 font-bold block mb-1">6. PAYMENTS (Financial Ledger Entity)</span>
                    <p className="text-slate-400">PK: <span className="text-amber-400">id</span> (INT)</p>
                    <p className="text-slate-400">FK: <span className="text-purple-300">booking_id -&gt; bookings(id) ON DELETE CASCADE</span></p>
                    <p className="text-slate-400">Unique: <span className="text-cyan-400">transaction_id</span></p>
                  </div>
                </div>
              </div>

              {/* Textual Cardinality Map */}
              <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800">
                <h4 className="font-semibold text-white mb-2">Relationship Cardinalities & Business Rules:</h4>
                <ul className="space-y-1.5 list-disc pl-5 text-slate-300">
                  <li><strong className="text-white">USERS to BOOKINGS (1 : N)</strong>: A registered user can make 0 or many bookings. Each booking references exactly 1 customer.</li>
                  <li><strong className="text-white">STUDIOS to BOOKINGS (1 : N)</strong>: A studio room hosts multiple non-overlapping bookings.</li>
                  <li><strong className="text-white">BOOKINGS to EQUIPMENT (M : N via BOOKING_EQUIPMENT)</strong>: A session can reserve multiple pieces of outboard gear; each equipment item can be rented across separate sessions.</li>
                  <li><strong className="text-white">BOOKINGS to PAYMENTS (1 : 1)</strong>: Every confirmed session corresponds to a payment ledger entry recording method and settlement status.</li>
                  <li><strong className="text-white">BOOKINGS to REVIEWS (1 : 0..1)</strong>: Completed bookings are eligible for at most one verified review from the booking customer.</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 3: NORMALIZATION (1NF to 3NF) */}
          {activeTab === 'normalization' && (
            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-2">Database Normalization Proof (1NF to 3NF)</h3>
                <p className="text-slate-400 mb-3">
                  SonicSpace database tables are strictly normalized to eliminate insertion, deletion, and update anomalies.
                </p>

                <div className="space-y-3">
                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-cyan-400 block mb-1">First Normal Form (1NF) - Atomicity</span>
                    <p>All attributes contain single, atomic values. No repeating groups or non-scalar arrays exist in the relational columns. For example, instead of storing a comma-separated string of rented gear inside the <code className="text-purple-300">bookings</code> table, reservations are decomposed into separate rows in <code className="text-purple-300">booking_equipment</code>.</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-cyan-400 block mb-1">Second Normal Form (2NF) - Full Functional Dependency</span>
                    <p>The schema satisfies 1NF and contains no partial dependencies on candidate keys. In the associative entity <code className="text-purple-300">booking_equipment(booking_id, equipment_id)</code>, attributes like <code className="text-purple-300">quantity</code> and <code className="text-purple-300">hourly_rate</code> depend on the entire composite key. Static equipment details (e.g. brand, description) remain segregated in <code className="text-purple-300">equipment</code>.</p>
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-cyan-400 block mb-1">Third Normal Form (3NF) - Elimination of Transitive Dependencies</span>
                    <p>Every non-prime attribute is non-transitively dependent on the primary key ($X \rightarrow Y$ with no $Y \rightarrow Z$ where $Z$ is non-prime). For example, <code className="text-purple-300">bookings</code> only stores <code className="text-purple-300">user_id</code> and <code className="text-purple-300">studio_id</code>. It does not store customer phone numbers or studio console names directly; these are resolved at query time via SQL INNER JOINs or database Views.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ACID & DOUBLE-BOOKING CONCURRENCY */}
          {activeTab === 'acid' && (
            <div className="space-y-4 text-xs text-slate-300 leading-relaxed">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800">
                <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>ACID Concurrency & Double-Booking Prevention</span>
                </h3>
                <p className="text-slate-400 mb-3">
                  SonicSpace implements pessimistic row-locking and transaction isolation to prevent double bookings during simultaneous checkout attempts:
                </p>

                <div className="p-3 rounded-lg bg-slate-950 font-mono text-[11px] text-cyan-300 space-y-2 border border-slate-800">
                  <p className="text-purple-400">-- 1. Atomic Transaction Start</p>
                  <p>START TRANSACTION;</p>
                  <p className="text-purple-400">-- 2. Inspect Overlapping Time Intervals with Exclusive Row Lock</p>
                  <p>SELECT id, booking_reference FROM bookings</p>
                  <p>WHERE studio_id = ? AND booking_date = ?</p>
                  <p>  AND status IN ('confirmed', 'in_session', 'pending')</p>
                  <p>  AND (start_time &lt; ? AND end_time &gt; ?) FOR UPDATE;</p>
                  <p className="text-purple-400">-- 3. If any row is locked and returned: ROLLBACK and reject!</p>
                  <p className="text-purple-400">-- 4. Otherwise: INSERT booking + INSERT equipment + INSERT payment</p>
                  <p>COMMIT;</p>
                </div>

                <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-white block">Atomicity</span>
                    <span className="text-[10px] text-slate-400">All-or-nothing session reservation</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-white block">Consistency</span>
                    <span className="text-[10px] text-slate-400">Foreign keys & check constraints</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-white block">Isolation</span>
                    <span className="text-[10px] text-slate-400">Serializable schedule verification</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
                    <span className="font-bold text-white block">Durability</span>
                    <span className="text-[10px] text-slate-400">Committed to persistent storage</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SCHEMA & SEED SCRIPTS */}
          {activeTab === 'schema_sql' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">MySQL 8 DDL & Seed Scripts</h3>
                  <p className="text-xs text-slate-400">Production ready scripts located in database/schema.sql and database/seed.sql</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => copyToClipboard(schemaSql, 'schema')}
                    className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    {copied === 'schema' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied === 'schema' ? 'Copied schema.sql' : 'Copy schema.sql'}</span>
                  </button>
                  <button
                    onClick={() => copyToClipboard(seedSql, 'seed')}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    {copied === 'seed' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied === 'seed' ? 'Copied seed.sql' : 'Copy seed.sql'}</span>
                  </button>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 max-h-[50vh] overflow-y-auto whitespace-pre leading-relaxed">
                {schemaSql || '-- Loading schema.sql...'}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
