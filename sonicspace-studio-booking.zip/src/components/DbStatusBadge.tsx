import React, { useEffect, useState } from 'react';
import { Database, Server, CheckCircle2, AlertCircle } from 'lucide-react';
import { api } from '../services/api';
import { DbStatus } from '../types';

export const DbStatusBadge: React.FC<{ onClick?: () => void }> = ({ onClick }) => {
  const [status, setStatus] = useState<DbStatus | null>(null);

  useEffect(() => {
    let mounted = true;
    const fetchStatus = async () => {
      try {
        const data = await api.getDbStatus();
        if (mounted) setStatus(data);
      } catch (err) {
        console.error('Failed to fetch DB status', err);
      }
    };
    fetchStatus();
    const interval = setInterval(fetchStatus, 30000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  if (!status) return null;

  const isLive = status.mode === 'mysql' && status.connected;

  return (
    <button
      onClick={onClick}
      title="Click to open Academic DBMS Explorer & SQL Console"
      className="flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-all duration-200 cursor-pointer bg-slate-900/80 hover:bg-slate-800/90 border-purple-500/30 hover:border-purple-400/60 shadow-sm group"
    >
      <span className="relative flex h-2 w-2">
        <span
          className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
            isLive ? 'bg-emerald-400' : 'bg-cyan-400'
          }`}
        />
        <span
          className={`relative inline-flex rounded-full h-2 w-2 ${
            isLive ? 'bg-emerald-500' : 'bg-cyan-500'
          }`}
        />
      </span>

      <Database className="w-3.5 h-3.5 text-purple-400 group-hover:text-purple-300" />
      
      <span className="text-slate-300 group-hover:text-white">
        {isLive ? 'MySQL 8 Live' : 'Relational Engine (MySQL Ready)'}
      </span>

      <span className="bg-purple-900/50 text-purple-300 text-[10px] px-1.5 py-0.5 rounded border border-purple-500/20 font-mono">
        DBMS Docs
      </span>
    </button>
  );
};
