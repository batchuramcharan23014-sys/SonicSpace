export interface User {
  id: number;
  name: string;
  email: string;
  role: 'customer' | 'admin';
  phone?: string | null;
  bio?: string | null;
  genre_specialty?: string | null;
  avatar_url?: string | null;
  created_at: string;
}

export interface Studio {
  id: number;
  name: string;
  slug: string;
  tagline: string;
  description: string;
  hourly_rate: number;
  capacity: number;
  square_feet: number;
  console_type: string;
  monitoring_system: string;
  amenities: string[];
  image_url: string;
  gallery_urls?: string[];
  status: 'active' | 'maintenance' | 'inactive';
  rating_avg: number;
  review_count: number;
  created_at?: string;
}

export interface StudioAvailability {
  id: number;
  studio_id: number;
  day_of_week: number;
  open_time: string;
  close_time: string;
  is_open: boolean;
}

export interface Equipment {
  id: number;
  name: string;
  category: 'Microphones' | 'Preamps & Outboard' | 'Synthesizers & Keyboards' | 'Monitors & Headphones' | 'Instruments' | 'Audio Interfaces';
  brand: string;
  model: string;
  hourly_rate: number;
  daily_rate: number;
  total_quantity: number;
  available_quantity: number;
  description?: string;
  specs?: Record<string, string>;
  image_url: string;
  status: 'available' | 'rented' | 'maintenance' | 'retired';
  created_at?: string;
}

export interface BookingEquipment {
  id: number;
  booking_id: number;
  equipment_id: number;
  quantity: number;
  hourly_rate: number;
  total_price: number;
  equipment_name?: string;
  equipment_category?: string;
  equipment_image?: string;
}

export interface Payment {
  id: number;
  booking_id: number;
  transaction_id: string;
  amount: number;
  payment_method: 'credit_card' | 'debit_card' | 'apple_pay' | 'paypal' | 'studio_credit';
  payment_status: 'pending' | 'completed' | 'failed' | 'refunded';
  card_last4?: string | null;
  card_brand?: string | null;
  payment_date: string;
  notes?: string | null;
  booking_reference?: string;
}

export interface Review {
  id: number;
  booking_id: number;
  user_id: number;
  studio_id: number;
  rating: number;
  sound_quality_rating: number;
  cleanliness_rating: number;
  comment: string;
  created_at: string;
  user_name?: string;
  user_avatar?: string;
  studio_name?: string;
}

export interface Booking {
  id: number;
  booking_reference: string;
  user_id: number;
  studio_id: number;
  booking_date: string;
  start_time: string;
  end_time: string;
  duration_hours: number;
  session_type: string;
  studio_rate: number;
  studio_total: number;
  equipment_total: number;
  tax_amount: number;
  total_amount: number;
  special_requests?: string | null;
  engineer_required: boolean;
  status: 'pending' | 'confirmed' | 'in_session' | 'completed' | 'cancelled';
  created_at: string;
  updated_at?: string;
  customer_name?: string;
  customer_email?: string;
  customer_phone?: string;
  studio_name?: string;
  studio_image?: string;
  equipment?: BookingEquipment[];
  payment?: Payment | null;
  review?: Review | null;
}

export interface DbStatus {
  mode: 'mysql' | 'simulated';
  connected: boolean;
  host?: string;
  database?: string;
  message: string;
  counts: {
    users: number;
    studios: number;
    equipment: number;
    bookings: number;
    payments: number;
    reviews: number;
  };
}

export interface DashboardSummary {
  totalRevenue: number;
  totalStudioRevenue: number;
  totalEquipmentRevenue: number;
  totalBookings: number;
  activeBookings: number;
  completedBookings: number;
  totalCustomers: number;
  monthlyRevenue: { month: string; studio: number; equipment: number; total: number; count: number }[];
  studioDistribution: { studioId: number; studioName: string; bookingCount: number; totalRevenue: number }[];
  sessionTypeDistribution: Record<string, number>;
  topEquipment: { name: string; count: number; revenue: number }[];
}
