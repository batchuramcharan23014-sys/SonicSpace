import React from 'react';
import { Calendar, CheckCircle2, Clock, ShieldCheck, Zap, Sparkles } from 'lucide-react';
import { Studio } from '../types';

interface PricingPageProps {
  studios: Studio[];
  onOpenBooking: (studio?: Studio) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({ studios, onOpenBooking }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold">
          <Zap className="w-3.5 h-3.5" />
          <span>Transparent Studio Pricing</span>
        </div>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Hourly & Day Block Rates
        </h1>
        <p className="text-sm text-slate-400">
          All rates include full room access, private lounge, high-speed fiber internet, and standard mic locker access. Outboard rental gear and staff engineer options can be added during reservation.
        </p>
      </div>

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {studios.slice(0, 3).map((s, idx) => (
          <div
            key={s.id}
            className={`p-6 rounded-2xl border transition-all flex flex-col justify-between ${
              idx === 0
                ? 'bg-purple-950/30 border-purple-500 shadow-xl shadow-purple-900/20 relative'
                : 'bg-[#12111E] border-slate-800'
            }`}
          >
            {idx === 0 && (
              <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-600 text-white shadow-md">
                Flagship Suite
              </span>
            )}

            <div className="space-y-4">
              <div>
                <span className="text-[11px] font-mono uppercase text-cyan-400 font-semibold">{s.console_type}</span>
                <h3 className="text-xl font-bold text-white mt-0.5">{s.name}</h3>
                <p className="text-xs text-slate-300 mt-1 line-clamp-2">{s.tagline}</p>
              </div>

              <div className="pt-2 pb-4 border-b border-white/5">
                <span className="text-4xl font-extrabold font-mono text-white">${s.hourly_rate}</span>
                <span className="text-xs text-slate-400 font-normal"> / hour</span>
                <span className="text-[11px] text-purple-300 block font-mono mt-1">
                  10-Hr Day Block: ${(s.hourly_rate * 8.5).toFixed(0)} (15% Savings)
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">Included with Room:</span>
                {s.amenities.map((am, i) => (
                  <div key={i} className="flex items-center gap-2 text-slate-300">
                    <CheckCircle2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span>{am}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-6">
              <button
                onClick={() => onOpenBooking(s)}
                className={`w-full py-3 rounded-xl font-semibold text-xs transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  idx === 0
                    ? 'bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/30'
                    : 'bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Reserve {s.name.split(':')[0]}</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Operating Hours Timetable */}
      <div className="p-6 rounded-2xl bg-[#12111E] border border-purple-500/20 space-y-4">
        <div className="flex items-center gap-2">
          <Clock className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-bold text-white">Weekly Studio Operating Hours & Overtime Policy</h3>
        </div>
        <p className="text-xs text-slate-300">
          SonicSpace is open 7 days a week. Night owl and pre-production overnight blocks (midnight to 8 AM) are available upon request through the front desk.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs pt-2">
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-semibold text-purple-300 block">Monday – Thursday</span>
            <span className="text-slate-300 font-mono text-[11px]">08:00 AM – 11:00 PM</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-semibold text-purple-300 block">Friday – Saturday</span>
            <span className="text-slate-300 font-mono text-[11px]">08:00 AM – 02:00 AM</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-semibold text-purple-300 block">Sunday</span>
            <span className="text-slate-300 font-mono text-[11px]">10:00 AM – 10:00 PM</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
            <span className="font-semibold text-cyan-400 block">Staff Sound Engineers</span>
            <span className="text-slate-300 font-mono text-[11px]">Available on all shifts</span>
          </div>
        </div>
      </div>
    </div>
  );
};
