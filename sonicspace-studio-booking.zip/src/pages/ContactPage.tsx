import React, { useState } from 'react';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle2 } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('Session Inquiry');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setName('');
      setEmail('');
      setMessage('');
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
      <div className="max-w-3xl space-y-3">
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Get in Touch & Studio Load-in
        </h1>
        <p className="text-sm text-slate-400">
          Have special gear routing questions, commercial lockout requests, or heavy instrument load-in logistics? Our studio manager responds promptly.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Contact Form */}
        <div className="p-6 sm:p-8 rounded-2xl bg-[#12111E] border border-purple-500/20 shadow-xl space-y-6">
          <h3 className="text-lg font-bold text-white">Send Studio Management a Message</h3>

          {submitted ? (
            <div className="py-12 text-center space-y-2">
              <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
              <h4 className="text-base font-bold text-white">Message Received!</h4>
              <p className="text-xs text-slate-300">Our studio coordinator will get back to you within 2 business hours.</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Your Name or Artist Tag</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Alex Mercer"
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Email Address</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  placeholder="alex@producer.com"
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Inquiry Topic</label>
                <select
                  value={subject}
                  onChange={e => setSubject(e.target.value)}
                  className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                >
                  <option value="Session Inquiry">General Session Inquiry</option>
                  <option value="Commercial Lockout">Multi-Week Album Lockout</option>
                  <option value="Special Gear">Outboard Gear Rental Request</option>
                  <option value="Dolby Atmos Mixing">Dolby Atmos Spatial Mastering</option>
                  <option value="Heavy Load-in">Drum Vault & Load-in Logistics</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Message Details</label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="Describe your session vision, dates of interest, or technical requirements..."
                  className="w-full p-3 bg-slate-900 border border-slate-700 rounded-xl text-white focus:outline-none focus:border-purple-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Submit Inquiry</span>
              </button>
            </form>
          )}
        </div>

        {/* Location & Load-in Info */}
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#12111E] border border-slate-800 space-y-4 text-xs">
            <h3 className="text-base font-bold text-white">Facility Coordinates</h3>
            <div className="space-y-3 text-slate-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                <span>482 Soundwave Blvd, Recording Arts District, Los Angeles, CA 90028</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>+1 (555) 880-BEAT (2328)</span>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-violet-400 shrink-0" />
                <span>sessions@sonicspace.io</span>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Front Desk: Mon–Sun 08:00 AM – 02:00 AM</span>
              </div>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-purple-950/20 border border-purple-500/30 space-y-3 text-xs">
            <h4 className="font-bold text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>Heavy Equipment & Band Load-in Info</span>
            </h4>
            <p className="text-slate-300 leading-relaxed">
              SonicSpace features a dedicated hydraulic ramp rear loading dock with direct level access into Studio A and Studio B live tracking rooms. No stairs or narrow hallways.
            </p>
            <p className="text-slate-400">
              Please notify dispatch 30 minutes prior to arrival for rolling ramp deployment and gate access.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
