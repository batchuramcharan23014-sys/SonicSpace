import React from 'react';
import { Award, Volume2, ShieldCheck, Headphones, Zap, Music2, CheckCircle2 } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-16">
      {/* Header */}
      <div className="max-w-3xl space-y-4">
        <span className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono">
          About SonicSpace Studios
        </span>
        <h1 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight">
          Where Analog Warmth Meets Digital Precision
        </h1>
        <p className="text-sm text-slate-300 leading-relaxed">
          Founded in Los Angeles by multi-platinum recording engineers and acoustic designers, SonicSpace is built on a singular conviction: creative magic emerges when artists have access to uncompromised acoustic environments, legendary hardware, and effortless scheduling.
        </p>
      </div>

      {/* Acoustic Isolation Architecture */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-6 rounded-2xl bg-[#12111E] border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Volume2 className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Box-in-Box Decoupling</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Every tracking suite rests on independent 12-inch reinforced floating concrete slabs isolated with Sylomer elastomeric bearings, achieving -70dB ambient isolation.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#12111E] border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Headphones className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Dolby Atmos Certified 7.1.4</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Studio A is certified for immersive music spatial mixing with Smart Active Genelec monitoring, time-aligned with laser precision to meet Dolby’s strictest studio standards.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#12111E] border border-slate-800 space-y-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white">Clean Transformer Power</h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            Equipped with balanced 120V isolation transformers, eliminating ground hum and providing absolute zero-noise floors for sensitive tube preamps and ribbon microphones.
          </p>
        </div>
      </div>

      {/* Staff Engineers Roster */}
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Resident Audio Engineers</h2>
          <p className="text-xs text-slate-400 mt-1">Multi-platinum and Grammy-nominated engineering staff available for your sessions.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 flex gap-4 items-center">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80"
              alt="Marcus Vance"
              className="w-16 h-16 rounded-xl object-cover shrink-0 border border-purple-500/30"
            />
            <div>
              <h4 className="text-sm font-bold text-white">Marcus Vance</h4>
              <p className="text-[11px] text-purple-300 font-mono">Chief Studio Director</p>
              <p className="text-[10px] text-slate-400 mt-1">15+ years experience • Neve & Atmos certified</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 flex gap-4 items-center">
            <img
              src="https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80"
              alt="Elena Rostova"
              className="w-16 h-16 rounded-xl object-cover shrink-0 border border-cyan-500/30"
            />
            <div>
              <h4 className="text-sm font-bold text-white">Elena Rostova</h4>
              <p className="text-[11px] text-cyan-300 font-mono">Senior Mixing Engineer</p>
              <p className="text-[10px] text-slate-400 mt-1">Analog summing & orchestral tracking specialist</p>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 flex gap-4 items-center">
            <img
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80"
              alt="Leo Thorne"
              className="w-16 h-16 rounded-xl object-cover shrink-0 border border-purple-500/30"
            />
            <div>
              <h4 className="text-sm font-bold text-white">Leo Thorne</h4>
              <p className="text-[11px] text-purple-300 font-mono">Analog Mastering Engineer</p>
              <p className="text-[10px] text-slate-400 mt-1">Tape transfer, vinyl cuts, and digital loudness mastering</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
