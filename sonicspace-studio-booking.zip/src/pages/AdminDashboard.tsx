import React, { useState, useEffect } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  RadialLinearScale
} from 'chart.js';
import { Bar, Doughnut, Line } from 'react-chartjs-2';
import {
  LayoutDashboard,
  Sliders,
  Mic,
  Calendar,
  CreditCard,
  Users,
  Star,
  Download,
  Plus,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Search,
  Filter,
  DollarSign
} from 'lucide-react';
import { api } from '../services/api';
import { DashboardSummary, Studio, Equipment, Booking, Payment, User, Review } from '../types';

// Register ChartJS elements
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  RadialLinearScale,
  Title,
  Tooltip,
  Legend
);

export const AdminDashboard: React.FC = () => {
  const [tab, setTab] = useState<'overview' | 'studios' | 'equipment' | 'bookings' | 'payments' | 'users' | 'reviews'>('overview');
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<DashboardSummary | null>(null);

  // Collections
  const [studios, setStudios] = useState<Studio[]>([]);
  const [equipmentList, setEquipmentList] = useState<Equipment[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);

  // Studio Edit/Create Modal State
  const [studioModalOpen, setStudioModalOpen] = useState(false);
  const [editingStudio, setEditingStudio] = useState<Partial<Studio> | null>(null);

  // Equipment Edit/Create Modal State
  const [equipmentModalOpen, setEquipmentModalOpen] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState<Partial<Equipment> | null>(null);

  // Booking Status Update State
  const [statusUpdatingId, setStatusUpdatingId] = useState<number | null>(null);
  const [bookingSearch, setBookingSearch] = useState('');
  const [bookingStatusFilter, setBookingStatusFilter] = useState('all');

  const loadAllAdminData = async () => {
    try {
      setLoading(true);
      const [sumData, stdData, eqData, bkData, payData, userData, revData] = await Promise.all([
        api.getDashboardSummary(),
        api.getStudios(),
        api.getEquipment(),
        api.getBookings(),
        api.getPayments(),
        api.listUsers(),
        api.getReviews()
      ]);
      setSummary(sumData);
      setStudios(stdData);
      setEquipmentList(eqData);
      setBookings(bkData);
      setPayments(payData);
      setUsers(userData);
      setReviews(revData);
    } catch (err) {
      console.error('Failed to load admin data', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAllAdminData();
  }, []);

  // Studio CRUD
  const handleSaveStudio = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStudio) return;

    try {
      if (editingStudio.id) {
        await api.updateStudio(editingStudio.id, editingStudio);
      } else {
        await api.createStudio(editingStudio);
      }
      setStudioModalOpen(false);
      setEditingStudio(null);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to save studio');
    }
  };

  const handleDeleteStudio = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this studio?')) return;
    try {
      await api.deleteStudio(id);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete studio');
    }
  };

  // Equipment CRUD
  const handleSaveEquipment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEquipment) return;

    try {
      if (editingEquipment.id) {
        await api.updateEquipment(editingEquipment.id, editingEquipment);
      } else {
        await api.createEquipment(editingEquipment);
      }
      setEquipmentModalOpen(false);
      setEditingEquipment(null);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to save equipment');
    }
  };

  const handleDeleteEquipment = async (id: number) => {
    if (!window.confirm('Are you sure you want to delete this equipment item?')) return;
    try {
      await api.deleteEquipment(id);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to delete equipment');
    }
  };

  // Booking Status Management
  const handleUpdateBookingStatus = async (id: number, newStatus: string) => {
    setStatusUpdatingId(id);
    try {
      await api.updateBookingStatus(id, newStatus);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to update status');
    } finally {
      setStatusUpdatingId(null);
    }
  };

  // User Role Management
  const handleToggleUserRole = async (user: User) => {
    const nextRole = user.role === 'admin' ? 'customer' : 'admin';
    if (!window.confirm(`Change ${user.name}'s role to ${nextRole.toUpperCase()}?`)) return;
    try {
      await api.updateUserRole(user.id, nextRole);
      await loadAllAdminData();
    } catch (err: any) {
      alert(err.message || 'Failed to update user role');
    }
  };

  // CSV Report Export
  const handleExportCsv = () => {
    const csvHeader = 'Reference,Date,Time,DurationHrs,Studio,Customer,Email,SessionType,TotalAmount,Status\n';
    const csvRows = bookings.map(b =>
      `"${b.booking_reference}","${b.booking_date}","${b.start_time.slice(0, 5)}",${b.duration_hours},"${b.studio_name}","${b.customer_name}","${b.customer_email}","${b.session_type}",${b.total_amount},"${b.status}"`
    ).join('\n');

    const blob = new Blob([csvHeader + csvRows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sonicspace_bookings_report_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Chart Configurations
  const monthlyRevenueChartData = {
    labels: summary?.monthlyRevenue.map(m => m.month) || [],
    datasets: [
      {
        label: 'Studio Session Sales ($)',
        data: summary?.monthlyRevenue.map(m => m.studio) || [],
        backgroundColor: 'rgba(168, 85, 247, 0.75)',
        borderColor: '#A855F7',
        borderWidth: 1,
        borderRadius: 6
      },
      {
        label: 'Gear Rental Surcharges ($)',
        data: summary?.monthlyRevenue.map(m => m.equipment) || [],
        backgroundColor: 'rgba(6, 182, 212, 0.75)',
        borderColor: '#06B6D4',
        borderWidth: 1,
        borderRadius: 6
      }
    ]
  };

  const studioUtilizationChartData = {
    labels: summary?.studioDistribution.map(s => s.studioName.split(':')[0]) || [],
    datasets: [
      {
        data: summary?.studioDistribution.map(s => s.bookingCount) || [],
        backgroundColor: [
          '#A855F7',
          '#06B6D4',
          '#3B82F6',
          '#EC4899',
          '#10B981'
        ],
        borderWidth: 0
      }
    ]
  };

  const chartOptionsDark = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        labels: {
          color: '#94A3B8',
          font: { family: 'Plus Jakarta Sans', size: 11 }
        }
      }
    },
    scales: {
      x: {
        ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 } },
        grid: { color: 'rgba(255, 255, 255, 0.05)' }
      },
      y: {
        ticks: { color: '#64748B', font: { family: 'JetBrains Mono', size: 10 } },
        grid: { color: 'rgba(255, 255, 255, 0.05)' }
      }
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Admin Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              SonicSpace Management Console
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold uppercase bg-purple-950 text-purple-300 border border-purple-500/30">
              Admin Ops
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Studio schedule coordination, hardware inventory control, payment settlement audit, and Chart.js analytics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportCsv}
            className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={loadAllAdminData}
            className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 hover:text-white transition-colors cursor-pointer"
            title="Refresh All Data"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-purple-400' : ''}`} />
          </button>
        </div>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex bg-[#12111E] p-1 rounded-2xl border border-purple-500/20 text-xs overflow-x-auto shadow-md">
        {[
          { id: 'overview', label: 'Overview & Charts', icon: LayoutDashboard },
          { id: 'studios', label: `Studios (${studios.length})`, icon: Sliders },
          { id: 'equipment', label: `Equipment (${equipmentList.length})`, icon: Mic },
          { id: 'bookings', label: `Bookings (${bookings.length})`, icon: Calendar },
          { id: 'payments', label: `Payments (${payments.length})`, icon: CreditCard },
          { id: 'users', label: `Users (${users.length})`, icon: Users },
          { id: 'reviews', label: `Reviews (${reviews.length})`, icon: Star }
        ].map(item => {
          const Icon = item.icon;
          const active = tab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setTab(item.id as any)}
              className={`py-2 px-3.5 rounded-xl font-medium flex items-center gap-1.5 whitespace-nowrap transition-all cursor-pointer ${
                active
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${active ? 'text-white' : 'text-slate-500'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* ================= TAB 1: OVERVIEW & CHART.JS ANALYTICS ================= */}
      {tab === 'overview' && (
        <div className="space-y-8">
          {/* Metric KPI Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 shadow-md">
              <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Gross Booking Sales</span>
              <p className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400 mt-1">
                ${summary?.totalRevenue.toFixed(2) || '0.00'}
              </p>
              <span className="text-[10px] text-slate-400 block mt-1">
                Studio: ${summary?.totalStudioRevenue.toFixed(0)} • Gear: ${summary?.totalEquipmentRevenue.toFixed(0)}
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 shadow-md">
              <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Total Sessions</span>
              <p className="text-2xl sm:text-3xl font-extrabold font-mono text-white mt-1">
                {summary?.totalBookings || 0}
              </p>
              <span className="text-[10px] text-purple-300 block mt-1">
                {summary?.activeBookings || 0} Active / {summary?.completedBookings || 0} Completed
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 shadow-md">
              <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Studio Rooms</span>
              <p className="text-2xl sm:text-3xl font-extrabold font-mono text-cyan-400 mt-1">
                {studios.length} Active
              </p>
              <span className="text-[10px] text-slate-400 block mt-1">
                All rooms 100% operational
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-[#12111E] border border-slate-800 shadow-md">
              <span className="text-[11px] font-semibold uppercase text-slate-400 tracking-wider">Customer Accounts</span>
              <p className="text-2xl sm:text-3xl font-extrabold font-mono text-violet-400 mt-1">
                {summary?.totalCustomers || 0} Artists
              </p>
              <span className="text-[10px] text-slate-400 block mt-1">
                Registered verified producers
              </span>
            </div>
          </div>

          {/* Chart.js Visualizations Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart 1: Monthly Revenue Breakdown */}
            <div className="lg:col-span-2 p-6 rounded-2xl bg-[#12111E] border border-purple-500/20 shadow-lg space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Monthly Revenue Trends & Gear Breakdown</h3>
                  <p className="text-xs text-slate-400">Comparing studio session revenue vs outboard hardware add-ons</p>
                </div>
                <span className="text-xs font-mono text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/20">
                  Chart.js Bar
                </span>
              </div>
              <div className="h-64">
                <Bar data={monthlyRevenueChartData} options={chartOptionsDark} />
              </div>
            </div>

            {/* Chart 2: Studio Utilization Share */}
            <div className="p-6 rounded-2xl bg-[#12111E] border border-purple-500/20 shadow-lg space-y-4 flex flex-col justify-between">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">Studio Popularity</h3>
                  <p className="text-xs text-slate-400">Booking share by room</p>
                </div>
                <span className="text-xs font-mono text-cyan-300 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/20">
                  Doughnut
                </span>
              </div>
              <div className="h-52 flex items-center justify-center">
                <Doughnut
                  data={studioUtilizationChartData}
                  options={{
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                      legend: {
                        position: 'bottom',
                        labels: { color: '#94A3B8', font: { family: 'Plus Jakarta Sans', size: 10 } }
                      }
                    }
                  }}
                />
              </div>
            </div>
          </div>

          {/* Top Rented Outboard Gear */}
          <div className="p-6 rounded-2xl bg-[#12111E] border border-purple-500/20 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-white">Top Rented Studio Hardware</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              {summary?.topEquipment.map((eq, i) => (
                <div key={i} className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-1 text-xs">
                  <span className="text-slate-400 block truncate font-medium">{eq.name}</span>
                  <div className="flex justify-between items-baseline pt-1">
                    <span className="text-base font-bold font-mono text-white">{eq.count} Sessions</span>
                    <span className="font-mono text-emerald-400 font-semibold">${eq.revenue.toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 2: STUDIOS MANAGEMENT ================= */}
      {tab === 'studios' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Studio Suites & Acoustical Configuration</h2>
            <button
              onClick={() => {
                setEditingStudio({
                  name: '',
                  tagline: '',
                  description: '',
                  hourly_rate: 100,
                  capacity: 6,
                  square_feet: 400,
                  console_type: '',
                  monitoring_system: '',
                  amenities: ['Acoustically Treated', 'Pro Tools Rig'],
                  image_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=800&q=80',
                  status: 'active'
                });
                setStudioModalOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-purple-600/30"
            >
              <Plus className="w-4 h-4" />
              <span>Add New Studio Room</span>
            </button>
          </div>

          <div className="rounded-2xl bg-[#12111E] border border-purple-500/20 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5">Studio Name</th>
                    <th className="p-3.5">Console / Gear</th>
                    <th className="p-3.5">Rate / Hr</th>
                    <th className="p-3.5">Size & Cap</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {studios.map(s => (
                    <tr key={s.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="p-3.5 flex items-center gap-3">
                        <img src={s.image_url} alt={s.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                          <span className="font-bold text-white block">{s.name}</span>
                          <span className="text-[10px] text-slate-400">{s.slug}</span>
                        </div>
                      </td>
                      <td className="p-3.5">
                        <span className="font-mono text-purple-300 block">{s.console_type}</span>
                        <span className="text-[10px] text-slate-400 truncate block max-w-xs">{s.monitoring_system}</span>
                      </td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        ${s.hourly_rate}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {s.square_feet} sq ft • {s.capacity} max
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold font-mono ${
                          s.status === 'active'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-950 text-amber-300 border border-amber-500/30'
                        }`}>
                          {s.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setEditingStudio(s);
                              setStudioModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
                            title="Edit Studio"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteStudio(s.id)}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 transition-colors cursor-pointer"
                            title="Delete Studio"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: EQUIPMENT MANAGEMENT ================= */}
      {tab === 'equipment' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white">Studio Outboard Hardware & Microphones</h2>
            <button
              onClick={() => {
                setEditingEquipment({
                  name: '',
                  category: 'Microphones',
                  brand: '',
                  model: '',
                  hourly_rate: 15,
                  daily_rate: 70,
                  total_quantity: 1,
                  available_quantity: 1,
                  description: '',
                  image_url: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=600&q=80',
                  status: 'available'
                });
                setEquipmentModalOpen(true);
              }}
              className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 cursor-pointer shadow-md shadow-purple-600/30"
            >
              <Plus className="w-4 h-4" />
              <span>Add Equipment</span>
            </button>
          </div>

          <div className="rounded-2xl bg-[#12111E] border border-purple-500/20 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5">Gear Name</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Rate / Hr</th>
                    <th className="p-3.5">Inventory</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {equipmentList.map(eq => (
                    <tr key={eq.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="p-3.5 flex items-center gap-3">
                        <img src={eq.image_url} alt={eq.name} className="w-10 h-10 rounded-lg object-cover" />
                        <div>
                          <span className="font-bold text-white block">{eq.name}</span>
                          <span className="text-[10px] text-slate-400">{eq.brand} • {eq.model}</span>
                        </div>
                      </td>
                      <td className="p-3.5 font-mono text-cyan-300">
                        {eq.category}
                      </td>
                      <td className="p-3.5 font-mono font-bold text-emerald-400">
                        ${eq.hourly_rate}
                      </td>
                      <td className="p-3.5 text-slate-300">
                        {eq.available_quantity} / {eq.total_quantity} In Stock
                      </td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold font-mono ${
                          eq.status === 'available'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-950 text-amber-300 border border-amber-500/30'
                        }`}>
                          {eq.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => {
                              setEditingEquipment(eq);
                              setEquipmentModalOpen(true);
                            }}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
                            title="Edit Equipment"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteEquipment(eq.id)}
                            className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 transition-colors cursor-pointer"
                            title="Delete Equipment"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 4: BOOKINGS MANAGEMENT ================= */}
      {tab === 'bookings' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 className="text-base font-bold text-white">Studio Schedule & Session Reservations</h2>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="Search reference, artist, or studio..."
                value={bookingSearch}
                onChange={e => setBookingSearch(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
              />
              <select
                value={bookingStatusFilter}
                onChange={e => setBookingStatusFilter(e.target.value)}
                className="px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-xs text-white"
              >
                <option value="all">All Statuses</option>
                <option value="confirmed">Confirmed</option>
                <option value="in_session">In Session</option>
                <option value="completed">Completed</option>
                <option value="cancelled">Cancelled</option>
              </select>
            </div>
          </div>

          <div className="rounded-2xl bg-[#12111E] border border-purple-500/20 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5">Reference & Date</th>
                    <th className="p-3.5">Studio & Client</th>
                    <th className="p-3.5">Schedule</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Update Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {bookings
                    .filter(b => {
                      const matchSearch = b.booking_reference.toLowerCase().includes(bookingSearch.toLowerCase()) ||
                        (b.customer_name && b.customer_name.toLowerCase().includes(bookingSearch.toLowerCase())) ||
                        (b.studio_name && b.studio_name.toLowerCase().includes(bookingSearch.toLowerCase()));
                      const matchStatus = bookingStatusFilter === 'all' || b.status === bookingStatusFilter;
                      return matchSearch && matchStatus;
                    })
                    .map(b => (
                      <tr key={b.id} className="hover:bg-slate-900/60 transition-colors">
                        <td className="p-3.5">
                          <span className="font-mono font-bold text-purple-300 block">{b.booking_reference}</span>
                          <span className="text-[10px] text-slate-400">{b.booking_date}</span>
                        </td>
                        <td className="p-3.5">
                          <span className="font-bold text-white block">{b.studio_name}</span>
                          <span className="text-[10px] text-slate-400">{b.customer_name} ({b.customer_email})</span>
                        </td>
                        <td className="p-3.5 font-mono text-[11px]">
                          {b.start_time.slice(0, 5)} - {b.end_time.slice(0, 5)} ({b.duration_hours}h)
                        </td>
                        <td className="p-3.5 font-mono font-bold text-emerald-400">
                          ${b.total_amount.toFixed(2)}
                        </td>
                        <td className="p-3.5">
                          <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold font-mono ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30'
                              : b.status === 'in_session'
                              ? 'bg-cyan-950 text-cyan-300 border border-cyan-500/30 animate-pulse'
                              : b.status === 'completed'
                              ? 'bg-purple-950 text-purple-300 border border-purple-500/30'
                              : 'bg-rose-950 text-rose-300 border border-rose-500/30'
                          }`}>
                            {b.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-right">
                          <select
                            disabled={statusUpdatingId === b.id}
                            value={b.status}
                            onChange={e => handleUpdateBookingStatus(b.id, e.target.value)}
                            className="px-2 py-1 bg-slate-900 border border-slate-700 rounded text-xs text-white focus:outline-none focus:border-purple-500 cursor-pointer"
                          >
                            <option value="confirmed">Confirmed</option>
                            <option value="in_session">In Session</option>
                            <option value="completed">Completed</option>
                            <option value="cancelled">Cancelled</option>
                          </select>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 5: PAYMENTS AUDIT LEDGER ================= */}
      {tab === 'payments' && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-white">Simulated Payment Transactions & Invoices</h2>
          <div className="rounded-2xl bg-[#12111E] border border-purple-500/20 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5">Transaction ID</th>
                    <th className="p-3.5">Booking Ref</th>
                    <th className="p-3.5">Amount</th>
                    <th className="p-3.5">Method</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200 font-mono text-[11px]">
                  {payments.map(p => (
                    <tr key={p.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="p-3.5 text-cyan-300 font-semibold">{p.transaction_id}</td>
                      <td className="p-3.5 text-purple-300">{p.booking_reference}</td>
                      <td className="p-3.5 text-emerald-400 font-bold">${p.amount.toFixed(2)}</td>
                      <td className="p-3.5 text-slate-300 uppercase">{p.payment_method} ({p.card_brand || 'Card'})</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded text-[10px] uppercase font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/30">
                          {p.payment_status}
                        </span>
                      </td>
                      <td className="p-3.5 text-slate-400">{p.payment_date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 6: USERS MANAGEMENT ================= */}
      {tab === 'users' && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-white">User Accounts & Roles</h2>
          <div className="rounded-2xl bg-[#12111E] border border-purple-500/20 overflow-hidden shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 border-b border-slate-800 text-slate-400 uppercase tracking-wider font-semibold">
                  <tr>
                    <th className="p-3.5">User</th>
                    <th className="p-3.5">Email</th>
                    <th className="p-3.5">Genre Specialty</th>
                    <th className="p-3.5">Role</th>
                    <th className="p-3.5 text-right">Switch Role</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 text-slate-200">
                  {users.map(u => (
                    <tr key={u.id} className="hover:bg-slate-900/60 transition-colors">
                      <td className="p-3.5 flex items-center gap-3">
                        <img src={u.avatar_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'} alt={u.name} className="w-8 h-8 rounded-lg object-cover" />
                        <span className="font-bold text-white">{u.name}</span>
                      </td>
                      <td className="p-3.5 font-mono text-slate-300">{u.email}</td>
                      <td className="p-3.5 text-slate-400">{u.genre_specialty || 'General Producer'}</td>
                      <td className="p-3.5">
                        <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold font-mono ${
                          u.role === 'admin'
                            ? 'bg-purple-950 text-purple-300 border border-purple-500/40'
                            : 'bg-slate-800 text-slate-300'
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => handleToggleUserRole(u)}
                          className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[11px] font-medium text-slate-200 transition-colors cursor-pointer"
                        >
                          Change to {u.role === 'admin' ? 'Customer' : 'Admin'}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 7: REVIEWS ================= */}
      {tab === 'reviews' && (
        <div className="space-y-4">
          <h2 className="text-base font-bold text-white">Client Feedback & Acoustic Ratings</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {reviews.map(r => (
              <div key={r.id} className="p-4 rounded-xl bg-[#12111E] border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-bold text-white block">{r.user_name}</span>
                    <span className="text-[10px] text-purple-300">{r.studio_name}</span>
                  </div>
                  <div className="flex items-center gap-1 text-amber-400">
                    {[...Array(r.rating)].map((_, i) => (
                      <Star key={i} className="w-3 h-3 fill-amber-400" />
                    ))}
                  </div>
                </div>
                <p className="text-slate-300">{r.comment}</p>
                <div className="flex gap-4 text-[10px] text-slate-400 pt-2 border-t border-white/5">
                  <span>Sound Quality: <strong className="text-cyan-400">{r.sound_quality_rating}/5</strong></span>
                  <span>Cleanliness: <strong className="text-cyan-400">{r.cleanliness_rating}/5</strong></span>
                  <span className="ml-auto font-mono">{r.created_at.slice(0, 10)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: STUDIO ADD / EDIT */}
      {studioModalOpen && editingStudio && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#12111E] border border-purple-500/40 rounded-2xl shadow-2xl p-6 text-white glow-purple overflow-y-auto max-h-[90vh]">
            <h3 className="text-lg font-bold text-white mb-4">
              {editingStudio.id ? 'Edit Studio Suite' : 'Create New Studio Suite'}
            </h3>

            <form onSubmit={handleSaveStudio} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Studio Name</label>
                <input
                  type="text"
                  required
                  value={editingStudio.name || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Tagline</label>
                <input
                  type="text"
                  value={editingStudio.tagline || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, tagline: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Hourly Rate ($)</label>
                  <input
                    type="number"
                    required
                    value={editingStudio.hourly_rate || 0}
                    onChange={e => setEditingStudio({ ...editingStudio, hourly_rate: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Square Feet</label>
                  <input
                    type="number"
                    value={editingStudio.square_feet || 400}
                    onChange={e => setEditingStudio({ ...editingStudio, square_feet: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Max Capacity</label>
                  <input
                    type="number"
                    value={editingStudio.capacity || 6}
                    onChange={e => setEditingStudio({ ...editingStudio, capacity: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Console Model</label>
                <input
                  type="text"
                  required
                  value={editingStudio.console_type || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, console_type: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Monitoring System</label>
                <input
                  type="text"
                  value={editingStudio.monitoring_system || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, monitoring_system: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Image URL</label>
                <input
                  type="url"
                  value={editingStudio.image_url || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, image_url: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description</label>
                <textarea
                  rows={3}
                  value={editingStudio.description || ''}
                  onChange={e => setEditingStudio({ ...editingStudio, description: e.target.value })}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setStudioModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs cursor-pointer"
                >
                  Save Studio
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EQUIPMENT ADD / EDIT */}
      {equipmentModalOpen && editingEquipment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#12111E] border border-purple-500/40 rounded-2xl shadow-2xl p-6 text-white glow-purple overflow-y-auto max-h-[90vh]">
            <h3 className="text-lg font-bold text-white mb-4">
              {editingEquipment.id ? 'Edit Equipment Item' : 'Add Outboard Gear to Vault'}
            </h3>

            <form onSubmit={handleSaveEquipment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 mb-1">Equipment Name</label>
                <input
                  type="text"
                  required
                  value={editingEquipment.name || ''}
                  onChange={e => setEditingEquipment({ ...editingEquipment, name: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Category</label>
                  <select
                    value={editingEquipment.category || 'Microphones'}
                    onChange={e => setEditingEquipment({ ...editingEquipment, category: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                  >
                    <option value="Microphones">Microphones</option>
                    <option value="Preamps & Outboard">Preamps & Outboard</option>
                    <option value="Synthesizers & Keyboards">Synthesizers & Keyboards</option>
                    <option value="Monitors & Headphones">Monitors & Headphones</option>
                    <option value="Instruments">Instruments</option>
                    <option value="Audio Interfaces">Audio Interfaces</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 mb-1">Brand</label>
                  <input
                    type="text"
                    value={editingEquipment.brand || ''}
                    onChange={e => setEditingEquipment({ ...editingEquipment, brand: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-300 mb-1">Hourly Rate ($)</label>
                  <input
                    type="number"
                    required
                    value={editingEquipment.hourly_rate || 0}
                    onChange={e => setEditingEquipment({ ...editingEquipment, hourly_rate: parseFloat(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Total Quantity</label>
                  <input
                    type="number"
                    value={editingEquipment.total_quantity || 1}
                    onChange={e => setEditingEquipment({ ...editingEquipment, total_quantity: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 mb-1">Available Quantity</label>
                  <input
                    type="number"
                    value={editingEquipment.available_quantity || 1}
                    onChange={e => setEditingEquipment({ ...editingEquipment, available_quantity: parseInt(e.target.value, 10) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Image URL</label>
                <input
                  type="url"
                  value={editingEquipment.image_url || ''}
                  onChange={e => setEditingEquipment({ ...editingEquipment, image_url: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-700 rounded-lg text-white font-mono text-[11px]"
                />
              </div>

              <div>
                <label className="block text-slate-300 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={editingEquipment.description || ''}
                  onChange={e => setEditingEquipment({ ...editingEquipment, description: e.target.value })}
                  className="w-full p-2 bg-slate-900 border border-slate-700 rounded-lg text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setEquipmentModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-slate-800 text-slate-300 text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs cursor-pointer"
                >
                  Save Equipment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
