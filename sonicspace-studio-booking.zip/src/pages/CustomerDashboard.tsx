import React, { useState, useEffect } from 'react';
import { Calendar, Clock, DollarSign, Mic, AlertTriangle, CheckCircle2, Star, Ban, FileText, ChevronRight, Sparkles, User as UserIcon } from 'lucide-react';
import { Booking, Review } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { ReviewModal } from '../components/ReviewModal';

interface CustomerDashboardProps {
  onOpenBooking: () => void;
  onOpenProfile: () => void;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({ onOpenBooking, onOpenProfile }) => {
  const { user } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterTab, setFilterTab] = useState<'active' | 'completed' | 'all'>('active');

  // Review modal state
  const [reviewBooking, setReviewBooking] = useState<Booking | null>(null);
  const [cancellingId, setCancellingId] = useState<number | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);

  const loadBookings = async () => {
    try {
      setLoading(true);
      const data = await api.getBookings();
      setBookings(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, []);

  const handleCancelBooking = async (id: number) => {
    if (!window.confirm('Are you sure you want to cancel this studio booking? A simulated refund will be processed.')) {
      return;
    }
    setCancellingId(id);
    setActionMessage(null);
    try {
      const res = await api.cancelBooking(id);
      setActionMessage(`Session ${res.booking.booking_reference} was cancelled. Simulated refund processed.`);
      await loadBookings();
    } catch (err: any) {
      alert(err.message || 'Failed to cancel booking.');
    } finally {
      setCancellingId(null);
    }
  };

  // Metrics
  const activeBookings = bookings.filter(b => ['confirmed', 'in_session', 'pending'].includes(b.status));
  const completedBookings = bookings.filter(b => b.status === 'completed');
  const totalHours = bookings
    .filter(b => b.status !== 'cancelled')
    .reduce((sum, b) => sum + b.duration_hours, 0);
  const totalSpent = bookings
    .filter(b => b.status !== 'cancelled')
    .reduce((sum, b) => sum + b.total_amount, 0);

  const displayedBookings = bookings.filter(b => {
    if (filterTab === 'active') return ['confirmed', 'in_session', 'pending'].includes(b.status);
    if (filterTab === 'completed') return b.status === 'completed';
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* User Header Profile Card */}
      <div className="p-6 sm:p-8 rounded-2xl bg-[#12111E] border border-purple-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4 relative z-10">
          <img
            src={user?.avatar_url || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'}
            alt={user?.name}
            className="w-16 h-16 rounded-2xl object-cover border-2 border-purple-500/40 shadow-lg"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold text-white">{user?.name}</h1>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-purple-900/60 text-purple-300 border border-purple-500/30">
                Artist Account
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {user?.genre_specialty || 'Independent Producer'} • {user?.email}
            </p>
            {user?.bio && (
              <p className="text-xs text-slate-300 mt-2 max-w-xl italic line-clamp-1">"{user.bio}"</p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 relative z-10">
          <button
            onClick={onOpenProfile}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer"
          >
            Edit Profile
          </button>
          <button
            onClick={onOpenBooking}
            className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/30 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Calendar className="w-4 h-4" />
            <span>Book New Session</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Upcoming Sessions</span>
            <span className="text-2xl font-bold font-mono text-white">{activeBookings.length}</span>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Total Studio Time Booked</span>
            <span className="text-2xl font-bold font-mono text-cyan-300">{totalHours} Hours</span>
          </div>
        </div>

        <div className="p-5 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <DollarSign className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Total Session Investment</span>
            <span className="text-2xl font-bold font-mono text-emerald-400">${totalSpent.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {actionMessage && (
        <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Bookings Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-white">Your Scheduled Studio Sessions</h2>
          <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setFilterTab('active')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                filterTab === 'active' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Upcoming ({activeBookings.length})
            </button>
            <button
              onClick={() => setFilterTab('completed')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                filterTab === 'completed' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Completed ({completedBookings.length})
            </button>
            <button
              onClick={() => setFilterTab('all')}
              className={`px-3 py-1.5 rounded-lg font-medium transition-all cursor-pointer ${
                filterTab === 'all' ? 'bg-purple-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              All Bookings ({bookings.length})
            </button>
          </div>
        </div>

        {loading ? (
          <div className="py-16 text-center text-slate-400 text-xs">
            <span className="inline-block w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin mb-2" />
            <p>Loading your session reservations...</p>
          </div>
        ) : displayedBookings.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#12111E] border border-slate-800 space-y-3">
            <Calendar className="w-10 h-10 text-slate-600 mx-auto" />
            <h3 className="text-base font-semibold text-white">No sessions found</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto">
              You don't have any bookings in this view. Ready to record your next track?
            </p>
            <button
              onClick={onOpenBooking}
              className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md shadow-purple-600/30 transition-all cursor-pointer"
            >
              Book Studio Time
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {displayedBookings.map(booking => {
              const isEligibleCancel = ['confirmed', 'pending'].includes(booking.status);
              const isCompleted = booking.status === 'completed';
              const hasReview = Boolean(booking.review);

              return (
                <div
                  key={booking.id}
                  className="p-5 sm:p-6 rounded-2xl bg-[#12111E] border border-slate-800 hover:border-purple-500/30 transition-all shadow-md space-y-4"
                >
                  {/* Card Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-white/5">
                    <div className="flex items-center gap-3">
                      <img
                        src={booking.studio_image || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=300&q=80'}
                        alt={booking.studio_name}
                        className="w-12 h-12 rounded-xl object-cover shrink-0"
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-bold text-white">{booking.studio_name}</h3>
                          <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase ${
                            booking.status === 'confirmed'
                              ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                              : booking.status === 'completed'
                              ? 'bg-purple-950/80 text-purple-300 border border-purple-500/40'
                              : booking.status === 'cancelled'
                              ? 'bg-rose-950/80 text-rose-300 border border-rose-500/40'
                              : 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                          }`}>
                            {booking.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 font-mono mt-0.5">
                          Ref: <span className="text-purple-300 font-bold">{booking.booking_reference}</span> • {booking.session_type}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-lg font-bold font-mono text-emerald-400">${booking.total_amount.toFixed(2)}</span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {booking.payment?.payment_method?.toUpperCase()} • {booking.payment?.card_brand || 'Simulated'}
                      </span>
                    </div>
                  </div>

                  {/* Card Details Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Date & Schedule:</span>
                      <span className="font-semibold text-white">{booking.booking_date}</span>
                      <span className="text-[11px] text-purple-300 block font-mono">
                        {booking.start_time.slice(0, 5)} - {booking.end_time.slice(0, 5)}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Session Duration:</span>
                      <span className="font-semibold text-white">{booking.duration_hours} Hours</span>
                      <span className="text-[10px] text-slate-400 block">
                        {booking.engineer_required ? 'Staff Engineer Included' : 'Self-Engineered'}
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Reserved Gear:</span>
                      <span className="font-semibold text-white">
                        {booking.equipment && booking.equipment.length > 0
                          ? `${booking.equipment.length} Hardware Units`
                          : 'Standard Mic Locker'}
                      </span>
                      <span className="text-[10px] text-cyan-400 block font-mono">
                        +${booking.equipment_total.toFixed(2)} Gear Surcharge
                      </span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-slate-950/70 border border-slate-800">
                      <span className="text-[10px] text-slate-400 block">Simulated Transaction:</span>
                      <span className="font-mono text-[10px] text-slate-300 truncate block">
                        {booking.payment?.transaction_id || 'TXN_SETTLED'}
                      </span>
                      <span className="text-[10px] text-emerald-400 block">
                        Status: {booking.payment?.payment_status?.toUpperCase() || 'PAID'}
                      </span>
                    </div>
                  </div>

                  {/* Special Requests if any */}
                  {booking.special_requests && (
                    <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 text-xs text-slate-300">
                      <span className="text-slate-400 font-semibold text-[10px] uppercase block mb-0.5">Patch Notes:</span>
                      {booking.special_requests}
                    </div>
                  )}

                  {/* Existing Review or Review Trigger */}
                  {hasReview && booking.review && (
                    <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/20 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-bold text-purple-300 uppercase">Your Session Rating:</span>
                        <div className="flex items-center gap-1 text-amber-400">
                          {[...Array(booking.review.rating)].map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-amber-400" />
                          ))}
                        </div>
                      </div>
                      <p className="text-slate-300 italic">"{booking.review.comment}"</p>
                    </div>
                  )}

                  {/* Card Bottom Actions */}
                  <div className="flex items-center justify-end gap-3 pt-2">
                    {isCompleted && !hasReview && (
                      <button
                        onClick={() => setReviewBooking(booking)}
                        className="px-3.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors"
                      >
                        <Star className="w-3.5 h-3.5" />
                        <span>Leave Session Feedback</span>
                      </button>
                    )}

                    {isEligibleCancel && (
                      <button
                        disabled={cancellingId === booking.id}
                        onClick={() => handleCancelBooking(booking.id)}
                        className="px-3.5 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-rose-300 text-xs font-medium flex items-center gap-1.5 cursor-pointer transition-colors disabled:opacity-50"
                      >
                        <Ban className="w-3.5 h-3.5" />
                        <span>{cancellingId === booking.id ? 'Cancelling...' : 'Cancel Reservation'}</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Feedback Modal */}
      {reviewBooking && (
        <ReviewModal
          isOpen={true}
          onClose={() => setReviewBooking(null)}
          booking={reviewBooking}
          onReviewSubmitted={() => {
            loadBookings();
            setReviewBooking(null);
          }}
        />
      )}
    </div>
  );
};
