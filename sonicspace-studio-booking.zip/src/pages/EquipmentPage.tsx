import React, { useState } from 'react';
import { Search, Mic, Sliders, Music, Headphones, Volume2, ShieldCheck, CheckCircle2, AlertCircle, Calendar } from 'lucide-react';
import { Equipment } from '../types';

interface EquipmentPageProps {
  equipment: Equipment[];
  onOpenBooking: () => void;
}

export const EquipmentPage: React.FC<EquipmentPageProps> = ({ equipment, onOpenBooking }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [search, setSearch] = useState<string>('');

  const categories = [
    { id: 'all', label: 'All Equipment' },
    { id: 'Microphones', label: 'Microphones' },
    { id: 'Preamps & Outboard', label: 'Preamps & Outboard' },
    { id: 'Synthesizers & Keyboards', label: 'Synthesizers & Keys' },
    { id: 'Audio Interfaces', label: 'Audio Interfaces' },
    { id: 'Monitors & Headphones', label: 'Monitors & Cans' },
    { id: 'Instruments', label: 'Instruments & Drums' }
  ];

  const filtered = equipment.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(search.toLowerCase()) ||
      item.brand.toLowerCase().includes(search.toLowerCase()) ||
      item.model.toLowerCase().includes(search.toLowerCase()) ||
      (item.description && item.description.toLowerCase().includes(search.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Outboard Equipment & Microphone Vault
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl">
            Rent pristine vintage tube microphones, legendary analog summing gear, and rare hardware synthesizers for your recording and mixing sessions.
          </p>
        </div>
        <button
          onClick={onOpenBooking}
          className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/30 transition-all flex items-center gap-2 cursor-pointer self-start md:self-auto"
        >
          <Calendar className="w-4 h-4" />
          <span>Book Session With Gear</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-[#12111E] border border-purple-500/20 space-y-4">
        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by brand (Neumann, Sony, Moog, Avalon, API), model, or gear description..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap gap-2 pt-1">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'bg-slate-900/80 text-slate-300 hover:text-white border border-slate-800'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Equipment Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(item => (
          <div
            key={item.id}
            className="rounded-2xl bg-[#12111E] border border-slate-800 hover:border-purple-500/40 transition-all duration-300 overflow-hidden flex flex-col justify-between group shadow-lg"
          >
            <div>
              {/* Image & Category Badge */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={item.image_url}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#12111E] via-transparent to-black/20" />
                
                <span className="absolute top-3 left-3 text-[10px] font-semibold uppercase px-2.5 py-1 rounded-full bg-black/70 backdrop-blur-md text-cyan-300 border border-cyan-500/30 font-mono">
                  {item.category}
                </span>

                <div className="absolute top-3 right-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase font-mono ${
                    item.status === 'available'
                      ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-950/80 text-amber-300 border border-amber-500/40'
                  }`}>
                    {item.available_quantity > 0 ? `${item.available_quantity} In Vault` : 'Reserved'}
                  </span>
                </div>
              </div>

              {/* Item Info */}
              <div className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-mono text-purple-300">{item.brand}</span>
                    <h3 className="text-base font-bold text-white group-hover:text-purple-300 transition-colors">
                      {item.name}
                    </h3>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="text-lg font-bold font-mono text-white">${item.hourly_rate}</span>
                    <span className="text-[10px] text-slate-400 block">/ hour</span>
                  </div>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed line-clamp-2">
                  {item.description}
                </p>

                {/* Specs Pill List */}
                {item.specs && Object.keys(item.specs).length > 0 && (
                  <div className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] space-y-1">
                    {Object.entries(item.specs).slice(0, 3).map(([k, v]) => (
                      <div key={k} className="flex justify-between text-slate-400">
                        <span className="truncate pr-2">{k}:</span>
                        <span className="text-slate-200 font-mono truncate">{String(v)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Bottom Controls */}
            <div className="p-5 pt-0 flex items-center justify-between">
              <span className="text-[11px] text-slate-400 font-mono">
                Full Day: <strong className="text-slate-200">${item.daily_rate}</strong>
              </span>
              <button
                onClick={onOpenBooking}
                className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs shadow-md shadow-purple-600/20 transition-all cursor-pointer flex items-center gap-1.5"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Reserve For Session</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
