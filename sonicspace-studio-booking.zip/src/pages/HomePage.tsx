import React from 'react';
import { Calendar, Sliders, Mic, Sparkles, Star, ShieldCheck, ArrowRight, Music, Headphones, Volume2, Award, Zap } from 'lucide-react';
import { Studio, Equipment } from '../types';
import { AudioWaveform } from '../components/AudioWaveform';

interface HomePageProps {
  studios: Studio[];
  equipment: Equipment[];
  onOpenBooking: (studio?: Studio) => void;
  onNavigate: (view: string) => void;
  onSelectStudio: (studio: Studio) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  studios,
  equipment,
  onOpenBooking,
  onNavigate,
  onSelectStudio
}) => {
  return (
    <div className="space-y-24">
      {/* HERO SECTION */}
      <section className="relative pt-12 pb-20 md:pt-20 md:pb-32 overflow-hidden">
        {/* Glow & Lighting Effects */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-purple-600/15 rounded-full blur-[140px] pointer-events-none" />
        <div className="absolute top-1/3 left-1/4 w-[400px] h-[400px] bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto space-y-6">
            {/* Pulsing Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-purple-950/60 border border-purple-500/40 text-purple-300 text-xs font-medium shadow-md shadow-purple-950/50">
              <span className="flex h-2 w-2 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500" />
              </span>
              <span>Flagship Dolby Atmos 7.1.4 & Analog Tracking</span>
              <AudioWaveform active={true} className="ml-1" />
            </div>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-[1.08]">
              Sculpt Your Sonic <br />
              <span className="bg-gradient-to-r from-purple-400 via-violet-300 to-cyan-400 bg-clip-text text-transparent">
                Masterpiece
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-2xl mx-auto font-normal">
              Book world-class acoustic tracking rooms, legendary Neve, API, and SSL consoles, and vintage outboard hardware with real-time double-booking prevention.
            </p>

            {/* Hero CTAs */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <button
                onClick={() => onOpenBooking()}
                className="w-full sm:w-auto px-8 py-4 rounded-xl bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-xl shadow-purple-600/30 transition-all transform hover:-translate-y-0.5 flex items-center justify-center gap-2.5 cursor-pointer"
              >
                <Calendar className="w-4 h-4" />
                <span>Reserve Studio Session</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onNavigate('studios')}
                className="w-full sm:w-auto px-6 py-4 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700/80 text-slate-200 hover:text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Sliders className="w-4 h-4 text-purple-400" />
                <span>Explore 5 Studio Rooms</span>
              </button>
            </div>

            {/* Quick Feature Badges */}
            <div className="pt-8 flex flex-wrap items-center justify-center gap-6 sm:gap-10 text-xs font-mono text-slate-400">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Pessimistic Double-Booking Locks</span>
              </div>
              <div className="flex items-center gap-2">
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>-70dB Floating Acoustic Isolation</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Instant Simulated Stripe Settlement</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* METRIC HIGHLIGHTS STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-6 rounded-2xl bg-slate-900/40 border border-purple-500/20 backdrop-blur-md">
          <div className="text-center p-3">
            <p className="text-3xl sm:text-4xl font-extrabold font-mono text-purple-400">5</p>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mt-1">Dedicated Studios</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Neve, SSL, API & Atmos</p>
          </div>
          <div className="text-center p-3 border-l border-white/5">
            <p className="text-3xl sm:text-4xl font-extrabold font-mono text-cyan-400">150+</p>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mt-1">Vintage Outboard Units</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Neumann, Sony C800G, Moog</p>
          </div>
          <div className="text-center p-3 border-l border-white/5">
            <p className="text-3xl sm:text-4xl font-extrabold font-mono text-violet-400">4.93</p>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mt-1">Average Star Rating</p>
            <p className="text-[11px] text-slate-400 mt-0.5">From 140+ verified sessions</p>
          </div>
          <div className="text-center p-3 border-l border-white/5">
            <p className="text-3xl sm:text-4xl font-extrabold font-mono text-emerald-400">100%</p>
            <p className="text-xs text-slate-400 uppercase tracking-wider font-semibold mt-1">ACID Schedule Guard</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Zero double-booking guarantee</p>
          </div>
        </div>
      </section>

      {/* FEATURED STUDIOS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-500/10 text-purple-400 text-xs font-semibold mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Flagship Tracking Suites</span>
            </div>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">World-Class Recording Environments</h2>
            <p className="text-sm text-slate-400 mt-1">Acoustically calibrated by Northward Acoustics and Walters-Storyk Design Group</p>
          </div>
          <button
            onClick={() => onNavigate('studios')}
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-1.5 transition-colors cursor-pointer self-start md:self-auto"
          >
            <span>View All Studio Rates & Specs</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {studios.slice(0, 3).map(studio => (
            <div
              key={studio.id}
              className="rounded-2xl bg-[#12111E] border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 overflow-hidden flex flex-col group hover:shadow-xl hover:shadow-purple-900/20"
            >
              {/* Studio Thumbnail */}
              <div className="relative h-56 overflow-hidden">
                <img
                  src={studio.image_url}
                  alt={studio.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#12111E] via-transparent to-black/30" />
                
                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-black/60 backdrop-blur-md text-cyan-300 border border-cyan-500/30 font-mono">
                    {studio.square_feet} sq ft • {studio.capacity} Artists
                  </span>
                </div>

                <div className="absolute top-3 right-3 flex items-center gap-1 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-md text-amber-400 text-xs font-bold font-mono">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                  <span>{studio.rating_avg.toFixed(2)}</span>
                </div>

                <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
                  <span className="text-xs font-medium text-purple-300 font-mono bg-purple-950/80 px-2 py-0.5 rounded border border-purple-500/30">
                    {studio.console_type}
                  </span>
                  <span className="text-xl font-bold font-mono text-white">
                    ${studio.hourly_rate}<span className="text-xs text-slate-400 font-normal">/hr</span>
                  </span>
                </div>
              </div>

              {/* Studio Info */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-lg font-bold text-white group-hover:text-purple-300 transition-colors">
                    {studio.name}
                  </h3>
                  <p className="text-xs text-slate-300 line-clamp-2 mt-1">
                    {studio.tagline}
                  </p>
                </div>

                {/* Amenities Badges */}
                <div className="flex flex-wrap gap-1.5">
                  {studio.amenities.slice(0, 3).map((am, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-300">
                      {am}
                    </span>
                  ))}
                  {studio.amenities.length > 3 && (
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                      +{studio.amenities.length - 3}
                    </span>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 pt-2 border-t border-white/5">
                  <button
                    onClick={() => onSelectStudio(studio)}
                    className="flex-1 py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer text-center"
                  >
                    View Room Specs
                  </button>
                  <button
                    onClick={() => onOpenBooking(studio)}
                    className="flex-1 py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold shadow-md shadow-purple-600/20 transition-all cursor-pointer text-center flex items-center justify-center gap-1.5"
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Book Session</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURED EQUIPMENT PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-xs font-semibold mb-2">
              <Mic className="w-3.5 h-3.5" />
              <span>Vintage & Modern Hardware</span>
            </div>
            <h2 className="text-3xl font-extrabold text-white tracking-tight">Outboard Gear & Microphone Vault</h2>
            <p className="text-sm text-slate-400 mt-1">Reserve precision analog outboard gear along with your studio session</p>
          </div>
          <button
            onClick={() => onNavigate('equipment')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors cursor-pointer self-start md:self-auto"
          >
            <span>Explore Complete Gear Vault</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {equipment.slice(0, 4).map(item => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-[#12111E] border border-slate-800 hover:border-purple-500/40 transition-all duration-200 flex flex-col justify-between group"
            >
              <div>
                <div className="relative h-40 rounded-xl overflow-hidden mb-3">
                  <img
                    src={item.image_url}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <span className="absolute top-2 left-2 text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-black/70 backdrop-blur-md text-cyan-300 border border-cyan-500/20">
                    {item.category}
                  </span>
                </div>
                <h4 className="text-sm font-semibold text-white group-hover:text-purple-300 transition-colors line-clamp-1">
                  {item.name}
                </h4>
                <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                  {item.description}
                </p>
              </div>

              <div className="pt-3 border-t border-white/5 flex items-center justify-between mt-4">
                <div>
                  <span className="text-[10px] text-slate-400 block">Session Rental</span>
                  <span className="text-sm font-bold font-mono text-purple-300">${item.hourly_rate}/hr</span>
                </div>
                <button
                  onClick={() => onOpenBooking()}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-purple-600/30 border border-slate-700 hover:border-purple-500/40 text-xs font-medium text-slate-200 hover:text-white transition-colors cursor-pointer"
                >
                  Reserve
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* WHY ARTISTS CHOOSE SONICSPACE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-[#131124] to-[#0D0B18] border border-purple-500/30 relative overflow-hidden">
          <div className="max-w-2xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono">
              Engineered for Sonic Perfection
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white">
              No Latency. No Compromises. Guaranteed Availability.
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed">
              Every room at SonicSpace features decoupled floating concrete slabs, variable bass traps, dedicated clean transformer power lines, and staff engineers certified on Avid Pro Tools HDX and Dolby Atmos RMUs.
            </p>
            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => onOpenBooking()}
                className="px-6 py-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/25 transition-all cursor-pointer"
              >
                Schedule Your Next Hit Session
              </button>
              <button
                onClick={() => onNavigate('about')}
                className="px-5 py-3 rounded-xl bg-slate-900 border border-slate-700 text-slate-200 text-xs font-medium hover:text-white transition-colors cursor-pointer"
              >
                Read Acoustic Whitepaper
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
