import React, { useState } from 'react';
import { Search, Sliders, Calendar, Star, Users, Maximize, Mic, CheckCircle2, Clock, X, ChevronRight } from 'lucide-react';
import { Studio, StudioAvailability, Review } from '../types';
import { api } from '../services/api';

interface StudiosPageProps {
  studios: Studio[];
  onOpenBooking: (studio?: Studio) => void;
  selectedStudioDetail: Studio | null;
  onSelectStudioDetail: (studio: Studio | null) => void;
}

export const StudiosPage: React.FC<StudiosPageProps> = ({
  studios,
  onOpenBooking,
  selectedStudioDetail,
  onSelectStudioDetail
}) => {
  const [search, setSearch] = useState('');
  const [consoleFilter, setConsoleFilter] = useState('all');
  const [maxPrice, setMaxPrice] = useState<number>(200);

  // Detail drawer state
  const [detailReviews, setDetailReviews] = useState<Review[]>([]);
  const [detailAvailability, setDetailAvailability] = useState<StudioAvailability[]>([]);
  const [loadingDetail, setLoadingDetail] = useState<boolean>(false);

  const handleOpenDetail = async (studio: Studio) => {
    onSelectStudioDetail(studio);
    setLoadingDetail(true);
    try {
      const [resStudio, reviews] = await Promise.all([
        api.getStudio(studio.id),
        api.getReviews(studio.id)
      ]);
      setDetailAvailability(resStudio.availability);
      setDetailReviews(reviews);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingDetail(false);
    }
  };

  const filteredStudios = studios.filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(search.toLowerCase()) ||
      s.console_type.toLowerCase().includes(search.toLowerCase()) ||
      s.tagline.toLowerCase().includes(search.toLowerCase()) ||
      s.description.toLowerCase().includes(search.toLowerCase());

    const matchesConsole = consoleFilter === 'all' || s.console_type.toLowerCase().includes(consoleFilter.toLowerCase());
    const matchesPrice = s.hourly_rate <= maxPrice;

    return matchesSearch && matchesConsole && matchesPrice;
  });

  const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Page Header */}
      <div className="space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Recording Studios & Mixing Suites
        </h1>
        <p className="text-sm text-slate-400 max-w-2xl">
          Five surgically isolated acoustic environments equipped with legendary analog consoles, Dolby Atmos spatial audio rigs, and verified availability.
        </p>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 rounded-2xl bg-[#12111E] border border-purple-500/20 shadow-lg space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-4 items-center">
          {/* Keyword Search */}
          <div className="sm:col-span-2 relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search studio by name, console (Neve, SSL, API), or features..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
          </div>

          {/* Console Type Selector */}
          <div>
            <select
              value={consoleFilter}
              onChange={e => setConsoleFilter(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-900 border border-slate-700 rounded-xl text-xs sm:text-sm text-white focus:outline-none focus:border-purple-500"
            >
              <option value="all">All Console Types</option>
              <option value="neve">Neve (88RS / Discrete)</option>
              <option value="api">API (Discrete Analog)</option>
              <option value="ssl">Solid State Logic (SSL)</option>
              <option value="apollo">Universal Audio Apollo</option>
              <option value="grace">Grace Design Preamp</option>
            </select>
          </div>

          {/* Max Price Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Max Hourly Rate:</span>
              <span className="font-mono text-purple-300 font-bold">${maxPrice}/hr</span>
            </div>
            <input
              type="range"
              min="60"
              max="200"
              step="5"
              value={maxPrice}
              onChange={e => setMaxPrice(parseInt(e.target.value, 10))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Studios Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {filteredStudios.map(studio => (
          <div
            key={studio.id}
            className="rounded-2xl bg-[#12111E] border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 overflow-hidden flex flex-col group shadow-lg"
          >
            {/* Studio Hero Image & Header Badges */}
            <div className="relative h-64 overflow-hidden">
              <img
                src={studio.image_url}
                alt={studio.name}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#12111E] via-transparent to-black/40" />

              <div className="absolute top-3 left-3 flex flex-wrap gap-2">
                <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-black/60 backdrop-blur-md text-cyan-300 border border-cyan-500/30 font-mono">
                  {studio.square_feet} sq ft
                </span>
                <span className="px-2.5 py-1 rounded-full text-[10px] font-semibold uppercase tracking-wider bg-black/60 backdrop-blur-md text-slate-200 border border-white/20 font-mono">
                  Up to {studio.capacity} People
                </span>
              </div>

              <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-black/60 backdrop-blur-md text-amber-400 text-xs font-bold font-mono">
                <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>{studio.rating_avg.toFixed(2)}</span>
                <span className="text-[10px] text-slate-400 font-normal">({studio.review_count})</span>
              </div>

              <div className="absolute bottom-4 left-4 right-4 flex justify-between items-end">
                <div>
                  <h3 className="text-xl font-bold text-white group-hover:text-purple-300 transition-colors">
                    {studio.name}
                  </h3>
                  <p className="text-xs text-purple-300 font-medium font-mono mt-0.5">
                    {studio.console_type}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-2xl font-bold font-mono text-emerald-400">${studio.hourly_rate}</span>
                  <span className="text-xs text-slate-400">/hr</span>
                </div>
              </div>
            </div>

            {/* Studio Body Content */}
            <div className="p-6 flex-1 flex flex-col justify-between space-y-5">
              <p className="text-xs text-slate-300 leading-relaxed">
                {studio.description}
              </p>

              {/* Monitoring System Info */}
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
                <span className="text-[10px] text-slate-400 uppercase font-semibold block mb-0.5">Reference Monitoring:</span>
                <span className="text-slate-200 font-medium">{studio.monitoring_system}</span>
              </div>

              {/* Amenities Grid */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-semibold uppercase text-slate-400 tracking-wider">Features & Isolation:</span>
                <div className="flex flex-wrap gap-1.5">
                  {studio.amenities.map((am, i) => (
                    <span key={i} className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900/90 border border-slate-800 text-slate-300 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 text-cyan-400 shrink-0" />
                      <span>{am}</span>
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-white/5 flex items-center gap-3">
                <button
                  onClick={() => handleOpenDetail(studio)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 hover:text-white transition-all cursor-pointer text-center"
                >
                  Full Specs & Reviews
                </button>
                <button
                  onClick={() => onOpenBooking(studio)}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/25 transition-all cursor-pointer text-center flex items-center justify-center gap-1.5"
                >
                  <Calendar className="w-4 h-4" />
                  <span>Reserve Session</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* DETAIL MODAL / DRAWER */}
      {selectedStudioDetail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md overflow-y-auto">
          <div className="relative w-full max-w-3xl bg-[#12111E] border border-purple-500/30 rounded-2xl shadow-2xl text-white glow-purple overflow-hidden my-auto max-h-[85vh] flex flex-col">
            {/* Top Modal Bar */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-slate-900/80">
              <div>
                <h3 className="text-lg font-bold text-white">{selectedStudioDetail.name}</h3>
                <p className="text-xs text-slate-400">{selectedStudioDetail.tagline}</p>
              </div>
              <button
                onClick={() => onSelectStudioDetail(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Scroll Content */}
            <div className="p-6 overflow-y-auto space-y-6">
              {/* Photo Showcase */}
              <div className="h-60 rounded-xl overflow-hidden relative">
                <img
                  src={selectedStudioDetail.image_url}
                  alt={selectedStudioDetail.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute bottom-3 left-3 bg-black/70 backdrop-blur-md px-3 py-1 rounded-lg text-xs font-mono text-purple-300 border border-purple-500/30">
                  ${selectedStudioDetail.hourly_rate}/hr • {selectedStudioDetail.square_feet} sq ft
                </div>
              </div>

              {/* Description */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">Acoustic Overview</h4>
                <p className="text-xs text-slate-300 leading-relaxed">{selectedStudioDetail.description}</p>
              </div>

              {/* Technical Specifications */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Mixing & Tracking Console:</span>
                  <span className="text-white font-medium">{selectedStudioDetail.console_type}</span>
                </div>
                <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
                  <span className="text-[10px] text-slate-400 uppercase font-semibold block">Monitoring Calibration:</span>
                  <span className="text-white font-medium">{selectedStudioDetail.monitoring_system}</span>
                </div>
              </div>

              {/* Operating Hours Timetable */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Regular Studio Operating Hours</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                  {detailAvailability.map(a => (
                    <div key={a.id} className="p-2 rounded-lg bg-slate-950 border border-slate-800">
                      <span className="text-purple-300 font-semibold block text-[11px]">{daysOfWeek[a.day_of_week]}</span>
                      <span className="text-[10px] text-slate-400">
                        {a.open_time.slice(0, 5)} - {a.close_time.slice(0, 5)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Client Reviews Section */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    Verified Artist Reviews ({detailReviews.length})
                  </h4>
                  <div className="flex items-center gap-1 text-xs text-amber-400 font-bold font-mono">
                    <Star className="w-3.5 h-3.5 fill-amber-400" />
                    <span>{selectedStudioDetail.rating_avg.toFixed(2)} Avg</span>
                  </div>
                </div>

                {detailReviews.length === 0 ? (
                  <p className="text-xs text-slate-500 italic p-3 rounded-lg bg-slate-900/40">No reviews recorded yet for this room.</p>
                ) : (
                  <div className="space-y-3">
                    {detailReviews.map(r => (
                      <div key={r.id} className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-white">{r.user_name}</span>
                            <span className="text-[10px] text-slate-400">• {r.created_at.slice(0, 10)}</span>
                          </div>
                          <div className="flex items-center gap-1 text-amber-400">
                            {[...Array(r.rating)].map((_, i) => (
                              <Star key={i} className="w-3 h-3 fill-amber-400" />
                            ))}
                          </div>
                        </div>
                        <p className="text-slate-300">{r.comment}</p>
                        <div className="flex gap-4 text-[10px] text-slate-400 pt-1 border-t border-white/5">
                          <span>Acoustics: <strong className="text-cyan-400">{r.sound_quality_rating}/5</strong></span>
                          <span>Cleanliness: <strong className="text-cyan-400">{r.cleanliness_rating}/5</strong></span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Modal Bottom CTA */}
            <div className="p-4 border-t border-white/10 bg-slate-900/80 flex items-center justify-between">
              <span className="text-lg font-bold font-mono text-white">
                ${selectedStudioDetail.hourly_rate}<span className="text-xs text-slate-400 font-normal">/hr</span>
              </span>
              <button
                onClick={() => {
                  const s = selectedStudioDetail;
                  onSelectStudioDetail(null);
                  onOpenBooking(s);
                }}
                className="px-6 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs shadow-lg shadow-purple-600/30 transition-all cursor-pointer flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>Book This Room</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
