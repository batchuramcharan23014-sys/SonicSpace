import { Router, Response } from 'express';
import { dbPayments } from '../db';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/payments (Admin lists all payments)
router.get('/', verifyToken, requireAdmin, async (_req: AuthRequest, res: Response) => {
  try {
    const payments = await dbPayments.listAll();
    res.json(payments);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/payments/booking/:bookingId
router.get('/booking/:bookingId', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const bookingId = parseInt(req.params.bookingId, 10);
    const payment = await dbPayments.findByBookingId(bookingId);
    if (!payment) {
      res.status(404).json({ error: 'Payment transaction record not found.' });
      return;
    }
    res.json(payment);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/payments/simulate-checkout
router.post('/simulate-checkout', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const { amount, paymentMethod, cardDetails } = req.body;

    if (!amount || amount <= 0) {
      res.status(400).json({ error: 'Valid amount is required.' });
      return;
    }

    // Simulate 200ms processing delay
    await new Promise(resolve => setTimeout(resolve, 350));

    const txnId = `TXN_SONIC_${Date.now().toString().slice(-8)}${Math.floor(10 + Math.random() * 90)}`;
    const cardLast4 = cardDetails?.cardNumber ? cardDetails.cardNumber.slice(-4) : (paymentMethod === 'apple_pay' ? '8819' : '4242');

    res.json({
      success: true,
      transactionId: txnId,
      amount: parseFloat(amount),
      paymentMethod: paymentMethod || 'credit_card',
      cardLast4,
      cardBrand: cardDetails?.cardNumber?.startsWith('5') ? 'Mastercard' : (paymentMethod === 'apple_pay' ? 'Apple Card' : 'Visa'),
      timestamp: new Date().toISOString()
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
