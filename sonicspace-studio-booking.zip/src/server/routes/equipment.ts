import { Router, Response } from 'express';
import { dbEquipment } from '../db';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/equipment
router.get('/', async (req, res: Response) => {
  try {
    const { category, status, search } = req.query;
    const items = await dbEquipment.listAll({
      category: category as string,
      status: status as string,
      search: search as string
    });
    res.json(items);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/equipment/:id
router.get('/:id', async (req, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const item = await dbEquipment.findById(id);
    if (!item) {
      res.status(404).json({ error: 'Equipment item not found.' });
      return;
    }
    res.json(item);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/equipment (Admin only)
router.post('/', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { name, category, brand, model, hourlyRate, dailyRate, totalQuantity, availableQuantity, description, specs, imageUrl, status } = req.body;

    if (!name || !category || !hourlyRate) {
      res.status(400).json({ error: 'Name, category, and hourly rate are required.' });
      return;
    }

    const newEquip = await dbEquipment.create({
      name: name.trim(),
      category,
      brand: brand?.trim() || 'Custom',
      model: model?.trim() || 'MK I',
      hourly_rate: parseFloat(hourlyRate),
      daily_rate: parseFloat(dailyRate || hourlyRate * 5),
      total_quantity: parseInt(totalQuantity, 10) || 1,
      available_quantity: parseInt(availableQuantity ?? totalQuantity, 10) || 1,
      description: description?.trim() || '',
      specs: specs || {},
      image_url: imageUrl?.trim() || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=600&q=80',
      status: status || 'available'
    });

    res.status(201).json({ message: 'Equipment added successfully!', equipment: newEquip });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/equipment/:id (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const updates = req.body;

    if (updates.hourlyRate !== undefined) updates.hourly_rate = parseFloat(updates.hourlyRate);
    if (updates.dailyRate !== undefined) updates.daily_rate = parseFloat(updates.dailyRate);
    if (updates.totalQuantity !== undefined) updates.total_quantity = parseInt(updates.totalQuantity, 10);
    if (updates.availableQuantity !== undefined) updates.available_quantity = parseInt(updates.availableQuantity, 10);
    if (updates.imageUrl !== undefined) updates.image_url = updates.imageUrl;

    const updated = await dbEquipment.update(id, updates);
    if (!updated) {
      res.status(404).json({ error: 'Equipment not found.' });
      return;
    }

    res.json({ message: 'Equipment updated successfully!', equipment: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/equipment/:id (Admin only)
router.delete('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    await dbEquipment.delete(id);
    res.json({ message: 'Equipment removed successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
