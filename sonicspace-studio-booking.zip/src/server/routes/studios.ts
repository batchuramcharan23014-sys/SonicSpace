import { Router, Response } from 'express';
import { dbStudios, dbBookings } from '../db';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/studios
router.get('/', async (req, res: Response) => {
  try {
    const { status, minRate, maxRate, search } = req.query;
    const studios = await dbStudios.listAll({
      status: status as string,
      minRate: minRate ? parseFloat(minRate as string) : undefined,
      maxRate: maxRate ? parseFloat(maxRate as string) : undefined,
      search: search as string
    });
    res.json(studios);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/studios/:idOrSlug
router.get('/:idOrSlug', async (req, res: Response) => {
  try {
    const param = req.params.idOrSlug;
    let studio = null;

    if (/^\d+$/.test(param)) {
      studio = await dbStudios.findById(parseInt(param, 10));
    } else {
      studio = await dbStudios.findBySlug(param);
    }

    if (!studio) {
      res.status(404).json({ error: 'Studio not found.' });
      return;
    }

    const availability = await dbStudios.getAvailability(studio.id);
    res.json({ studio, availability });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/studios/:id/schedule?date=YYYY-MM-DD
router.get('/:id/schedule', async (req, res: Response) => {
  try {
    const studioId = parseInt(req.params.id, 10);
    const date = (req.query.date as string) || new Date().toISOString().slice(0, 10);

    const studio = await dbStudios.findById(studioId);
    if (!studio) {
      res.status(404).json({ error: 'Studio not found.' });
      return;
    }

    const bookedSlots = await dbBookings.getStudioBookingsForDate(studioId, date);
    const formattedSlots = bookedSlots.map(b => ({
      bookingId: b.id,
      startTime: b.start_time.slice(0, 5),
      endTime: b.end_time.slice(0, 5),
      durationHours: b.duration_hours,
      status: b.status
    }));

    res.json({
      studioId,
      date,
      bookedSlots: formattedSlots
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/studios (Admin only)
router.post('/', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const { name, tagline, description, hourlyRate, capacity, squareFeet, consoleType, monitoringSystem, amenities, imageUrl, galleryUrls, status } = req.body;

    if (!name || !hourlyRate || !consoleType) {
      res.status(400).json({ error: 'Studio name, hourly rate, and console type are required.' });
      return;
    }

    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Date.now().toString().slice(-4);

    const newStudio = await dbStudios.create({
      name: name.trim(),
      slug,
      tagline: tagline?.trim() || 'Professional Recording Suite',
      description: description?.trim() || '',
      hourly_rate: parseFloat(hourlyRate),
      capacity: parseInt(capacity, 10) || 6,
      square_feet: parseInt(squareFeet, 10) || 450,
      console_type: consoleType.trim(),
      monitoring_system: monitoringSystem?.trim() || 'Active Reference Monitors',
      amenities: Array.isArray(amenities) ? amenities : ['Acoustically Treated', 'Pro Tools Rig', 'Wi-Fi'],
      image_url: imageUrl?.trim() || 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1200&q=80',
      gallery_urls: Array.isArray(galleryUrls) ? galleryUrls : [],
      status: status || 'active'
    });

    res.status(201).json({ message: 'Studio created successfully!', studio: newStudio });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/studios/:id (Admin only)
router.put('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const updates = req.body;

    if (updates.hourlyRate !== undefined) updates.hourly_rate = parseFloat(updates.hourlyRate);
    if (updates.capacity !== undefined) updates.capacity = parseInt(updates.capacity, 10);
    if (updates.squareFeet !== undefined) updates.square_feet = parseInt(updates.squareFeet, 10);
    if (updates.consoleType !== undefined) updates.console_type = updates.consoleType;
    if (updates.monitoringSystem !== undefined) updates.monitoring_system = updates.monitoringSystem;
    if (updates.imageUrl !== undefined) updates.image_url = updates.imageUrl;

    const updated = await dbStudios.update(id, updates);
    if (!updated) {
      res.status(404).json({ error: 'Studio not found.' });
      return;
    }

    res.json({ message: 'Studio updated successfully!', studio: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/studios/:id (Admin only)
router.delete('/:id', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    await dbStudios.delete(id);
    res.json({ message: 'Studio removed successfully.' });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
