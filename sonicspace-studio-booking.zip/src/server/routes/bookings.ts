import { Router, Response } from 'express';
import { dbBookings, dbStudios } from '../db';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/bookings (List bookings: admins see all, customers see own)
router.get('/', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const user = req.user!;
    const { studioId, status, date } = req.query;

    const filter: any = {};
    if (user.role !== 'admin') {
      filter.userId = user.id;
    }
    if (studioId) filter.studioId = parseInt(studioId as string, 10);
    if (status) filter.status = status as string;
    if (date) filter.date = date as string;

    const bookings = await dbBookings.listAll(filter);
    res.json(bookings);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/bookings/:id
router.get('/:id', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const booking = await dbBookings.findById(id);

    if (!booking) {
      res.status(404).json({ error: 'Booking reservation not found.' });
      return;
    }

    if (req.user!.role !== 'admin' && booking.user_id !== req.user!.id) {
      res.status(403).json({ error: 'Unauthorized to view this booking.' });
      return;
    }

    res.json(booking);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/bookings/check-availability
router.post('/check-availability', async (req, res: Response) => {
  try {
    const { studioId, date, startTime, durationHours } = req.body;

    if (!studioId || !date || !startTime || !durationHours) {
      res.status(400).json({ error: 'studioId, date, startTime, and durationHours are required.' });
      return;
    }

    const dur = parseInt(durationHours, 10);
    const [startH, startM] = startTime.split(':').map((n: string) => parseInt(n, 10));
    const endH = startH + dur;
    const endTime = `${String(endH).padStart(2, '0')}:${String(startM || 0).padStart(2, '0')}`;

    const studio = await dbStudios.findById(parseInt(studioId, 10));
    if (!studio) {
      res.status(404).json({ error: 'Studio not found.' });
      return;
    }

    const conflicts = await dbBookings.checkConflicts(studio.id, date, startTime, endTime);
    const isAvailable = conflicts.length === 0;

    res.json({
      available: isAvailable,
      studioId: studio.id,
      studioName: studio.name,
      requestedSlot: { date, startTime, endTime, durationHours: dur },
      conflicts: conflicts.map(c => ({
        bookingRef: c.booking_reference,
        startTime: c.start_time.slice(0, 5),
        endTime: c.end_time.slice(0, 5),
        status: c.status
      })),
      hourlyRate: studio.hourly_rate,
      estimatedStudioTotal: studio.hourly_rate * dur
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/bookings (Create booking with transaction)
router.post('/', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const {
      studioId,
      date,
      startTime,
      durationHours,
      sessionType,
      engineerRequired,
      specialRequests,
      equipmentItems,
      paymentMethod,
      cardLast4,
      cardBrand
    } = req.body;

    if (!studioId || !date || !startTime || !durationHours) {
      res.status(400).json({ error: 'Studio ID, date, start time, and duration are required.' });
      return;
    }

    const dur = parseInt(durationHours, 10);
    const [startH, startM] = startTime.split(':').map((n: string) => parseInt(n, 10));
    const endH = startH + dur;
    const endTime = `${String(endH).padStart(2, '0')}:${String(startM || 0).padStart(2, '0')}`;

    const booking = await dbBookings.createBookingTransaction({
      userId: req.user!.id,
      studioId: parseInt(studioId, 10),
      date,
      startTime,
      endTime,
      durationHours: dur,
      sessionType: sessionType || 'Tracking / Recording',
      engineerRequired: Boolean(engineerRequired),
      specialRequests,
      equipmentIds: Array.isArray(equipmentItems) ? equipmentItems : [],
      paymentMethod: paymentMethod || 'credit_card',
      cardLast4,
      cardBrand
    });

    res.status(201).json({
      message: 'Booking successfully confirmed! Your session is scheduled.',
      booking
    });
  } catch (err: any) {
    res.status(409).json({ error: err.message || 'Booking transaction failed.' });
  }
});

// PUT /api/bookings/:id/status (Admin only)
router.put('/:id/status', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { status } = req.body;

    if (!['pending', 'confirmed', 'in_session', 'completed', 'cancelled'].includes(status)) {
      res.status(400).json({ error: 'Invalid booking status.' });
      return;
    }

    const updated = await dbBookings.updateStatus(id, status);
    if (!updated) {
      res.status(404).json({ error: 'Booking not found.' });
      return;
    }

    res.json({ message: `Booking status updated to ${status}.`, booking: updated });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/bookings/:id/cancel
router.post('/:id/cancel', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const isAdmin = req.user!.role === 'admin';
    const booking = await dbBookings.cancelBooking(id, req.user!.id, isAdmin);

    res.json({
      message: 'Booking session cancelled successfully. Simulated refund processed.',
      booking
    });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
