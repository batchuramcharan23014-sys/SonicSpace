import { Router, Response } from 'express';
import { dbReports, dbBookings } from '../db';
import { verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/reports/dashboard (Admin Dashboard analytics for Chart.js)
router.get('/dashboard', verifyToken, requireAdmin, async (_req: AuthRequest, res: Response) => {
  try {
    const summary = await dbReports.getDashboardSummary();
    res.json(summary);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/reports/export (Admin CSV export for bookings)
router.get('/export', verifyToken, requireAdmin, async (_req: AuthRequest, res: Response) => {
  try {
    const bookings = await dbBookings.listAll();
    const csvHeader = 'Reference,Date,Time,DurationHrs,Studio,Customer,Email,SessionType,StudioTotal,EquipmentTotal,TotalAmount,Status\n';
    const csvRows = bookings.map(b => 
      `"${b.booking_reference}","${b.booking_date}","${b.start_time.slice(0,5)}","${b.duration_hours}","${b.studio_name}","${b.customer_name}","${b.customer_email}","${b.session_type}",${b.studio_total},${b.equipment_total},${b.total_amount},"${b.status}"`
    ).join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="sonicspace_bookings_report.csv"');
    res.send(csvHeader + csvRows);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
