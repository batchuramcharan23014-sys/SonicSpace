import { Router, Request, Response } from 'express';
import { getDbStatus, runAcademicQuery, initDatabaseConnection } from '../db';
import fs from 'fs';
import path from 'path';

const router = Router();

// GET /api/system/db-status
router.get('/db-status', async (_req: Request, res: Response) => {
  const status = await getDbStatus();
  res.json(status);
});

// POST /api/system/test-connection
router.post('/test-connection', async (_req: Request, res: Response) => {
  const connected = await initDatabaseConnection();
  const status = await getDbStatus();
  res.json({
    connected,
    status
  });
});

// POST /api/system/run-query (Academic DBMS SQL query runner)
router.post('/run-query', async (req: Request, res: Response) => {
  try {
    const { query } = req.body;
    if (!query || typeof query !== 'string') {
      res.status(400).json({ error: 'SQL query string is required.' });
      return;
    }

    const result = await runAcademicQuery(query);
    res.json({
      success: true,
      query,
      columns: result.columns,
      rows: result.rows,
      rowCount: result.rows.length,
      executionTimeMs: result.executionTimeMs
    });
  } catch (err: any) {
    res.status(400).json({
      success: false,
      error: err.message
    });
  }
});

// GET /api/system/docs
router.get('/docs', (_req: Request, res: Response) => {
  try {
    const docPath = path.resolve(process.cwd(), 'database/DBMS_DOCUMENTATION.md');
    if (fs.existsSync(docPath)) {
      const content = fs.readFileSync(docPath, 'utf-8');
      res.json({ markdown: content });
    } else {
      res.json({ markdown: '# SonicSpace Database Documentation\nAvailable in repository.' });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/system/schema-sql
router.get('/schema-sql', (_req: Request, res: Response) => {
  try {
    const schemaPath = path.resolve(process.cwd(), 'database/schema.sql');
    const seedPath = path.resolve(process.cwd(), 'database/seed.sql');
    const schemaSql = fs.existsSync(schemaPath) ? fs.readFileSync(schemaPath, 'utf-8') : '';
    const seedSql = fs.existsSync(seedPath) ? fs.readFileSync(seedPath, 'utf-8') : '';

    res.json({ schemaSql, seedSql });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
