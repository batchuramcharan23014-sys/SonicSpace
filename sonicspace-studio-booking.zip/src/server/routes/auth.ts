import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { dbUsers } from '../db';
import { signToken, verifyToken, requireAdmin, AuthRequest } from '../middleware/auth';

const router = Router();

// POST /api/auth/register
router.post('/register', async (req, res: Response) => {
  try {
    const { name, email, password, role, phone, genreSpecialty, bio } = req.body;

    if (!name || !email || !password) {
      res.status(400).json({ error: 'Name, email, and password are required.' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ error: 'Password must be at least 6 characters long.' });
      return;
    }

    const existing = await dbUsers.findByEmail(email);
    if (existing) {
      res.status(409).json({ error: 'An account with this email address already exists.' });
      return;
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const assignedRole = role === 'admin' ? 'admin' : 'customer';

    const newUser = await dbUsers.create({
      name: name.trim(),
      email: email.trim().toLowerCase(),
      password_hash: passwordHash,
      role: assignedRole,
      phone: phone?.trim() || null,
      genre_specialty: genreSpecialty?.trim() || 'General Music Production',
      bio: bio?.trim() || '',
      avatar_url: `https://images.unsplash.com/photo-${assignedRole === 'admin' ? '1534528741775-53994a69daeb' : '1535713875002-d1d0cf377fde'}?auto=format&fit=crop&w=300&q=80`
    });

    const token = signToken(newUser);
    const { password_hash, ...safeUser } = newUser;

    res.status(201).json({
      message: 'Account created successfully!',
      token,
      user: safeUser
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Registration failed.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: 'Email and password are required.' });
      return;
    }

    const user = await dbUsers.findByEmail(email);
    if (!user) {
      res.status(401).json({ error: 'Invalid email address or password.' });
      return;
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      res.status(401).json({ error: 'Invalid email address or password.' });
      return;
    }

    const token = signToken(user);
    const { password_hash, ...safeUser } = user;

    res.json({
      message: 'Logged in successfully!',
      token,
      user: safeUser
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Login failed.' });
  }
});

// GET /api/auth/me
router.get('/me', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const user = await dbUsers.findById(req.user!.id);
    if (!user) {
      res.status(404).json({ error: 'User profile not found.' });
      return;
    }
    const { password_hash, ...safeUser } = user;
    res.json({ user: safeUser });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/auth/profile
router.put('/profile', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const { name, phone, bio, genreSpecialty, avatarUrl } = req.body;
    const updated = await dbUsers.update(req.user!.id, {
      ...(name && { name: name.trim() }),
      ...(phone !== undefined && { phone }),
      ...(bio !== undefined && { bio }),
      ...(genreSpecialty !== undefined && { genre_specialty: genreSpecialty }),
      ...(avatarUrl !== undefined && { avatar_url: avatarUrl })
    });

    if (!updated) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }
    const { password_hash, ...safeUser } = updated;
    res.json({ message: 'Profile updated successfully!', user: safeUser });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/auth/users (Admin only)
router.get('/users', verifyToken, requireAdmin, async (_req: AuthRequest, res: Response) => {
  try {
    const users = await dbUsers.listAll();
    res.json(users);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /api/auth/users/:id/role (Admin only)
router.put('/users/:id/role', verifyToken, requireAdmin, async (req: AuthRequest, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    const { role } = req.body;
    if (!['customer', 'admin'].includes(role)) {
      res.status(400).json({ error: 'Invalid role.' });
      return;
    }

    const updated = await dbUsers.update(id, { role });
    if (!updated) {
      res.status(404).json({ error: 'User not found.' });
      return;
    }

    const { password_hash, ...safeUser } = updated;
    res.json({ message: 'User role updated.', user: safeUser });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
