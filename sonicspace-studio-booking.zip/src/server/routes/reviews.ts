import { Router, Response } from 'express';
import { dbReviews } from '../db';
import { verifyToken, AuthRequest } from '../middleware/auth';

const router = Router();

// GET /api/reviews
router.get('/', async (req, res: Response) => {
  try {
    const studioId = req.query.studioId ? parseInt(req.query.studioId as string, 10) : undefined;
    const reviews = await dbReviews.listAll(studioId);
    res.json(reviews);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/reviews (Customer submits review for completed booking)
router.post('/', verifyToken, async (req: AuthRequest, res: Response) => {
  try {
    const { bookingId, rating, soundQualityRating, cleanlinessRating, comment } = req.body;

    if (!bookingId || !rating || !comment) {
      res.status(400).json({ error: 'bookingId, rating (1-5), and review comment are required.' });
      return;
    }

    const newReview = await dbReviews.create({
      bookingId: parseInt(bookingId, 10),
      userId: req.user!.id,
      rating: Math.min(5, Math.max(1, parseInt(rating, 10))),
      soundQualityRating: Math.min(5, Math.max(1, parseInt(soundQualityRating || rating, 10))),
      cleanlinessRating: Math.min(5, Math.max(1, parseInt(cleanlinessRating || rating, 10))),
      comment: comment.trim()
    });

    res.status(201).json({ message: 'Review submitted successfully! Thank you for your feedback.', review: newReview });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
