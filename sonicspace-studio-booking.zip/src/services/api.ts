import { User, Studio, StudioAvailability, Equipment, Booking, Payment, Review, DbStatus, DashboardSummary } from '../types';

const API_BASE = '/api';

function getAuthHeaders(): HeadersInit {
  const token = localStorage.getItem('sonicspace_token');
  const headers: HeadersInit = {
    'Content-Type': 'application/json'
  };
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  return headers;
}

async function handleResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const errorMsg = data.error || data.message || `Request failed with status ${res.status}`;
    throw new Error(errorMsg);
  }
  return data as T;
}

export const api = {
  // Auth
  async register(body: { name: string; email: string; password: string; role?: string; phone?: string; genreSpecialty?: string; bio?: string }) {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    return handleResponse<{ message: string; token: string; user: User }>(res);
  },

  async login(email: string, password: string) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    return handleResponse<{ message: string; token: string; user: User }>(res);
  },

  async getCurrentUser() {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: getAuthHeaders()
    });
    return handleResponse<{ user: User }>(res);
  },

  async updateProfile(updates: Partial<User>) {
    const res = await fetch(`${API_BASE}/auth/profile`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates)
    });
    return handleResponse<{ message: string; user: User }>(res);
  },

  async listUsers() {
    const res = await fetch(`${API_BASE}/auth/users`, {
      headers: getAuthHeaders()
    });
    return handleResponse<User[]>(res);
  },

  async updateUserRole(id: number, role: 'customer' | 'admin') {
    const res = await fetch(`${API_BASE}/auth/users/${id}/role`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ role })
    });
    return handleResponse<{ message: string; user: User }>(res);
  },

  // Studios
  async getStudios(params?: { status?: string; minRate?: number; maxRate?: number; search?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.status) searchParams.append('status', params.status);
    if (params?.minRate !== undefined) searchParams.append('minRate', params.minRate.toString());
    if (params?.maxRate !== undefined) searchParams.append('maxRate', params.maxRate.toString());
    if (params?.search) searchParams.append('search', params.search);

    const qs = searchParams.toString();
    const res = await fetch(`${API_BASE}/studios${qs ? `?${qs}` : ''}`);
    return handleResponse<Studio[]>(res);
  },

  async getStudio(idOrSlug: string | number) {
    const res = await fetch(`${API_BASE}/studios/${idOrSlug}`);
    return handleResponse<{ studio: Studio; availability: StudioAvailability[] }>(res);
  },

  async getStudioSchedule(studioId: number, date: string) {
    const res = await fetch(`${API_BASE}/studios/${studioId}/schedule?date=${date}`);
    return handleResponse<{ studioId: number; date: string; bookedSlots: { startTime: string; endTime: string; durationHours: number; status: string }[] }>(res);
  },

  async createStudio(studio: Partial<Studio>) {
    const res = await fetch(`${API_BASE}/studios`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(studio)
    });
    return handleResponse<{ message: string; studio: Studio }>(res);
  },

  async updateStudio(id: number, updates: Partial<Studio>) {
    const res = await fetch(`${API_BASE}/studios/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates)
    });
    return handleResponse<{ message: string; studio: Studio }>(res);
  },

  async deleteStudio(id: number) {
    const res = await fetch(`${API_BASE}/studios/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return handleResponse<{ message: string }>(res);
  },

  // Equipment
  async getEquipment(params?: { category?: string; status?: string; search?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.append('category', params.category);
    if (params?.status) searchParams.append('status', params.status);
    if (params?.search) searchParams.append('search', params.search);

    const qs = searchParams.toString();
    const res = await fetch(`${API_BASE}/equipment${qs ? `?${qs}` : ''}`);
    return handleResponse<Equipment[]>(res);
  },

  async createEquipment(equipment: Partial<Equipment>) {
    const res = await fetch(`${API_BASE}/equipment`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(equipment)
    });
    return handleResponse<{ message: string; equipment: Equipment }>(res);
  },

  async updateEquipment(id: number, updates: Partial<Equipment>) {
    const res = await fetch(`${API_BASE}/equipment/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(updates)
    });
    return handleResponse<{ message: string; equipment: Equipment }>(res);
  },

  async deleteEquipment(id: number) {
    const res = await fetch(`${API_BASE}/equipment/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders()
    });
    return handleResponse<{ message: string }>(res);
  },

  // Bookings
  async checkAvailability(studioId: number, date: string, startTime: string, durationHours: number) {
    const res = await fetch(`${API_BASE}/bookings/check-availability`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ studioId, date, startTime, durationHours })
    });
    return handleResponse<{
      available: boolean;
      studioId: number;
      studioName: string;
      requestedSlot: { date: string; startTime: string; endTime: string; durationHours: number };
      conflicts: any[];
      hourlyRate: number;
      estimatedStudioTotal: number;
    }>(res);
  },

  async getBookings(params?: { studioId?: number; status?: string; date?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.studioId) searchParams.append('studioId', params.studioId.toString());
    if (params?.status) searchParams.append('status', params.status);
    if (params?.date) searchParams.append('date', params.date);

    const qs = searchParams.toString();
    const res = await fetch(`${API_BASE}/bookings${qs ? `?${qs}` : ''}`, {
      headers: getAuthHeaders()
    });
    return handleResponse<Booking[]>(res);
  },

  async createBooking(data: {
    studioId: number;
    date: string;
    startTime: string;
    durationHours: number;
    sessionType: string;
    engineerRequired: boolean;
    specialRequests?: string;
    equipmentItems?: { equipmentId: number; quantity: number }[];
    paymentMethod: string;
    cardLast4?: string;
    cardBrand?: string;
  }) {
    const res = await fetch(`${API_BASE}/bookings`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return handleResponse<{ message: string; booking: Booking }>(res);
  },

  async updateBookingStatus(id: number, status: string) {
    const res = await fetch(`${API_BASE}/bookings/${id}/status`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify({ status })
    });
    return handleResponse<{ message: string; booking: Booking }>(res);
  },

  async cancelBooking(id: number) {
    const res = await fetch(`${API_BASE}/bookings/${id}/cancel`, {
      method: 'POST',
      headers: getAuthHeaders()
    });
    return handleResponse<{ message: string; booking: Booking }>(res);
  },

  // Payments
  async getPayments() {
    const res = await fetch(`${API_BASE}/payments`, {
      headers: getAuthHeaders()
    });
    return handleResponse<Payment[]>(res);
  },

  async simulateCheckout(amount: number, paymentMethod: string, cardDetails?: any) {
    const res = await fetch(`${API_BASE}/payments/simulate-checkout`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify({ amount, paymentMethod, cardDetails })
    });
    return handleResponse<{ success: boolean; transactionId: string; amount: number; paymentMethod: string; cardLast4?: string; cardBrand?: string }>(res);
  },

  // Reviews
  async getReviews(studioId?: number) {
    const qs = studioId ? `?studioId=${studioId}` : '';
    const res = await fetch(`${API_BASE}/reviews${qs}`);
    return handleResponse<Review[]>(res);
  },

  async createReview(data: { bookingId: number; rating: number; soundQualityRating: number; cleanlinessRating: number; comment: string }) {
    const res = await fetch(`${API_BASE}/reviews`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(data)
    });
    return handleResponse<{ message: string; review: Review }>(res);
  },

  // Reports
  async getDashboardSummary() {
    const res = await fetch(`${API_BASE}/reports/dashboard`, {
      headers: getAuthHeaders()
    });
    return handleResponse<DashboardSummary>(res);
  },

  // System & Academic DBMS
  async getDbStatus() {
    const res = await fetch(`${API_BASE}/system/db-status`);
    return handleResponse<DbStatus>(res);
  },

  async testDbConnection() {
    const res = await fetch(`${API_BASE}/system/test-connection`, { method: 'POST' });
    return handleResponse<{ connected: boolean; status: DbStatus }>(res);
  },

  async runQuery(query: string) {
    const res = await fetch(`${API_BASE}/system/run-query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query })
    });
    return handleResponse<{ success: boolean; query: string; columns: string[]; rows: any[]; rowCount: number; executionTimeMs: number; error?: string }>(res);
  },

  async getSchemaSql() {
    const res = await fetch(`${API_BASE}/system/schema-sql`);
    return handleResponse<{ schemaSql: string; seedSql: string }>(res);
  },

  async getDbmsDocs() {
    const res = await fetch(`${API_BASE}/system/docs`);
    return handleResponse<{ markdown: string }>(res);
  }
};
