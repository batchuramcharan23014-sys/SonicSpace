import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { StudiosPage } from './pages/StudiosPage';
import { EquipmentPage } from './pages/EquipmentPage';
import { PricingPage } from './pages/PricingPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { CustomerDashboard } from './pages/CustomerDashboard';
import { AdminDashboard } from './pages/AdminDashboard';
import { BookingModal } from './components/BookingModal';
import { AuthModal } from './components/AuthModal';
import { ProfileModal } from './components/ProfileModal';
import { DbmsExplorerModal } from './components/DbmsExplorerModal';
import { Studio, Equipment } from './types';
import { api } from './services/api';

function MainApp() {
  const { user, isAuthenticated, isAdmin } = useAuth();

  // Navigation state: 'home' | 'studios' | 'equipment' | 'pricing' | 'about' | 'contact' | 'customer' | 'admin'
  const [currentView, setCurrentView] = useState<string>('home');

  // Modals state
  const [bookingModalOpen, setBookingModalOpen] = useState<boolean>(false);
  const [selectedStudioForBooking, setSelectedStudioForBooking] = useState<Studio | null>(null);

  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register'>('login');

  const [profileModalOpen, setProfileModalOpen] = useState<boolean>(false);
  const [dbmsModalOpen, setDbmsModalOpen] = useState<boolean>(false);

  // Studio detail state
  const [selectedStudioDetail, setSelectedStudioDetail] = useState<Studio | null>(null);

  // Global data
  const [studios, setStudios] = useState<Studio[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [stdList, eqList] = await Promise.all([
          api.getStudios(),
          api.getEquipment()
        ]);
        setStudios(stdList);
        setEquipment(eqList);
      } catch (err) {
        console.error('Failed to pre-fetch studio data', err);
      }
    };
    fetchData();
  }, []);

  const handleOpenBooking = (studio?: Studio) => {
    setSelectedStudioForBooking(studio || null);
    setBookingModalOpen(true);
  };

  const handleOpenAuth = (mode: 'login' | 'register' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleNavigate = (view: string) => {
    if (view === 'customer' && !isAuthenticated) {
      handleOpenAuth('login');
      return;
    }
    if (view === 'admin' && !isAdmin) {
      if (!isAuthenticated) {
        handleOpenAuth('login');
      } else {
        alert('Access denied: Administrator privileges required.');
      }
      return;
    }
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0B0B13] text-slate-100 antialiased">
      {/* Navigation Bar */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenBooking={() => handleOpenBooking()}
        onOpenAuth={handleOpenAuth}
        onOpenProfile={() => setProfileModalOpen(true)}
        onOpenDbms={() => setDbmsModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomePage
            studios={studios}
            equipment={equipment}
            onOpenBooking={handleOpenBooking}
            onNavigate={handleNavigate}
            onSelectStudio={studio => {
              setSelectedStudioDetail(studio);
              setCurrentView('studios');
            }}
          />
        )}

        {currentView === 'studios' && (
          <StudiosPage
            studios={studios}
            onOpenBooking={handleOpenBooking}
            selectedStudioDetail={selectedStudioDetail}
            onSelectStudioDetail={setSelectedStudioDetail}
          />
        )}

        {currentView === 'equipment' && (
          <EquipmentPage
            equipment={equipment}
            onOpenBooking={() => handleOpenBooking()}
          />
        )}

        {currentView === 'pricing' && (
          <PricingPage
            studios={studios}
            onOpenBooking={handleOpenBooking}
          />
        )}

        {currentView === 'about' && <AboutPage />}

        {currentView === 'contact' && <ContactPage />}

        {currentView === 'customer' && (
          <CustomerDashboard
            onOpenBooking={() => handleOpenBooking()}
            onOpenProfile={() => setProfileModalOpen(true)}
          />
        )}

        {currentView === 'admin' && <AdminDashboard />}
      </main>

      {/* Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenDbms={() => setDbmsModalOpen(true)}
      />

      {/* Booking Modal */}
      <BookingModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        selectedStudio={selectedStudioForBooking}
        onBookingSuccess={() => {
          // If on customer page, reload bookings
        }}
        onOpenAuth={() => {
          setBookingModalOpen(false);
          handleOpenAuth('login');
        }}
      />

      {/* Auth Modal (Login / Register) */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authModalMode}
      />

      {/* Profile Settings Modal */}
      <ProfileModal
        isOpen={profileModalOpen}
        onClose={() => setProfileModalOpen(false)}
      />

      {/* Academic DBMS Explorer & Interactive SQL Console Modal */}
      <DbmsExplorerModal
        isOpen={dbmsModalOpen}
        onClose={() => setDbmsModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
