-- ====================================================================
-- SonicSpace Music Recording Studio & Equipment Booking Management System
-- Seed Data Script (DML)
-- ====================================================================

USE sonicspace_db;

-- --------------------------------------------------------------------
-- 1. Insert Users (Password is 'password123' hashed with bcrypt)
-- Hash for 'password123': $2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O
-- --------------------------------------------------------------------
INSERT INTO users (id, name, email, password_hash, role, phone, bio, genre_specialty, avatar_url) VALUES
(1, 'Marcus Vance', 'admin@sonicspace.io', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'admin', '+1 (555) 234-5678', 'Chief Audio Engineer & Studio Director with 15+ years of multi-platinum tracking and Dolby Atmos experience.', 'Audio Engineering / Mastering', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80'),
(2, 'Elena Rostova', 'elena.admin@sonicspace.io', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'admin', '+1 (555) 345-6789', 'Senior Mixing Engineer specializing in analog summing, Neve acoustics, and orchestral scoring.', 'Mix Engineering & Orchestral', 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=300&q=80'),
(3, 'Damian Cruz', 'damian@producer.com', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'customer', '+1 (555) 987-6543', 'Grammy-nominated hip-hop and R&B music producer based in LA/NYC.', 'Hip-Hop, Trap, R&B', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80'),
(4, 'Seraphina Lin', 'seraphina@indieartist.org', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'customer', '+1 (555) 876-5432', 'Indie-pop singer-songwriter and multi-instrumentalist recording her second studio LP.', 'Indie Pop & Dream Pop', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80'),
(5, 'Julian Reed', 'julian@heavyriff.net', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'customer', '+1 (555) 765-4321', 'Lead guitarist and sound designer for progressive rock & metal band Apex Zero.', 'Alternative Rock & Prog Metal', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80'),
(6, 'Chloe Bennet', 'chloe.podcasts@streamline.com', '$2b$10$ve9RkEXzP6zd/RgliuqtUeKkfEpDqmEip2hlXSBSZdAA3BpzU6x8O', 'customer', '+1 (555) 654-3210', 'Audio drama host and voice actor producing top-charting narrative investigative series.', 'Voiceover, Podcast & Audio Drama', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80');

-- --------------------------------------------------------------------
-- 2. Insert Studios
-- --------------------------------------------------------------------
INSERT INTO studios (id, name, slug, tagline, description, hourly_rate, capacity, square_feet, console_type, monitoring_system, amenities, image_url, status, rating_avg, review_count) VALUES
(1, 'Studio A: The Neon Chamber', 'studio-a-neon-chamber', 'Flagship Dolby Atmos Tracking & Live Room', 
'Our crown jewel recording environment featuring an expansive 900 sq ft double-height live tracking room with variable acoustic baffles, Steinway Model D concert grand piano, and a world-class Neve 88RS 48-channel console. Tuned specifically for full band tracking, strings, and immersive mix sessions.',
150.00, 12, 900, 'Neve 88RS 48-Channel Custom', 'Genelec 7.1.4 Dolby Atmos Smart Active Monitors + ATC SCM110ASL Mains',
JSON_ARRAY('Private Green Room', 'Steinway Model D Concert Grand', 'Dolby Atmos 7.1.4 Certified', 'Full Drum Isolation Vault', 'High-speed Fiber WiFi', 'Nespresso Coffee Bar', 'Dedicated Vocal Isolation Booth'),
'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1200&q=80', 'active', 4.95, 38),

(2, 'Studio B: Velvet Horizon', 'studio-b-velvet-horizon', 'Warm Vintage Tube Tracking & Mixing Suite',
'An intimate, vibey analog sanctuary wrapped in walnut diffuser panels and velvet acoustic curtains. Powered by an API 1608-II console and vintage Telefunken and Fairchild tube gear, this room produces the unmistakable warmth of timeless records.',
110.00, 6, 520, 'API 1608-II 16-Channel Discrete Analog', 'Focal Trio11 Be & Yamaha NS-10M Studio Classics',
JSON_ARRAY('Vintage Tube Outboard Rack', 'Hammond B3 Organ with Leslie 122', 'Separate Overdub Booth', 'Turntable Listening Lounge', 'Analog 2-inch 24-Track Tape Option'),
'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80', 'active', 4.88, 26),

(3, 'Studio C: Electric Violet Mix Lab', 'studio-c-electric-violet', 'Precision Hybrid Mixing & Mastering Suite',
'Surgically calibrated acoustic room with Northward Acoustics zero-reflection geometry. Outfitted with SSL Duality Delta console, Crane Song HEDD Quantum converters, and PMC monitoring. Perfect for high-stakes single and album mastering.',
95.00, 4, 380, 'Solid State Logic (SSL) Duality Delta', 'PMC result6 + Bryston Amp System & Subwoofer',
JSON_ARRAY('Calibrated Mastering Chain', 'Crane Song & Weiss Digital Processing', '4K Reference Monitor Displays', 'Motorized Standing/Sitting Desks', 'Silent AC System'),
'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=1200&q=80', 'active', 4.92, 19),

(4, 'Studio D: The Beat Foundry', 'studio-d-beat-foundry', 'Modern Beatmaking & Electronic Production Hub',
'Designed ground-up for hip-hop, electronic, and pop producers. Features wall-to-wall hardware synthesizers (Moog, Prophet, Roland), Akai MPC X, Native Instruments Maschine, and wall-shaking Augspurger subwoofers for true low-end response.',
80.00, 5, 410, 'Custom Universal Audio Apollo x16 Rig', 'Augspurger Treo 812 Dual Subwoofer System & Barefoot Footprint02',
JSON_ARRAY('Massive Analog Synth Wall', 'Akai MPC & Roland Hardware', 'Pioneer DJ CDJ-3000 Rig', 'Custom RGB Mood Lighting Rig', 'Fast Sampling Workstation'),
'https://images.unsplash.com/photo-1520523839898-50712825e3a7?auto=format&fit=crop&w=1200&q=80', 'active', 4.85, 31),

(5, 'Studio E: Skyline Vocal Suite', 'studio-e-skyline-vocal', 'Ultra-Pristine Vocal & Podcast Broadcast Studio',
'The ultimate vocal tracking booth with floating floor acoustic decoupling and minus-70dB ambient isolation. Features Sony C-800G, Neumann U87, and Shure SM7B mics with Avalon and BAE preamps, paired with 4-mic podcast broadcast video cameras.',
65.00, 4, 280, 'Grace Design m108 Preamp / Interface', 'Neumann KH 120 II Active Monitors + Sennheiser HD650s',
JSON_ARRAY('Dual 4K Blackmagic Podcast Cameras', 'Whisper-Quiet Vocal Chamber', 'Teleprompter Screen', 'Custom Headphone Cue Mixers', 'Live Streaming Deck'),
'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=1200&q=80', 'active', 4.90, 42);

-- --------------------------------------------------------------------
-- 3. Insert Studio Availability (7 days for each studio)
-- --------------------------------------------------------------------
INSERT INTO studio_availability (studio_id, day_of_week, open_time, close_time, is_open) VALUES
(1, 0, '10:00:00', '22:00:00', 1), (1, 1, '08:00:00', '23:00:00', 1), (1, 2, '08:00:00', '23:00:00', 1), (1, 3, '08:00:00', '23:00:00', 1), (1, 4, '08:00:00', '23:00:00', 1), (1, 5, '08:00:00', '02:00:00', 1), (1, 6, '09:00:00', '02:00:00', 1),
(2, 0, '10:00:00', '22:00:00', 1), (2, 1, '08:00:00', '23:00:00', 1), (2, 2, '08:00:00', '23:00:00', 1), (2, 3, '08:00:00', '23:00:00', 1), (2, 4, '08:00:00', '23:00:00', 1), (2, 5, '08:00:00', '02:00:00', 1), (2, 6, '09:00:00', '02:00:00', 1),
(3, 0, '10:00:00', '20:00:00', 1), (3, 1, '09:00:00', '22:00:00', 1), (3, 2, '09:00:00', '22:00:00', 1), (3, 3, '09:00:00', '22:00:00', 1), (3, 4, '09:00:00', '22:00:00', 1), (3, 5, '09:00:00', '22:00:00', 1), (3, 6, '10:00:00', '20:00:00', 1),
(4, 0, '12:00:00', '02:00:00', 1), (4, 1, '10:00:00', '02:00:00', 1), (4, 2, '10:00:00', '02:00:00', 1), (4, 3, '10:00:00', '02:00:00', 1), (4, 4, '10:00:00', '02:00:00', 1), (4, 5, '10:00:00', '04:00:00', 1), (4, 6, '12:00:00', '04:00:00', 1),
(5, 0, '09:00:00', '21:00:00', 1), (5, 1, '08:00:00', '22:00:00', 1), (5, 2, '08:00:00', '22:00:00', 1), (5, 3, '08:00:00', '22:00:00', 1), (5, 4, '08:00:00', '22:00:00', 1), (5, 5, '08:00:00', '22:00:00', 1), (5, 6, '09:00:00', '22:00:00', 1);

-- --------------------------------------------------------------------
-- 4. Insert Equipment Catalogue
-- --------------------------------------------------------------------
INSERT INTO equipment (id, name, category, brand, model, hourly_rate, daily_rate, total_quantity, available_quantity, description, specs, image_url, status) VALUES
(1, 'Neumann U87 Ai Large-Diaphragm Condenser', 'Microphones', 'Neumann', 'U87 Ai', 15.00, 75.00, 3, 2, 'The global studio standard vocal and acoustic instrument condenser microphone with variable polar patterns.', JSON_OBJECT('Pattern', 'Omni/Cardioid/Figure-8', 'FreqResponse', '20Hz - 20kHz', 'Connector', 'Gold XLR'), 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=600&q=80', 'available'),
(2, 'Sony C-800G Pac Tube Condenser', 'Microphones', 'Sony', 'C-800G', 35.00, 180.00, 1, 1, 'Legendary Peltier-cooled tube microphone celebrated worldwide for chart-topping vocal presence and silkiness.', JSON_OBJECT('Tube', '6AU6 vacuum tube', 'Cooling', 'Thermoelectric Peltier', 'Pattern', 'Uni/Omni'), 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=600&q=80', 'available'),
(3, 'Shure SM7B Dynamic Vocal Mic', 'Microphones', 'Shure', 'SM7B', 8.00, 35.00, 6, 5, 'Classic broadcast and rock vocal dynamic mic with electromagnetic shielding and bass rolloff.', JSON_OBJECT('Type', 'Dynamic', 'Pattern', 'Cardioid', 'Sensitivity', '-59.0 dB'), 'https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=600&q=80', 'available'),
(4, 'Avalon VT-737sp Vacuum Tube Channel Strip', 'Preamps & Outboard', 'Avalon Design', 'VT-737sp', 20.00, 95.00, 2, 2, 'Class-A opto-compressor, parametric EQ, and tube preamplifier with pristine high-headroom output.', JSON_OBJECT('Circuit', 'Class A Twin Tube', 'Compressor', 'Opto-Attenuator', 'RackUnits', '2U'), 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=600&q=80', 'available'),
(5, 'Empirical Labs Distressor EL8X', 'Preamps & Outboard', 'Empirical Labs', 'EL8X-S Pair', 18.00, 85.00, 2, 2, 'Legendary digitally controlled analog harmonic knee compressor with British Mod ratio.', JSON_OBJECT('Type', 'Analog VCA Knee', 'Modes', 'Dist 2 & Dist 3 British Mode', 'Stereo', 'Linked Pair'), 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80', 'available'),
(6, 'Moog Subsequent 37 Analog Synthesizer', 'Synthesizers & Keyboards', 'Moog', 'Subsequent 37', 18.00, 80.00, 2, 1, 'Paraphonic analog synthesizer with Multidrive, Duo mode, and 256 programmable patch memory.', JSON_OBJECT('Keys', '37 Semi-Weighted', 'Oscillators', '2 Variable waveshape VCOs', 'Filter', 'Ladder Filter'), 'https://images.unsplash.com/photo-1520523839898-50712825e3a7?auto=format&fit=crop&w=600&q=80', 'available'),
(7, 'Fender Rhodes Mark I Suitcase 73', 'Synthesizers & Keyboards', 'Fender Rhodes', 'Mark I 73-Key', 25.00, 120.00, 1, 1, 'Authentic 1974 vintage electromechanical tine piano with original preamp and stereo vibrato tremolo.', JSON_OBJECT('Vintage', '1974 Original', 'Tines', 'Raymac Steel', 'Amplifier', 'Stereo 4x12 Cab'), 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80', 'available'),
(8, 'Universal Audio Apollo x8p Heritage Edition', 'Audio Interfaces', 'Universal Audio', 'Apollo x8p', 22.00, 100.00, 2, 2, 'Elite-class audio conversion with 8 Unison mic preamps, HEXA core DSP processing, and Thunderbolt 3.', JSON_OBJECT('Inputs', '8 Unison XLR/TRS', 'DSP', 'HEXA Core 6 Sharc DSP', 'DynamicRange', '129 dB'), 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=600&q=80', 'available'),
(9, 'DW Collector\'s Series Exotic 6-Piece Drum Kit', 'Instruments', 'DW Drums', 'Collector\'s Maple', 30.00, 140.00, 1, 1, 'Handcrafted pure North American maple shells with reinforcement rings and Zildjian K Custom cymbals.', JSON_OBJECT('Shells', 'Pure Maple HVX', 'Snare', '14x6.5 Collector\'s Brass', 'Cymbals', 'Zildjian K Custom Dark Set'), 'https://images.unsplash.com/photo-1519892300165-cb5542fb47c7?auto=format&fit=crop&w=600&q=80', 'available'),
(10, 'Sennheiser HD 800 S Reference Headphones', 'Monitors & Headphones', 'Sennheiser', 'HD 800 S', 10.00, 45.00, 4, 4, 'Open-back dynamic flagship headphones with 56mm Ring Radiator transducer for spatial mixing accuracy.', JSON_OBJECT('Driver', '56mm Ring Radiator', 'Impedance', '300 Ohms', 'Frequency', '4Hz - 51kHz'), 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80', 'available');

-- --------------------------------------------------------------------
-- 5. Insert Sample Bookings
-- --------------------------------------------------------------------
INSERT INTO bookings (id, booking_reference, user_id, studio_id, booking_date, start_time, end_time, duration_hours, session_type, studio_rate, studio_total, equipment_total, tax_amount, total_amount, special_requests, engineer_required, status) VALUES
(1, 'SONIC-2026-9041', 3, 1, '2026-11-10', '14:00:00', '18:00:00', 4, 'Tracking / Recording', 150.00, 600.00, 140.00, 59.20, 799.20, 'Need drum vault isolated and patch bay pre-routed to Pro Tools template.', 1, 'confirmed'),
(2, 'SONIC-2026-9042', 4, 2, '2026-11-12', '11:00:00', '15:00:00', 4, 'Vocal Tracking', 110.00, 440.00, 60.00, 40.00, 540.00, 'Preamp warm tube sound for female indie vocal.', 0, 'confirmed'),
(3, 'SONIC-2026-9043', 5, 4, '2026-11-08', '18:00:00', '22:00:00', 4, 'Full Production', 80.00, 320.00, 72.00, 31.36, 423.36, 'Synth patch programming session.', 1, 'confirmed'),
(4, 'SONIC-2026-9040', 3, 3, '2026-11-02', '13:00:00', '17:00:00', 4, 'Mixing & Mastering', 95.00, 380.00, 0.00, 30.40, 410.40, 'Final album stem summing on SSL console.', 1, 'completed'),
(5, 'SONIC-2026-9039', 6, 5, '2026-11-03', '10:00:00', '13:00:00', 3, 'Podcast / Voiceover', 65.00, 195.00, 24.00, 17.52, 236.52, 'Weekly episode recording with 2 guest mics.', 0, 'completed');

-- --------------------------------------------------------------------
-- 6. Insert Booking Equipment Links
-- --------------------------------------------------------------------
INSERT INTO booking_equipment (id, booking_id, equipment_id, quantity, hourly_rate, total_price) VALUES
(1, 1, 2, 1, 35.00, 140.00), -- Sony C-800G for 4 hrs
(2, 2, 1, 1, 15.00, 60.00),  -- Neumann U87 for 4 hrs
(3, 3, 6, 1, 18.00, 72.00),  -- Moog Subsequent 37 for 4 hrs
(4, 5, 3, 1, 8.00, 24.00);   -- Shure SM7B for 3 hrs

-- --------------------------------------------------------------------
-- 7. Insert Payments
-- --------------------------------------------------------------------
INSERT INTO payments (id, booking_id, transaction_id, amount, payment_method, payment_status, card_last4, card_brand, notes) VALUES
(1, 1, 'TXN_SONIC_88391201', 799.20, 'credit_card', 'completed', '4242', 'Visa', 'Authorized via simulated Stripe portal'),
(2, 2, 'TXN_SONIC_88391202', 540.00, 'apple_pay', 'completed', '8819', 'Apple Card', 'Simulated biometric Apple Pay checkout'),
(3, 3, 'TXN_SONIC_88391203', 423.36, 'credit_card', 'completed', '5521', 'Mastercard', 'Pre-authorized for production session'),
(4, 4, 'TXN_SONIC_88391198', 410.40, 'paypal', 'completed', NULL, 'PayPal', 'Instant settlement account damian@producer.com'),
(5, 5, 'TXN_SONIC_88391195', 236.52, 'credit_card', 'completed', '1102', 'Visa', 'Broadcast podcast session payment');

-- --------------------------------------------------------------------
-- 8. Insert Reviews
-- --------------------------------------------------------------------
INSERT INTO reviews (id, booking_id, user_id, studio_id, rating, sound_quality_rating, cleanliness_rating, comment) VALUES
(1, 4, 3, 3, 5, 5, 5, 'The SSL Duality and PMC monitors in Studio C gave our master incredible punch and clarity. Easily one of the most acoustically transparent control rooms on the West Coast.'),
(2, 5, 6, 5, 5, 5, 5, 'Recorded 3 podcast episodes back-to-back in Studio E. The room isolation is whisper silent (-70dB floor) and the broadcast video feed came out broadcast-ready.');
