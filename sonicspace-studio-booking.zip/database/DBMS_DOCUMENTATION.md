# SonicSpace DBMS Academic & Architectural Documentation
## Music Recording Studio Session & Equipment Booking Management System
**Database Engine**: MySQL 8.0+ (InnoDB Storage Engine)

---

## 1. Entity-Relationship (ER) Model & Cardinalities

### 1.1 Entities & Key Attributes

1. **USER (`users`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `name` (VARCHAR(100))
   - `email` (VARCHAR(150), UNIQUE)
   - `password_hash` (VARCHAR(255))
   - `role` (ENUM('customer', 'admin'))
   - `phone`, `bio`, `genre_specialty`, `avatar_url`, `created_at`, `updated_at`

2. **STUDIO (`studios`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `name` (VARCHAR(120))
   - `slug` (VARCHAR(120), UNIQUE)
   - `tagline`, `description`, `hourly_rate`, `capacity`, `square_feet`
   - `console_type`, `monitoring_system`, `amenities`, `image_url`, `status`
   - `rating_avg`, `review_count`, `created_at`, `updated_at`

3. **STUDIO_AVAILABILITY (`studio_availability`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `studio_id` (FK -> studios.id)
   - `day_of_week` (TINYINT: 0=Sun to 6=Sat)
   - `open_time`, `close_time`, `is_open`

4. **EQUIPMENT (`equipment`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `name`, `category`, `brand`, `model`
   - `hourly_rate`, `daily_rate`, `total_quantity`, `available_quantity`
   - `description`, `specs`, `image_url`, `status`

5. **BOOKING (`bookings`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `booking_reference` (VARCHAR(32), UNIQUE)
   - `user_id` (FK -> users.id)
   - `studio_id` (FK -> studios.id)
   - `booking_date` (DATE)
   - `start_time` (TIME), `end_time` (TIME), `duration_hours` (INT)
   - `session_type`, `studio_rate`, `studio_total`, `equipment_total`, `tax_amount`, `total_amount`
   - `engineer_required`, `special_requests`, `status`

6. **BOOKING_EQUIPMENT (`booking_equipment`) [Associative Entity for M:N]**
   - `id` (PK, INT AUTO_INCREMENT)
   - `booking_id` (FK -> bookings.id)
   - `equipment_id` (FK -> equipment.id)
   - `quantity` (INT)
   - `hourly_rate` (DECIMAL(10,2))
   - `total_price` (DECIMAL(10,2))

7. **PAYMENT (`payments`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `booking_id` (FK -> bookings.id)
   - `transaction_id` (VARCHAR(64), UNIQUE)
   - `amount`, `payment_method`, `payment_status`, `card_last4`, `card_brand`, `payment_date`

8. **REVIEW (`reviews`)**
   - `id` (PK, INT AUTO_INCREMENT)
   - `booking_id` (FK -> bookings.id, UNIQUE - 1 review per booking)
   - `user_id` (FK -> users.id)
   - `studio_id` (FK -> studios.id)
   - `rating`, `sound_quality_rating`, `cleanliness_rating`, `comment`, `created_at`

### 1.2 Cardinalities & Relationships
- **User (1) to Booking (M)**: One customer can make zero or multiple bookings ($1 : N$). A booking must belong to exactly one user ($N : 1$).
- **Studio (1) to Booking (M)**: One studio can host multiple non-overlapping bookings over time ($1 : N$). A booking reserves exactly one primary studio ($N : 1$).
- **Studio (1) to Studio_Availability (M)**: One studio specifies operating hours across 7 days ($1 : 7$).
- **Booking (M) to Equipment (N)** via `booking_equipment`: A booking can reserve 0 or more equipment items; an equipment item can be reserved across multiple distinct bookings ($M : N$).
- **Booking (1) to Payment (1..M)**: A booking can have an initial payment and optional refund or split adjustments ($1 : 1$ standard flow).
- **Booking (1) to Review (0..1)**: A completed booking may yield at most one verified review ($1 : 0..1$).

```
 [ USERS ] 1 ─────────── M [ BOOKINGS ] M ─────────── 1 [ STUDIOS ]
    │                            │                            │
    │ 1                          │ 1                          │ 1
    ▼                            ▼                            ▼
 [ REVIEWS ]                  [ PAYMENTS ]            [ STUDIO_AVAILABILITY ]
    │                            │
    │ M                          │ 1
    └──────────────┐             ▼
                   │   [ BOOKING_EQUIPMENT ] (Bridge Table)
                   │             ▲
                   │             │ M
                   └─────────── [ EQUIPMENT ]
```

---

## 2. Functional Dependencies & Normalization Walkthrough

### 2.1 Functional Dependencies (FDs)
- **USERS**:
  - $id \rightarrow \{name, email, password\_hash, role, phone, bio, genre\_specialty, avatar\_url\}$
  - $email \rightarrow \{id, name, password\_hash, role\}$
- **STUDIOS**:
  - $id \rightarrow \{name, slug, hourly\_rate, capacity, square\_feet, console\_type, monitoring\_system, status\}$
  - $slug \rightarrow \{id, name, ...\}$
- **EQUIPMENT**:
  - $id \rightarrow \{name, category, brand, model, hourly\_rate, daily\_rate, total\_quantity, available\_quantity\}$
- **BOOKINGS**:
  - $id \rightarrow \{booking\_reference, user\_id, studio\_id, booking\_date, start\_time, end\_time, total\_amount, status\}$
  - $booking\_reference \rightarrow \{id, user\_id, studio\_id, ...\}$
- **BOOKING_EQUIPMENT**:
  - $(booking\_id, equipment\_id) \rightarrow \{quantity, hourly\_rate, total\_price\}$

### 2.2 First Normal Form (1NF)
- **Definition**: Every attribute contains only atomic (indivisible) values; no repeating groups or multivalued arrays stored in relational columns without structure.
- **Application**: Equipment reservations are decomposed into individual rows in `booking_equipment` rather than comma-separated lists inside `bookings`. Each column (e.g. `start_time`, `duration_hours`, `hourly_rate`) is atomic.

### 2.3 Second Normal Form (2NF)
- **Definition**: The relation is in 1NF and every non-prime attribute is fully functionally dependent on the entire primary key (no partial dependencies on a composite candidate key).
- **Application**: In `booking_equipment`, the composite key candidate is `(booking_id, equipment_id)`. 
  - `hourly_rate` stored in `booking_equipment` represents the locked contract price at time of reservation (protecting historical invoice integrity from future catalog price changes).
  - Equipment descriptions, brands, and models remain in `equipment` dependent on `equipment_id` alone, avoiding partial key dependencies.

### 2.4 Third Normal Form (3NF)
- **Definition**: The relation is in 2NF and has no transitive dependencies ($X \rightarrow Y$ and $Y \rightarrow Z$ where $Z$ is non-prime and $Y$ is not a superkey).
- **Application**: In `bookings`, we store `user_id` and `studio_id`. We do *not* redundantly store `user_name`, `customer_email`, or `studio_console_type` inside `bookings`. Those attributes are derived at query time via relational joins, eliminating update and deletion anomalies.

---

## 3. SQL DDL & DML Examples

### 3.1 DDL: Adding an Index for High-Concurrency Availability Checking
```sql
CREATE INDEX idx_booking_slot ON bookings (studio_id, booking_date, start_time, end_time, status);
```

### 3.2 DML: CRUD Operations

#### CREATE: Inserting a New Studio
```sql
INSERT INTO studios (name, slug, tagline, description, hourly_rate, capacity, square_feet, console_type, monitoring_system, status)
VALUES ('Studio F: Sub-Zero Bass Lab', 'studio-f-subzero', 'Bass Music & Sound Design Suite', 'Acoustically tuned for low frequency reproduction down to 18Hz.', 85.00, 4, 320, 'SSL Matrix 2', 'Genelec 8351B SAM + 7380A Subwoofer', 'active');
```

#### READ: Fetching Available Studios under $120/hr
```sql
SELECT id, name, hourly_rate, console_type, rating_avg, review_count
FROM studios
WHERE status = 'active' AND hourly_rate <= 120.00
ORDER BY rating_avg DESC;
```

#### UPDATE: Adjusting Equipment Quantity During Studio Maintenance
```sql
UPDATE equipment
SET available_quantity = available_quantity - 1, status = 'maintenance'
WHERE id = 1 AND available_quantity > 0;
```

#### DELETE: Safely Cancelling and Purging Incomplete Draft Bookings
```sql
DELETE FROM bookings
WHERE status = 'pending' AND created_at < NOW() - INTERVAL 1 HOUR;
```

---

## 4. SQL Relational Joins

### 4.1 INNER JOIN: Fetching Active Bookings with Customer & Studio Details
```sql
SELECT 
    b.booking_reference,
    u.name AS artist_name,
    u.email AS artist_email,
    s.name AS studio_name,
    b.booking_date,
    b.start_time,
    b.end_time,
    b.total_amount,
    b.status
FROM bookings b
INNER JOIN users u ON b.user_id = u.id
INNER JOIN studios s ON b.studio_id = s.id
WHERE b.status = 'confirmed'
ORDER BY b.booking_date ASC;
```

### 4.2 LEFT JOIN: Finding Studios That Have Never Received a Negative Review
```sql
SELECT 
    s.id,
    s.name,
    s.hourly_rate,
    COUNT(r.id) AS total_reviews,
    COALESCE(AVG(r.rating), 5.0) AS avg_rating
FROM studios s
LEFT JOIN reviews r ON s.id = r.studio_id
GROUP BY s.id, s.name, s.hourly_rate
HAVING COALESCE(MIN(r.rating), 5) >= 4;
```

### 4.3 Multi-Table Join: Full Itemized Invoice with Reserved Equipment
```sql
SELECT 
    b.booking_reference,
    u.name AS customer_name,
    s.name AS studio_name,
    e.name AS gear_name,
    e.category AS gear_category,
    be.quantity,
    be.hourly_rate AS gear_hourly_rate,
    be.total_price AS gear_total_price,
    p.transaction_id,
    p.payment_status
FROM bookings b
JOIN users u ON b.user_id = u.id
JOIN studios s ON b.studio_id = s.id
LEFT JOIN booking_equipment be ON b.id = be.booking_id
LEFT JOIN equipment e ON be.equipment_id = e.id
LEFT JOIN payments p ON b.id = p.booking_id
WHERE b.id = 1;
```

---

## 5. Database Views & Aggregation Reports

### 5.1 Monthly Revenue Report (Aggregations & Grouping)
```sql
SELECT 
    DATE_FORMAT(booking_date, '%Y-%m') AS session_month,
    COUNT(id) AS total_sessions,
    SUM(studio_total) AS studio_earnings,
    SUM(equipment_total) AS gear_rental_earnings,
    SUM(total_amount) AS gross_revenue,
    ROUND(AVG(total_amount), 2) AS average_ticket_size
FROM bookings
WHERE status IN ('confirmed', 'completed')
GROUP BY DATE_FORMAT(booking_date, '%Y-%m')
ORDER BY session_month DESC;
```

### 5.2 Studio Summary View (Cartesian Inflation Avoidance)
To prevent Cartesian multiplication when joining a studio with both its bookings and its reviews, aggregations are evaluated in derived subquery relations prior to the left join:
```sql
CREATE OR REPLACE VIEW view_studio_summary AS
SELECT 
    s.id AS studio_id,
    s.name AS studio_name,
    s.hourly_rate,
    s.status,
    COALESCE(b_agg.total_bookings, 0) AS total_bookings,
    COALESCE(b_agg.total_studio_revenue, 0.00) AS total_studio_revenue,
    COALESCE(r_agg.computed_rating, s.rating_avg) AS computed_rating,
    COALESCE(r_agg.total_reviews, 0) AS total_reviews
FROM studios s
LEFT JOIN (
    SELECT 
        studio_id,
        COUNT(id) AS total_bookings,
        SUM(CASE WHEN status = 'completed' THEN studio_total ELSE 0 END) AS total_studio_revenue
    FROM bookings
    GROUP BY studio_id
) b_agg ON s.id = b_agg.studio_id
LEFT JOIN (
    SELECT 
        studio_id,
        ROUND(AVG(rating), 2) AS computed_rating,
        COUNT(id) AS total_reviews
    FROM reviews
    GROUP BY studio_id
) r_agg ON s.id = r_agg.studio_id;
```
```

---

## 6. ACID Properties & Concurrency Control (Double-Booking Prevention)

To guarantee that two users attempting to reserve the exact same studio and overlapping time slot cannot both succeed, SonicSpace executes booking creations within an **ACID transaction** using pessimistic row-locking:

### 6.1 Transaction Implementation (Double Booking Protection)
```sql
-- Step 1: Begin Atomic Transaction
START TRANSACTION;

-- Step 2: Lock the target studio row and inspect overlapping reservations
-- Overlap condition: (ExistingStart < NewEnd) AND (ExistingEnd > NewStart)
SELECT id, booking_reference 
FROM bookings
WHERE studio_id = 1
  AND booking_date = '2026-11-15'
  AND status IN ('confirmed', 'in_session', 'pending')
  AND (start_time < '18:00:00' AND end_time > '14:00:00')
FOR UPDATE;

-- Step 3: Application Check
-- If any rows return from the query above, abort immediately:
-- ROLLBACK;
-- SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Studio is already reserved for the requested time slot.';

-- Step 4: Insert the validated booking
INSERT INTO bookings (
    booking_reference, user_id, studio_id, booking_date, start_time, end_time,
    duration_hours, session_type, studio_rate, studio_total, equipment_total,
    tax_amount, total_amount, status
) VALUES (
    'SONIC-2026-9901', 3, 1, '2026-11-15', '14:00:00', '18:00:00',
    4, 'Tracking / Recording', 150.00, 600.00, 0.00,
    48.00, 648.00, 'confirmed'
);

-- Step 5: Record Associated Payment
INSERT INTO payments (
    booking_id, transaction_id, amount, payment_method, payment_status, card_last4
) VALUES (
    LAST_INSERT_ID(), 'TXN_SONIC_990184', 648.00, 'credit_card', 'completed', '4242'
);

-- Step 6: Commit all changes atomically
COMMIT;
```

### 6.2 Rollback Demonstration
If an unhandled error, database constraint violation, or payment failure occurs:
```sql
START TRANSACTION;
-- Booking attempt...
-- Error triggered:
ROLLBACK;
-- Entire transaction is reverted; no partial orphaned booking exists.
```
