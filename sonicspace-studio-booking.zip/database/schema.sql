-- ====================================================================
-- SonicSpace Music Recording Studio & Equipment Booking Management System
-- Target RDBMS: MySQL 8.0+
-- Database Creation & Schema Definition (DDL)
-- ====================================================================

CREATE DATABASE IF NOT EXISTS sonicspace_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sonicspace_db;

-- --------------------------------------------------------------------
-- Drop existing tables if re-running (in reverse foreign key dependency order)
-- --------------------------------------------------------------------
DROP VIEW IF EXISTS view_revenue_monthly;
DROP VIEW IF EXISTS view_booking_details;
DROP VIEW IF EXISTS view_studio_summary;

DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS payments;
DROP TABLE IF EXISTS booking_equipment;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS equipment;
DROP TABLE IF EXISTS studio_availability;
DROP TABLE IF EXISTS studios;
DROP TABLE IF EXISTS users;

-- --------------------------------------------------------------------
-- 1. Table: users
-- Stores customer profiles and administrator credentials with role-based auth
-- --------------------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('customer', 'admin') NOT NULL DEFAULT 'customer',
    phone VARCHAR(30) NULL,
    bio TEXT NULL,
    genre_specialty VARCHAR(100) NULL,
    avatar_url VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_email (email)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 2. Table: studios
-- Soundproofed rooms, mixing suites, tracking rooms, mastering labs
-- --------------------------------------------------------------------
CREATE TABLE studios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    tagline VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    hourly_rate DECIMAL(10, 2) NOT NULL,
    capacity INT NOT NULL DEFAULT 4,
    square_feet INT NOT NULL DEFAULT 450,
    console_type VARCHAR(100) NOT NULL,
    monitoring_system VARCHAR(150) NOT NULL,
    amenities JSON NULL,
    image_url VARCHAR(255) NOT NULL,
    gallery_urls JSON NULL,
    status ENUM('active', 'maintenance', 'inactive') NOT NULL DEFAULT 'active',
    rating_avg DECIMAL(3, 2) NOT NULL DEFAULT 5.00,
    review_count INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_studio_status (status),
    INDEX idx_studio_rate (hourly_rate)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 3. Table: studio_availability
-- Defines regular operating hours or blackout maintenance windows
-- --------------------------------------------------------------------
CREATE TABLE studio_availability (
    id INT AUTO_INCREMENT PRIMARY KEY,
    studio_id INT NOT NULL,
    day_of_week TINYINT NOT NULL COMMENT '0=Sunday, 1=Monday, ..., 6=Saturday',
    open_time TIME NOT NULL DEFAULT '08:00:00',
    close_time TIME NOT NULL DEFAULT '23:00:00',
    is_open BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (studio_id) REFERENCES studios(id) ON DELETE CASCADE,
    UNIQUE KEY uk_studio_day (studio_id, day_of_week)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 4. Table: equipment
-- Microphones, preamps, synthesizers, drum kits, audio interfaces
-- --------------------------------------------------------------------
CREATE TABLE equipment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    category ENUM('Microphones', 'Preamps & Outboard', 'Synthesizers & Keyboards', 'Monitors & Headphones', 'Instruments', 'Audio Interfaces') NOT NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    hourly_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    daily_rate DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    total_quantity INT NOT NULL DEFAULT 1,
    available_quantity INT NOT NULL DEFAULT 1,
    description TEXT NULL,
    specs JSON NULL,
    image_url VARCHAR(255) NOT NULL,
    status ENUM('available', 'rented', 'maintenance', 'retired') NOT NULL DEFAULT 'available',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_equipment_category (category),
    INDEX idx_equipment_status (status)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 5. Table: bookings
-- Studio session reservations made by customers
-- --------------------------------------------------------------------
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_reference VARCHAR(32) NOT NULL UNIQUE,
    user_id INT NOT NULL,
    studio_id INT NOT NULL,
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    duration_hours INT NOT NULL,
    session_type VARCHAR(100) NOT NULL DEFAULT 'Tracking / Recording',
    studio_rate DECIMAL(10, 2) NOT NULL,
    studio_total DECIMAL(10, 2) NOT NULL,
    equipment_total DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    tax_amount DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    total_amount DECIMAL(10, 2) NOT NULL,
    special_requests TEXT NULL,
    engineer_required BOOLEAN NOT NULL DEFAULT FALSE,
    status ENUM('pending', 'confirmed', 'in_session', 'completed', 'cancelled') NOT NULL DEFAULT 'confirmed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (studio_id) REFERENCES studios(id) ON DELETE RESTRICT,
    INDEX idx_booking_schedule (studio_id, booking_date, start_time, end_time),
    INDEX idx_booking_user (user_id),
    INDEX idx_booking_status (status)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 6. Table: booking_equipment (Many-to-Many associative table)
-- Records individual equipment pieces reserved for a specific studio booking
-- --------------------------------------------------------------------
CREATE TABLE booking_equipment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    equipment_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    hourly_rate DECIMAL(10, 2) NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE RESTRICT,
    UNIQUE KEY uk_booking_eq (booking_id, equipment_id)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 7. Table: payments
-- Simulated payment transactions (Card, Apple Pay, PayPal, Studio Credit)
-- --------------------------------------------------------------------
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL,
    transaction_id VARCHAR(64) NOT NULL UNIQUE,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method ENUM('credit_card', 'debit_card', 'apple_pay', 'paypal', 'studio_credit') NOT NULL DEFAULT 'credit_card',
    payment_status ENUM('pending', 'completed', 'failed', 'refunded') NOT NULL DEFAULT 'completed',
    card_last4 VARCHAR(4) NULL,
    card_brand VARCHAR(30) NULL,
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes VARCHAR(255) NULL,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    INDEX idx_payment_status (payment_status)
) ENGINE=InnoDB;

-- --------------------------------------------------------------------
-- 8. Table: reviews
-- Customer feedback, acoustics rating, engineer rating, and comment
-- --------------------------------------------------------------------
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT NOT NULL UNIQUE,
    user_id INT NOT NULL,
    studio_id INT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    sound_quality_rating INT NOT NULL CHECK (sound_quality_rating BETWEEN 1 AND 5),
    cleanliness_rating INT NOT NULL CHECK (cleanliness_rating BETWEEN 1 AND 5),
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (studio_id) REFERENCES studios(id) ON DELETE CASCADE,
    INDEX idx_review_studio (studio_id),
    INDEX idx_review_rating (rating)
) ENGINE=InnoDB;

-- ====================================================================
-- DATABASE VIEWS
-- ====================================================================

-- 1. view_studio_summary: Aggregate analytics per studio (uses independent subqueries to prevent revenue inflation)
CREATE OR REPLACE VIEW view_studio_summary AS
SELECT 
    s.id AS studio_id,
    s.name AS studio_name,
    s.hourly_rate,
    s.status,
    COALESCE(b_agg.total_bookings, 0) AS total_bookings,
    COALESCE(b_agg.total_studio_revenue, 0.00) AS total_studio_revenue,
    COALESCE(r_agg.computed_rating, s.rating_avg) AS computed_rating,
    COALESCE(r_agg.total_reviews, 0) AS total_reviews
FROM studios s
LEFT JOIN (
    SELECT 
        studio_id,
        COUNT(id) AS total_bookings,
        SUM(CASE WHEN status = 'completed' THEN studio_total ELSE 0 END) AS total_studio_revenue
    FROM bookings
    GROUP BY studio_id
) b_agg ON s.id = b_agg.studio_id
LEFT JOIN (
    SELECT 
        studio_id,
        ROUND(AVG(rating), 2) AS computed_rating,
        COUNT(id) AS total_reviews
    FROM reviews
    GROUP BY studio_id
) r_agg ON s.id = r_agg.studio_id;

-- 2. view_booking_details: Denormalized booking view with client and studio info
CREATE OR REPLACE VIEW view_booking_details AS
SELECT 
    b.id AS booking_id,
    b.booking_reference,
    b.booking_date,
    b.start_time,
    b.end_time,
    b.duration_hours,
    b.session_type,
    b.status AS booking_status,
    b.total_amount,
    u.id AS user_id,
    u.name AS customer_name,
    u.email AS customer_email,
    u.phone AS customer_phone,
    s.id AS studio_id,
    s.name AS studio_name,
    p.transaction_id,
    p.payment_status,
    p.payment_method,
    COUNT(be.id) AS reserved_equipment_count
FROM bookings b
JOIN users u ON b.user_id = u.id
JOIN studios s ON b.studio_id = s.id
LEFT JOIN payments p ON b.id = p.booking_id
LEFT JOIN booking_equipment be ON b.id = be.booking_id
GROUP BY b.id, b.booking_reference, b.booking_date, b.start_time, b.end_time, 
         b.duration_hours, b.session_type, b.status, b.total_amount, u.id, 
         u.name, u.email, u.phone, s.id, s.name, p.transaction_id, p.payment_status, p.payment_method;

-- 3. view_revenue_monthly: Financial aggregation view
CREATE OR REPLACE VIEW view_revenue_monthly AS
SELECT 
    DATE_FORMAT(b.booking_date, '%Y-%m') AS booking_month,
    COUNT(b.id) AS booking_count,
    SUM(b.studio_total) AS total_studio_sales,
    SUM(b.equipment_total) AS total_equipment_sales,
    SUM(b.total_amount) AS total_revenue
FROM bookings b
WHERE b.status IN ('confirmed', 'completed', 'in_session')
GROUP BY DATE_FORMAT(b.booking_date, '%Y-%m')
ORDER BY booking_month DESC;
